package com.capitalone.bank.wire.object.mapper.fis;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Derives the name table ({@code src/main/resources/fis/pain001-v11-fis-names.json}) from two files:
 * the pain.001.001.11 schema and the FIS contract (OpenAPI).
 *
 * <p>How: the FIS contract keeps the type names of the ISO schema and lists the properties of a type in
 * the order the schema lists its elements. So the two are lined up type by type and position by position:
 * the third element of {@code GroupHeader95} in the schema ({@code Authstn}) is the third property of
 * {@code GroupHeader95} in the contract ({@code authorisation}). Whether a property is a list, a boolean
 * or required is read from the contract. Four property names of the contract's schemas are not the names
 * FIS writes in its own requests ({@code iBAN}, {@code bICFI}, {@code lEI}, {@code uetr} against
 * {@code IBAN}, {@code BICFI}, {@code UETR}): for a tag written in capitals only, the table carries both,
 * the schema's as {@code json} and FIS's as {@code sent}. Wherever the two do not line up (another number of elements, a
 * list on one side only, another type name) a problem is reported and nothing is guessed.
 *
 * <p>Supplementary data is described by the contract alone: which supplement FIS takes at which place,
 * and the types inside it.
 *
 * <p>Run with {@code ./gradlew generateFisNameTable}. Arguments: the schema, the contract, the file to write.
 */
public final class FisNameTableGenerator {

    private static final String XS = "http://www.w3.org/2001/XMLSchema";
    private static final String REQUEST_TYPE = "Pain001v11UniversalApplicationMessage1";
    private static final ObjectMapper JSON = new ObjectMapper();

    /** The table as it is written to the resource, and what could not be lined up. */
    record Result(String text, List<String> problems, int types, int names) {
    }

    private record XsdChild(String tag, String type, boolean repeats) {
    }

    private record XsdType(String name, List<XsdChild> children, List<String> attributes, boolean value) {
    }

    private FisNameTableGenerator() {
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 3) {
            System.err.println("usage: FisNameTableGenerator <pain.001.001.11.xsd> <FIS contract .json> <table to write>");
            System.exit(2);
        }
        Result result;
        try (var xsd = Files.newInputStream(Path.of(args[0])); var contract = Files.newInputStream(Path.of(args[1]))) {
            result = generate(xsd, contract);
        }
        result.problems().forEach(problem -> System.out.println("PROBLEM  " + problem));
        if (!result.problems().isEmpty()) {
            System.out.println(result.problems().size() + " place(s) where the schema and the contract do not line up; nothing written");
            System.exit(1);
        }
        var target = Path.of(args[2]);
        Files.createDirectories(target.getParent());
        Files.writeString(target, result.text(), StandardCharsets.UTF_8);
        System.out.println(result.types() + " types, " + result.names() + " names -> " + target);
    }

    static Result generate(InputStream xsdStream, InputStream contractStream) throws IOException {
        var problems = new ArrayList<String>();
        JsonNode contract = JSON.readTree(contractStream);
        JsonNode schemas = contract.path("components").path("schemas");

        // ---------------------------------------------------------- the schema
        Element schema;
        try {
            var parsers = DocumentBuilderFactory.newInstance();
            parsers.setNamespaceAware(true);
            parsers.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            schema = parsers.newDocumentBuilder().parse(xsdStream).getDocumentElement();
        } catch (Exception e) {
            throw new IOException("Cannot read the schema", e);
        }
        var namespace = schema.getAttribute("targetNamespace");
        var xsdTypes = new LinkedHashMap<String, XsdType>();
        String documentType = null;
        for (Element top : elements(schema)) {
            if (top.getLocalName().equals("element") && top.getAttribute("name").equals("Document")) {
                documentType = top.getAttribute("type");
            }
            if (!top.getLocalName().equals("complexType")) {
                continue;
            }
            var children = new ArrayList<XsdChild>();
            var attributes = new ArrayList<String>();
            var value = new boolean[1];
            collect(top, children, attributes, value);
            xsdTypes.put(top.getAttribute("name"), new XsdType(top.getAttribute("name"), children, attributes, value[0]));
        }
        if (documentType == null) {
            throw new IOException("The schema has no Document element");
        }

        // ---------------------------------------------------------- the message: schema and contract side by side
        var iso = new TreeMap<String, String>();
        var fisQueue = new ArrayDeque<String>();
        var names = 0;
        var documentContractType = refName(schemas.path(REQUEST_TYPE).path("properties").path("businessDocument"));
        if (documentContractType == null) {
            problems.add(REQUEST_TYPE + ": the contract has no businessDocument to start from");
        }
        for (XsdType type : xsdTypes.values()) {
            if (type.name().equals("SupplementaryData1") || type.name().equals("SupplementaryDataEnvelope1")) {
                continue;   // FIS types these per place in the message; see below
            }
            var contractName = type.name().equals(documentType) ? documentContractType : type.name();
            JsonNode s = contractName == null ? null : schemas.get(contractName);
            if (s == null) {
                problems.add(type.name() + ": the contract has no schema of that name");
                continue;
            }
            var props = properties(s);
            if (type.value()) {
                // a value with attributes, such as an amount and its currency: one property for each
                var attributeJson = new LinkedHashMap<String, String>();
                var rest = new ArrayList<>(props.keySet());
                for (String attribute : type.attributes()) {
                    var start = attribute.toLowerCase(Locale.ROOT).substring(0, Math.min(3, attribute.length()));
                    var match = rest.stream().filter(p -> p.toLowerCase(Locale.ROOT).startsWith(start)
                            || (attribute.equals("Ccy") && p.toLowerCase(Locale.ROOT).contains("currency"))).findFirst();
                    if (match.isPresent()) {
                        attributeJson.put(attribute, match.get());
                        rest.remove(match.get());
                    }
                }
                if (attributeJson.size() != type.attributes().size() || rest.size() != 1) {
                    problems.add(type.name() + ": a value with the attributes " + type.attributes()
                            + ", but the contract has the properties " + props.keySet());
                    continue;
                }
                var line = new StringBuilder("{\"value\": " + q(rest.get(0)) + ", \"attributes\": {");
                var first = true;
                for (var a : attributeJson.entrySet()) {
                    line.append(first ? "" : ", ").append(q(a.getKey())).append(": ").append(q(a.getValue()));
                    first = false;
                }
                iso.put(type.name(), line.append("}}").toString());
                names += 1 + attributeJson.size();
                continue;
            }
            if (props.size() != type.children().size()) {
                problems.add(type.name() + ": " + type.children().size() + " elements in the schema, "
                        + props.size() + " properties in the contract");
                continue;
            }
            var required = required(s);
            var fields = new ArrayList<String>();
            var index = 0;
            for (var prop : props.entrySet()) {
                var child = type.children().get(index++);
                var json = prop.getKey();
                var p = prop.getValue();
                var ref = refName(p);
                var list = "array".equals(p.path("type").asText());
                if (list != child.repeats()) {
                    problems.add(type.name() + "/" + child.tag() + ": the schema says "
                            + (child.repeats() ? "repeatable" : "single") + ", the contract says "
                            + (list ? "a list" : "a single value"));
                }
                String fieldType = null;
                String kind = "string";
                if (child.type().equals("SupplementaryData1")) {
                    if (ref == null) {
                        problems.add(type.name() + "/" + child.tag() + ": the contract does not say what the supplementary data holds");
                    } else {
                        fieldType = ref;
                        supplementaryData(ref, xsdTypes, schemas, iso, fisQueue, problems);
                    }
                } else if (xsdTypes.containsKey(child.type())) {
                    fieldType = child.type();
                    var expected = child.type().equals(documentType) ? documentContractType : child.type();
                    if (ref != null && !ref.equals(expected)) {
                        problems.add(type.name() + "/" + child.tag() + ": the schema says " + child.type()
                                + ", the contract says " + ref);
                    }
                } else {
                    JsonNode target = ref != null ? schemas.path(ref) : (list ? p.path("items") : p);
                    if (isObject(target)) {
                        problems.add(type.name() + "/" + child.tag() + ": a plain value in the schema, an object in the contract");
                    }
                    kind = target.path("type").asText("string");
                }
                // a tag written in capitals only keeps its capitals in FIS's own requests
                var sent = child.tag().matches("[A-Z]{2,}") && !child.tag().equals(json) ? child.tag() : null;
                fields.add(field(child.tag(), json, sent, fieldType, list, kind, required.contains(json)));
                names++;
            }
            iso.put(type.name(), fieldsBlock(fields));
        }

        // ---------------------------------------------------------- inside the supplements: the contract alone
        var fis = new TreeMap<String, String>();
        while (!fisQueue.isEmpty()) {
            var name = fisQueue.poll();
            if (fis.containsKey(name)) {
                continue;
            }
            JsonNode s = schemas.get(name);
            if (s == null) {
                problems.add(name + ": referred to inside a supplement, but the contract has no schema of that name");
                continue;
            }
            var props = properties(s);
            if (props.isEmpty()) {
                if ("object".equals(s.path("type").asText()) && !s.has("oneOf") && !s.has("allOf") && !s.has("anyOf")) {
                    fis.put(name, "{\"open\": true}");
                } else {
                    problems.add(name + ": inside a supplement, a shape this generator does not know");
                }
                continue;
            }
            var required = required(s);
            var fields = new ArrayList<String>();
            for (var prop : props.entrySet()) {
                var json = prop.getKey();
                var p = prop.getValue();
                var ref = refName(p);
                var list = "array".equals(p.path("type").asText());
                JsonNode target = ref != null ? schemas.path(ref) : (list ? p.path("items") : p);
                String fieldType = null;
                String kind = "string";
                if (isObject(target)) {
                    if (ref == null) {
                        problems.add(name + "/" + json + ": an object written in place, which this generator does not know");
                        continue;
                    }
                    fieldType = ref;
                    fisQueue.add(ref);
                } else {
                    kind = target.path("type").asText("string");
                }
                var sent = json.matches("[a-z][A-Z]{2,}") ? json.toUpperCase(Locale.ROOT) : null;
                fields.add(field(json, json, sent, fieldType, list, kind, required.contains(json)));
                names++;
            }
            fis.put(name, fieldsBlock(fields));
        }

        // ---------------------------------------------------------- write
        var text = new StringBuilder();
        text.append("{\n");
        text.append("  \"about\": \"The XML tags of pain.001.001.11 and the names the FIS contract gives them. Derived by the generateFisNameTable task; do not edit by hand.\",\n");
        text.append("  \"contract\": ").append(q(contract.path("info").path("title").asText() + " "
                + contract.path("info").path("version").asText())).append(",\n");
        text.append("  \"namespace\": ").append(q(namespace)).append(",\n");
        text.append("  \"documentType\": ").append(q(documentType)).append(",\n");
        text.append("  \"isoTypes\": {\n").append(block(iso)).append("  },\n");
        text.append("  \"fisTypes\": {\n").append(block(fis)).append("  }\n");
        text.append("}\n");
        return new Result(text.toString(), problems, iso.size() + fis.size(), names);
    }

    /** The two types the contract has for supplementary data at one place: the holder and its envelope. */
    private static void supplementaryData(String holder, Map<String, XsdType> xsdTypes, JsonNode schemas,
                                          Map<String, String> iso, ArrayDeque<String> fisQueue, List<String> problems) {
        if (iso.containsKey(holder)) {
            return;
        }
        JsonNode s = schemas.path(holder);
        var props = properties(s);
        var xsd = xsdTypes.get("SupplementaryData1");
        if (xsd == null || props.size() != xsd.children().size()) {
            problems.add(holder + ": does not line up with SupplementaryData1 of the schema");
            return;
        }
        var required = required(s);
        var fields = new ArrayList<String>();
        var index = 0;
        String envelope = null;
        for (var prop : props.entrySet()) {
            var child = xsd.children().get(index++);
            var ref = refName(prop.getValue());
            if (child.type().equals("SupplementaryDataEnvelope1")) {
                envelope = ref;
            }
            fields.add(field(child.tag(), prop.getKey(), null, child.type().equals("SupplementaryDataEnvelope1") ? ref : null,
                    false, "string", required.contains(prop.getKey())));
        }
        iso.put(holder, fieldsBlock(fields));
        if (envelope == null) {
            problems.add(holder + ": the contract does not say what the envelope holds");
            return;
        }
        // the envelope: which supplement, by its schema name, and the type inside
        var mapping = schemas.path(envelope).path("discriminator").path("mapping");
        var entries = new ArrayList<String>();
        for (String urn : names(mapping)) {
            JsonNode content = schemas.path(last(mapping.get(urn).asText()));
            String element = null;
            String type = null;
            for (var p : properties(content).entrySet()) {
                if (!p.getKey().equals("schema")) {
                    element = p.getKey();
                    type = refName(p.getValue());
                }
            }
            if (element == null || type == null || properties(content).size() != 2) {
                problems.add(envelope + ": the supplement " + urn + " is not a schema name plus one element");
                continue;
            }
            entries.add("      " + q(urn) + ": {\"element\": " + q(element) + ", \"type\": " + q(type) + "}");
            fisQueue.add(type);
        }
        if (entries.isEmpty()) {
            problems.add(envelope + ": the contract names no supplement for this envelope");
            return;
        }
        iso.put(envelope, "{\"supplements\": {\n" + String.join(",\n", entries) + "\n    }}");
    }

    // ------------------------------------------------------------------ small helpers

    private static void collect(Element node, List<XsdChild> children, List<String> attributes, boolean[] value) {
        for (Element e : elements(node)) {
            switch (e.getLocalName()) {
                case "element" -> children.add(new XsdChild(e.getAttribute("name"), e.getAttribute("type"),
                        e.hasAttribute("maxOccurs") && !e.getAttribute("maxOccurs").equals("1")));
                case "any" -> children.add(new XsdChild("*", "", false));
                case "attribute" -> attributes.add(e.getAttribute("name"));
                case "simpleContent" -> {
                    value[0] = true;
                    collect(e, children, attributes, value);
                }
                default -> collect(e, children, attributes, value);
            }
        }
    }

    private static List<Element> elements(Element parent) {
        var out = new ArrayList<Element>();
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element e && XS.equals(e.getNamespaceURI())) {
                out.add(e);
            }
        }
        return out;
    }

    private static Map<String, JsonNode> properties(JsonNode schema) {
        var out = new LinkedHashMap<String, JsonNode>();
        var props = schema.path("properties");
        for (String name : names(props)) {
            out.put(name, props.get(name));
        }
        return out;
    }

    private static List<String> names(JsonNode object) {
        var out = new ArrayList<String>();
        object.fieldNames().forEachRemaining(out::add);
        return out;
    }

    private static List<String> required(JsonNode schema) {
        var out = new ArrayList<String>();
        schema.path("required").forEach(n -> out.add(n.asText()));
        return out;
    }

    private static boolean isObject(JsonNode schema) {
        return schema.has("properties") || "object".equals(schema.path("type").asText())
                || schema.has("oneOf") || schema.has("allOf") || schema.has("anyOf");
    }

    private static String refName(JsonNode property) {
        if (property.has("$ref")) {
            return last(property.get("$ref").asText());
        }
        if (property.path("items").has("$ref")) {
            return last(property.path("items").get("$ref").asText());
        }
        return null;
    }

    private static String last(String ref) {
        return ref.substring(ref.lastIndexOf('/') + 1);
    }

    private static String field(String tag, String json, String sent, String type, boolean list, String kind,
                                boolean required) {
        var line = new StringBuilder("{\"tag\": " + q(tag) + ", \"json\": " + q(json));
        if (sent != null) {
            line.append(", \"sent\": ").append(q(sent));
        }
        if (type != null) {
            line.append(", \"type\": ").append(q(type));
        }
        if (list) {
            line.append(", \"list\": true");
        }
        if (type == null && !"string".equals(kind)) {
            line.append(", \"kind\": ").append(q(kind));
        }
        if (required) {
            line.append(", \"required\": true");
        }
        return line.append("}").toString();
    }

    private static String fieldsBlock(List<String> fields) {
        var out = new StringBuilder("{\"fields\": [\n");
        for (int i = 0; i < fields.size(); i++) {
            out.append("      ").append(fields.get(i)).append(i < fields.size() - 1 ? ",\n" : "\n");
        }
        return out.append("    ]}").toString();
    }

    private static String block(Map<String, String> types) {
        var out = new StringBuilder();
        var i = 0;
        for (var type : types.entrySet()) {
            out.append("    ").append(q(type.getKey())).append(": ").append(type.getValue())
                    .append(++i < types.size() ? ",\n" : "\n");
        }
        return out.toString();
    }

    private static String q(String text) {
        try {
            return JSON.writeValueAsString(text);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(e);
        }
    }
}
