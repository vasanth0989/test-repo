package com.capitalone.bank.wire.object.mapper.fis;

import com.capitalone.bank.wire.object.mapper.fis.FisNameTable.Field;
import com.capitalone.bank.wire.object.mapper.fis.FisNameTable.Type;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads one of FIS's own JSON requests backwards: from the JSON to the pain.001.001.11 XML it stands for,
 * using the same name table as the converter. FIS did not send XML; this exists so that a test can put
 * FIS's request through the converter and see whether it comes out as FIS wrote it.
 *
 * <p>A property the contract has no name for cannot be given an XML tag. It is taken out of the copy and
 * listed in {@link #strays()}.
 */
final class FisSampleXml {

    private final FisNameTable table = FisNameTable.load();
    private final List<String> strays = new ArrayList<>();
    private final StringBuilder xml = new StringBuilder();
    private final ObjectNode document;

    /** @param businessDocument the {@code businessDocument} of a FIS request; it is copied, not changed */
    FisSampleXml(JsonNode businessDocument) {
        this.document = businessDocument.deepCopy();
        xml.append("<Document xmlns=\"").append(table.namespace()).append("\">");
        write(document, table.documentType(), "businessDocument");
        xml.append("</Document>");
    }

    String xml() {
        return xml.toString();
    }

    /** The paths of the properties the contract does not have. */
    List<String> strays() {
        return strays;
    }

    /** The {@code businessDocument} without the strays: what the converter is expected to give back. */
    ObjectNode documentWithoutStrays() {
        return document;
    }

    private void write(ObjectNode object, Type type, String path) {
        var unmatched = new ArrayList<String>();
        object.fieldNames().forEachRemaining(unmatched::add);
        for (Field field : type.fields()) {             // in the order of the schema, whatever the order in the JSON
            var property = unmatched.stream().filter(name -> name.equalsIgnoreCase(field.json())).findFirst().orElse(null);
            if (property == null) {
                continue;
            }
            unmatched.remove(property);
            var value = object.get(property);
            var values = new ArrayList<JsonNode>();
            if (field.list()) {
                value.forEach(values::add);
            } else {
                values.add(value);
            }
            for (int i = 0; i < values.size(); i++) {
                var at = path + "." + property + (field.list() ? "[" + i + "]" : "");
                element(field, values.get(i), at);
            }
        }
        for (String stray : unmatched) {
            strays.add(path + "." + stray);
            object.remove(stray);
        }
    }

    private void element(Field field, JsonNode value, String path) {
        if (field.type() == null) {
            leaf(field.tag(), value.asText());
            return;
        }
        var type = table.isoType(field.type());
        if (type.isEnvelope()) {
            var supplement = type.supplements().get(value.path("schema").asText());
            if (supplement == null) {
                throw new IllegalStateException(path + ": no supplement known for the schema " + value.path("schema"));
            }
            xml.append("<Envlp><").append(supplement.element()).append(" xmlns=\"").append(supplement.schema()).append("\">");
            open(value.path(supplement.element()));
            xml.append("</").append(supplement.element()).append("></Envlp>");
        } else if (type.value() != null) {
            xml.append('<').append(field.tag());
            type.attributes().forEach((attribute, json) -> {
                if (value.has(json)) {
                    xml.append(' ').append(attribute).append("=\"").append(escape(value.get(json).asText())).append('"');
                }
            });
            xml.append('>').append(escape(value.path(type.value()).asText())).append("</").append(field.tag()).append('>');
        } else {
            xml.append('<').append(field.tag()).append('>');
            write((ObjectNode) value, type, path);
            xml.append("</").append(field.tag()).append('>');
        }
    }

    /** FIS's own elements inside a supplement: the names as they are. */
    private void open(JsonNode object) {
        object.fieldNames().forEachRemaining(name -> {
            var value = object.get(name);
            var values = new ArrayList<JsonNode>();
            if (value.isArray()) {
                value.forEach(values::add);
            } else {
                values.add(value);
            }
            for (JsonNode one : values) {
                if (one.isObject()) {
                    xml.append('<').append(name).append('>');
                    open(one);
                    xml.append("</").append(name).append('>');
                } else {
                    leaf(name, one.asText());
                }
            }
        });
    }

    private void leaf(String tag, String text) {
        xml.append('<').append(tag).append('>').append(escape(text)).append("</").append(tag).append('>');
    }

    private static String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
