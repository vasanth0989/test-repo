package com.capitalone.bank.wire.object.mapper.fis;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SchemaValidatorsConfig;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.oas.OpenApi30;
import java.util.ArrayList;
import java.util.List;

/**
 * The FIS contract (OpenAPI 3.0, {@code src/test/resources/fis/EP-POM-CCTI.json}) as a validator for the
 * request body of {@code POST /customer-credit-transfer-initiations}. Used by the tests and the sample
 * renderer only; nothing of it is in the library.
 *
 * <p>The contract is read in two ways, because it does not agree with itself on four names. Its schemas
 * declare the properties {@code iBAN}, {@code bICFI}, {@code lEI} and {@code uetr}. The example request
 * inside the same contract, and FIS's sample requests, write {@code IBAN}, {@code BICFI} and
 * {@code UETR}; and the schema of an account identification declares {@code iBAN} but requires
 * {@code IBAN}, so that an IBAN account can never be valid against the contract as published.
 * <ul>
 *   <li>{@link #problems}: the contract with those names read as FIS writes them. This is the check the
 *       converter's output has to pass.</li>
 *   <li>{@link #problemsAsPublished}: the contract exactly as FIS published it.</li>
 * </ul>
 * Which names are read differently is taken from the name table ({@code sent} against {@code json}), so
 * there is no second list to keep in step.
 */
final class FisContract {

    static final String RESOURCE = "/fis/EP-POM-CCTI.json";
    private static final String REQUEST = "#/components/schemas/Pain001v11UniversalApplicationMessage1";

    private static final JsonSchema AS_PUBLISHED = schema(false);
    private static final JsonSchema AS_FIS_WRITES_THE_NAMES = schema(true);

    private FisContract() {
    }

    /** What the contract objects to in a request, with the four names read as FIS writes them. Empty when valid. */
    static List<String> problems(String requestJson) {
        return validate(AS_FIS_WRITES_THE_NAMES, requestJson);
    }

    /** What the contract exactly as published objects to in a request. Empty when valid. */
    static List<String> problemsAsPublished(String requestJson) {
        return validate(AS_PUBLISHED, requestJson);
    }

    private static List<String> validate(JsonSchema schema, String requestJson) {
        return schema.validate(FisFixtures.tree(requestJson)).stream()
                .map(message -> message.getInstanceLocation() + ": " + message.getMessage()
                        .replace(message.getInstanceLocation() + ": ", ""))
                .distinct()
                .sorted()
                .toList();
    }

    private static JsonSchema schema(boolean namesAsFisWritesThem) {
        var contract = (ObjectNode) FisFixtures.tree(FisFixtures.resource(RESOURCE));
        if (namesAsFisWritesThem) {
            var table = FisNameTable.load();
            var types = new ArrayList<>(table.isoTypes().values());
            types.addAll(table.fisTypes().values());
            for (var type : types) {
                for (var field : type.fields()) {
                    if (field.sent() != null) {
                        rename(contract.path("components").path("schemas").path(type.name()), field.json(), field.sent());
                    }
                }
            }
        }
        // the request body is one schema of the document; the rest stays reachable through its references
        contract.put("$ref", REQUEST);
        var factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V202012, builder -> builder
                .metaSchema(OpenApi30.getInstance())
                .defaultMetaSchemaIri(OpenApi30.getInstance().getIri()));
        var config = SchemaValidatorsConfig.builder().formatAssertionsEnabled(true).build();
        return factory.getSchema(contract, config);
    }

    /** Gives one property of a schema another name, keeping its place, also where the name is listed as required. */
    private static void rename(JsonNode schema, String from, String to) {
        if (!(schema instanceof ObjectNode object) || !(object.get("properties") instanceof ObjectNode properties)
                || !properties.has(from)) {
            return;
        }
        var renamed = properties.objectNode();
        properties.fieldNames().forEachRemaining(name -> renamed.set(name.equals(from) ? to : name, properties.get(name)));
        object.set("properties", renamed);
        if (object.get("required") instanceof ArrayNode required) {
            for (int i = 0; i < required.size(); i++) {
                if (required.get(i).asText().equals(from)) {
                    required.set(i, required.textNode(to));
                }
            }
        }
    }
}
