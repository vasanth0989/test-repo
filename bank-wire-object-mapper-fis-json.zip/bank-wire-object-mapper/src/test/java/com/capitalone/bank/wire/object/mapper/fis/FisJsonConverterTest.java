package com.capitalone.bank.wire.object.mapper.fis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.catchThrowableOfType;

import com.fasterxml.jackson.databind.JsonNode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

/** The rules of the conversion one by one: order, value types, lists, the header, and every way it fails. */
class FisJsonConverterTest {

    private static final String DOCUMENT = "businessDocument";
    private final FisJsonConverter converter = FisFixtures.converter();
    private final String xml = FisFixtures.goldenXml("fis-customer-transfer");

    // ------------------------------------------------------------------ the same XML, the same bytes

    @Test
    void theSameXmlAlwaysGivesTheSameBytes() {
        var first = converter.toJson(xml);

        for (int i = 0; i < 25; i++) {
            assertThat(converter.toJson(xml)).isEqualTo(first);
        }
        assertThat(new FisJsonConverter(FisFixtures.header()).toJson(xml)).as("another converter").isEqualTo(first);
        assertThat(converter.toPrettyJson(xml)).isEqualTo(converter.toPrettyJson(xml));
    }

    @Test
    void theMessageInMemoryAndItsXmlTextGiveTheSameBytes() {
        var mapper = FisFixtures.mapper(FisFixtures.FIXED_CLOCK);
        for (String name : FisFixtures.SAMPLES) {
            var payload = FisFixtures.payload(name);

            assertThat(converter.toJson(mapper.map(payload))).as(name).isEqualTo(converter.toJson(mapper.mapToXml(payload)));
        }
    }

    @Test
    void thePropertiesComeInTheOrderOfTheElements() {
        var request = FisFixtures.tree(converter.toJson(xml));
        var initiation = request.path(DOCUMENT).path("customerCreditTransferInitiation");

        assertThat(names(request)).containsExactly("businessApplicationHeader", "businessDocument");
        assertThat(names(initiation)).containsExactly("groupHeader", "paymentInformation", "supplementaryData");
        assertThat(names(initiation.path("groupHeader"))).containsExactly(
                "messageIdentification", "creationDateTime", "numberOfTransactions", "controlSum", "initiatingParty");
        assertThat(names(initiation.path("paymentInformation").path(0))).containsExactly(
                "paymentInformationIdentification", "paymentMethod", "batchBooking", "numberOfTransactions", "controlSum",
                "requestedExecutionDate", "debtor", "debtorAccount", "debtorAgent", "creditTransferTransactionInformation");
        assertThat(names(request.path("businessApplicationHeader"))).containsExactly(
                "characterSet", "from", "to", "businessMessageIdentifier", "messageDefinitionIdentifier",
                "businessService", "marketPractice", "creationDate");
    }

    // ------------------------------------------------------------------ value types

    @Test
    void datesAreIso8601Text() {
        var request = FisFixtures.tree(converter.toJson(xml));
        var initiation = request.path(DOCUMENT).path("customerCreditTransferInitiation");

        var created = initiation.path("groupHeader").path("creationDateTime");
        var requested = initiation.path("paymentInformation").path(0).path("requestedExecutionDate").path("date");
        var headerDate = request.path("businessApplicationHeader").path("creationDate");

        assertThat(created.isTextual()).isTrue();
        assertThat(OffsetDateTime.parse(created.asText())).isEqualTo(OffsetDateTime.parse("2026-10-23T13:56:05Z"));
        assertThat(requested.isTextual()).isTrue();
        assertThat(LocalDate.parse(requested.asText())).isEqualTo(LocalDate.of(2021, 7, 22));
        assertThat(headerDate.isTextual()).isTrue();
        assertThat(OffsetDateTime.parse(headerDate.asText())).isNotNull();
    }

    @Test
    void codesArePlainText() {
        var payment = FisFixtures.tree(converter.toJson(xml)).path(DOCUMENT).path("customerCreditTransferInitiation")
                .path("paymentInformation").path(0);
        var transaction = payment.path("creditTransferTransactionInformation").path(0);

        assertThat(payment.path("paymentMethod")).isEqualTo(text("TRF"));
        assertThat(transaction.path("chargeBearer")).isEqualTo(text("DEBT"));
        assertThat(transaction.path("paymentTypeInformation").path("instructionPriority")).isEqualTo(text("HIGH"));
        assertThat(transaction.path("paymentTypeInformation").path("localInstrument").path("code")).isEqualTo(text("CTR"));
    }

    @Test
    void numbersStayTextAndOnlyTrueOrFalseBecomesABoolean() {
        var initiation = FisFixtures.tree(converter.toJson(xml)).path(DOCUMENT).path("customerCreditTransferInitiation");
        var payment = initiation.path("paymentInformation").path(0);

        assertThat(initiation.path("groupHeader").path("numberOfTransactions")).isEqualTo(text("1"));
        assertThat(initiation.path("groupHeader").path("controlSum")).isEqualTo(text("1258.59"));
        assertThat(payment.path("batchBooking").isBoolean()).isTrue();
        assertThat(payment.path("batchBooking").asBoolean()).isFalse();
    }

    @Test
    void anAmountIsAnObjectOfAmountAndCurrency() {
        var amount = FisFixtures.tree(converter.toJson(xml)).path(DOCUMENT).path("customerCreditTransferInitiation")
                .path("paymentInformation").path(0).path("creditTransferTransactionInformation").path(0)
                .path("amount").path("instructedAmount");

        assertThat(names(amount)).containsExactly("amount", "currency");
        assertThat(amount.path("amount")).isEqualTo(text("1258.59"));
        assertThat(amount.path("currency")).isEqualTo(text("USD"));
    }

    @Test
    void whatMayRepeatIsAListAlsoWhenItIsThereOnce() {
        var initiation = FisFixtures.tree(converter.toJson(xml)).path(DOCUMENT).path("customerCreditTransferInitiation");
        var payment = initiation.path("paymentInformation");
        var transaction = payment.path(0).path("creditTransferTransactionInformation");

        assertThat(payment.isArray()).isTrue();
        assertThat(payment).hasSize(1);
        assertThat(transaction.isArray()).isTrue();
        assertThat(transaction.path(0).path("creditor").path("postalAddress").path("addressLine").isArray()).isTrue();
        assertThat(payment.path(0).path("debtor").path("postalAddress").path("addressLine")).hasSize(3);
        assertThat(transaction.path(0).path("remittanceInformation").path("unstructured").isArray()).isTrue();
    }

    @Test
    void supplementaryDataIsAnObjectWithTheSchemaOfTheSupplement() {
        var initiation = FisFixtures.tree(converter.toJson(xml)).path(DOCUMENT).path("customerCreditTransferInitiation");
        var atTheMessage = initiation.path("supplementaryData").path(0);
        var atTheTransaction = initiation.path("paymentInformation").path(0)
                .path("creditTransferTransactionInformation").path(0).path("supplementaryData").path(0);

        assertThat(atTheMessage.isObject()).isTrue();
        assertThat(atTheMessage.path("placeAndName").asText())
                .isEqualTo("$.businessDocument.customerCreditTransferInitiation.paymentInformation[0]");
        assertThat(names(atTheMessage.path("envelope"))).containsExactly("schema", "paymentInformationSupplement");
        assertThat(atTheMessage.path("envelope").path("schema").asText())
                .isEqualTo("urn:fis:ep:supplement:pain.001.001.11:pmtinf:universal:1");
        assertThat(atTheMessage.path("envelope").path("paymentInformationSupplement").path("extension").isObject()).isTrue();
        assertThat(atTheMessage.path("envelope").path("paymentInformationSupplement").path("extension")
                .path("internationalPayment")).isEqualTo(text("N"));
        assertThat(names(atTheTransaction.path("envelope"))).containsExactly("schema", "transactionInformationSupplement");
        assertThat(atTheTransaction.path("envelope").path("transactionInformationSupplement")
                .path("transactionTraceIdentification")).isEqualTo(text("CHANNEL_UNIQUE205"));
    }

    @Test
    void aTrueOrFalseInsideASupplementBecomesABoolean() {
        var withFlag = xml.replace("<firstInstructionReceiptIdentification>",
                "<forceFunds>true</forceFunds><firstInstructionReceiptIdentification>");

        var supplement = FisFixtures.tree(converter.toJson(withFlag)).path(DOCUMENT)
                .path("customerCreditTransferInitiation").path("supplementaryData").path(0).path("envelope")
                .path("paymentInformationSupplement");

        assertThat(supplement.path("forceFunds").isBoolean()).isTrue();
        assertThat(supplement.path("forceFunds").asBoolean()).isTrue();
    }

    @Test
    void textIsCarriedOverExactly() {
        var odd = xml.replace("<Nm>Bob Burton</Nm>", "<Nm>  José &amp; \"Söhne\" &lt;GmbH&gt; \\ 北京  </Nm>");

        var name = FisFixtures.tree(converter.toJson(odd)).path(DOCUMENT).path("customerCreditTransferInitiation")
                .path("paymentInformation").path(0).path("creditTransferTransactionInformation").path(0)
                .path("creditor").path("name");

        assertThat(name.asText()).isEqualTo("  José & \"Söhne\" <GmbH> \\ 北京  ");
    }

    // ------------------------------------------------------------------ names

    @Test
    void theTagsInCapitalsAreWrittenAsFisWritesThemUnlessAskedOtherwise() {
        var wire = FisFixtures.goldenXml("corp-fx-eur-wire");

        var asFis = converter.toJson(wire);
        var asTheSchemas = converter.withContractNames().toJson(wire);
        var oneName = converter.withName("PaymentIdentification6", "UETR", "uetr").toJson(wire);

        assertThat(asFis).contains("\"IBAN\":", "\"BICFI\":", "\"UETR\":").doesNotContain("\"iBAN\":", "\"bICFI\":", "\"uetr\":");
        assertThat(asTheSchemas).contains("\"iBAN\":", "\"bICFI\":", "\"uetr\":").doesNotContain("\"IBAN\":", "\"BICFI\":", "\"UETR\":");
        assertThat(oneName).contains("\"IBAN\":", "\"BICFI\":", "\"uetr\":").doesNotContain("\"UETR\":");
        assertThatThrownBy(() -> converter.withName("PaymentIdentification6", "NoSuchTag", "x"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ------------------------------------------------------------------ the header

    @Test
    void theHeaderTakesItsIdentifierAndDateFromTheMessage() {
        var header = FisFixtures.tree(converter.toJson(xml)).path("businessApplicationHeader");

        assertThat(header.path("businessMessageIdentifier")).isEqualTo(text("CHANNEL_UNIQUE205"));
        assertThat(header.path("creationDate")).isEqualTo(text("2026-10-23T13:56:05.000Z"));
        assertThat(header.path("messageDefinitionIdentifier")).isEqualTo(text("pain.001.001.11"));
        assertThat(header.path("to").path("organisationIdentification").path("identification")
                .path("organisationIdentification").path("other").path(2).path("schemeName").path("proprietary"))
                .isEqualTo(text("endPointName"));
    }

    @Test
    void theHeaderCanCarryItsOwnIdentifierAndDateAndLeaveOutWhatIsOptional() {
        var own = FisHeader.of(FisFixtures.header().from(), FisFixtures.header().to())
                .withBusinessMessageIdentifier("f47ac10b58cc4372a5670e02b2c3d479")
                .withCreationDate("2026-11-24T10:00:00.000Z");

        var json = converter.withHeader(own).toJson(xml);
        var header = FisFixtures.tree(json).path("businessApplicationHeader");

        assertThat(names(header)).containsExactly("from", "to", "businessMessageIdentifier",
                "messageDefinitionIdentifier", "creationDate");
        assertThat(header.path("businessMessageIdentifier")).isEqualTo(text("f47ac10b58cc4372a5670e02b2c3d479"));
        assertThat(header.path("creationDate")).isEqualTo(text("2026-11-24T10:00:00.000Z"));
        assertThat(FisContract.problems(json)).isEmpty();
    }

    @Test
    void aHeaderWithoutPartiesIsRefused() {
        assertThatThrownBy(() -> FisHeader.of(List.of(), FisFixtures.header().to()))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> FisFixtures.header().withMarketPractice("FIS EP Universal Execution", null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ------------------------------------------------------------------ failures: an error, never part of a request

    @Test
    void textThatIsNotXmlIsAnError() {
        assertThatThrownBy(() -> converter.toJson("{\"not\": \"xml\"}"))
                .isInstanceOf(FisJsonConversionException.class)
                .hasMessageContaining("not valid pain.001.001.11");
        assertThatThrownBy(() -> converter.toJson(xml.substring(0, xml.length() / 2)))
                .isInstanceOf(FisJsonConversionException.class);
    }

    @Test
    void anotherMessageTypeIsAnError() {
        var v9 = xml.replace("pain.001.001.11\"", "pain.001.001.09\"");

        assertThatThrownBy(() -> converter.toJson(v9)).isInstanceOf(FisJsonConversionException.class);
    }

    @Test
    void aMessageThatBreaksTheSchemaIsAnError() {
        var noEndToEndId = xml.replace("<EndToEndId>SALA/EMPL007/05</EndToEndId>", "");
        var unknownTag = xml.replace("<PmtMtd>TRF</PmtMtd>", "<PmtMtd>TRF</PmtMtd><Surprise>1</Surprise>");

        assertThatThrownBy(() -> converter.toJson(noEndToEndId))
                .isInstanceOf(FisJsonConversionException.class).hasMessageContaining("EndToEndId");
        assertThatThrownBy(() -> converter.toJson(unknownTag))
                .isInstanceOf(FisJsonConversionException.class).hasMessageContaining("Surprise");
    }

    @Test
    void aMessageInMemoryThatBreaksTheSchemaIsAnError() {
        var document = FisFixtures.mapper(FisFixtures.FIXED_CLOCK).map(FisFixtures.payload("fis-customer-transfer"));
        document.getCstmrCdtTrfInitn().getGrpHdr().setMsgId(null);

        assertThatThrownBy(() -> converter.toJson(document))
                .isInstanceOf(FisJsonConversionException.class).hasMessageContaining("MsgId");
    }

    @Test
    void aDocumentTypeDeclarationIsRefused() {
        var withDoctype = xml.replace("<Document ", "<!DOCTYPE Document [<!ENTITY x SYSTEM \"file:///etc/hosts\">]><Document ");

        assertThatThrownBy(() -> converter.toJson(withDoctype)).isInstanceOf(FisJsonConversionException.class);
    }

    @Test
    void aSupplementFisDoesNotTakeAtThatPlaceIsAnError() {
        var unknown = xml.replace("urn:fis:ep:supplement:pain.001.001.11:txinf:universal:1", "urn:example:other:1");
        var wrongPlace = xml.replace("urn:fis:ep:supplement:pain.001.001.11:txinf:universal:1",
                "urn:fis:ep:supplement:pain.001.001.11:msg:universal:1");

        assertThatThrownBy(() -> converter.toJson(unknown))
                .isInstanceOf(FisJsonConversionException.class)
                .hasMessageContaining("FIS takes no supplement with the schema urn:example:other:1 here");
        assertThatThrownBy(() -> converter.toJson(wrongPlace)).isInstanceOf(FisJsonConversionException.class);
    }

    @Test
    void everyProblemIsListedWithItsPlace() {
        var broken = xml
                .replace("<transactionTraceIdentification>CHANNEL_UNIQUE205</transactionTraceIdentification>",
                        "<notAFisName>1</notAFisName>")
                .replace("<firstInstructionReceiptIdentification>",
                        "<forceFunds>perhaps</forceFunds><firstInstructionReceiptIdentification>");

        var failure = catchThrowableOfType(FisJsonConversionException.class, () -> converter.toJson(broken));

        assertThat(failure.problems()).hasSize(2);
        assertThat(failure.problems().get(0))
                .startsWith("Document/CstmrCdtTrfInitn/PmtInf[1]/CdtTrfTxInf[1]/SplmtryData[1]/Envlp/transactionInformationSupplement/notAFisName")
                .contains("FIS has no such element");
        assertThat(failure.problems().get(1))
                .startsWith("Document/CstmrCdtTrfInitn/SplmtryData[1]/Envlp/paymentInformationSupplement/forceFunds")
                .contains("true or false");
        assertThat(failure).hasMessageContaining("2 problems");
    }

    // ------------------------------------------------------------------ helpers

    private static List<String> names(JsonNode object) {
        var out = new ArrayList<String>();
        object.fieldNames().forEachRemaining(out::add);
        return out;
    }

    private static JsonNode text(String value) {
        return FisFixtures.JSON.getNodeFactory().textNode(value);
    }
}
