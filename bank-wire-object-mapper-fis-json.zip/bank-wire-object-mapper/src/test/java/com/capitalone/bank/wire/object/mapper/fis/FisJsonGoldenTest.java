package com.capitalone.bank.wire.object.mapper.fis;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Every golden XML message against its golden FIS JSON under {@code src/test/resources/golden/fis-json},
 * and every golden JSON against the FIS contract.
 *
 * <p>The golden JSON files are written by
 * {@code ./gradlew renderFisJson -Pxml=src/test/resources/golden -PoutDir=src/test/resources/golden/fis-json}.
 * Refresh them only after reading the difference.
 */
class FisJsonGoldenTest {

    static Stream<String> samples() {
        return FisFixtures.SAMPLES.stream();
    }

    @ParameterizedTest
    @MethodSource("samples")
    void theGoldenXmlGivesTheGoldenJsonByteForByte(String name) {
        var json = FisFixtures.converter().toPrettyJson(FisFixtures.goldenXml(name));

        assertThat(json).isEqualTo(FisFixtures.goldenJson(name));
    }

    @ParameterizedTest
    @MethodSource("samples")
    void theGoldenJsonIsValidAgainstTheFisContract(String name) {
        assertThat(FisContract.problems(FisFixtures.goldenJson(name))).isEmpty();
    }

    @ParameterizedTest
    @MethodSource("samples")
    void whatIsSentIsTheGoldenJsonOnOneLine(String name) {
        var sent = FisFixtures.converter().toJson(FisFixtures.goldenXml(name));

        assertThat(sent).doesNotContain("\n");
        assertThat(FisFixtures.tree(sent)).isEqualTo(FisFixtures.tree(FisFixtures.goldenJson(name)));
        assertThat(FisContract.problems(sent)).isEmpty();
    }

    /** The whole way: payment object, to the message, to the JSON, with no XML text in between. */
    @ParameterizedTest
    @MethodSource("samples")
    void thePaymentObjectGivesTheSameJsonAsItsGoldenXml(String name) {
        var mapper = FisFixtures.mapper(FisFixtures.FIXED_CLOCK);

        var fromTheMessageInMemory = FisFixtures.converter().toPrettyJson(mapper.map(FisFixtures.payload(name)));

        assertThat(fromTheMessageInMemory).isEqualTo(FisFixtures.goldenJson(name));
    }
}
