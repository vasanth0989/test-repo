package com.capitalone.bank.wire.object.mapper.fis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.junit.jupiter.api.Test;

/** The one call the submitting service makes: the stored payment object (Base64) to the FIS request. */
class WirePaymentFisJsonTest {

    private final WirePaymentFisJson toFis = new WirePaymentFisJson(
            FisFixtures.mapper(FisFixtures.FIXED_CLOCK), FisFixtures.converter());
    private final String payment = FisFixtures.payloadJson("gpn-usd-wire");
    private final String expected = FisFixtures.converter().toJson(FisFixtures.goldenXml("gpn-usd-wire"));

    @Test
    void theEncodedPaymentObjectBecomesTheFisRequest() {
        var encoded = Base64.getEncoder().encodeToString(payment.getBytes(StandardCharsets.UTF_8));

        var request = toFis.fromEncodedPaymentObject(encoded);

        assertThat(request).isEqualTo(expected);
        assertThat(FisContract.problems(request)).isEmpty();
    }

    @Test
    void everyUsualWayOfWritingBase64IsRead() {
        var bytes = payment.getBytes(StandardCharsets.UTF_8);

        assertThat(toFis.fromEncodedPaymentObject(Base64.getUrlEncoder().encodeToString(bytes))).isEqualTo(expected);
        assertThat(toFis.fromEncodedPaymentObject(Base64.getUrlEncoder().withoutPadding().encodeToString(bytes))).isEqualTo(expected);
        assertThat(toFis.fromEncodedPaymentObject(Base64.getMimeEncoder().encodeToString(bytes))).isEqualTo(expected);
        assertThat(toFis.fromEncodedPaymentObject("  " + Base64.getEncoder().encodeToString(bytes) + "\n")).isEqualTo(expected);
    }

    @Test
    void thePaymentObjectAsJsonOrAsAnObjectGivesTheSame() {
        assertThat(toFis.fromPaymentObjectJson(payment)).isEqualTo(expected);
        assertThat(toFis.fromPaymentObject(FisFixtures.payload("gpn-usd-wire"))).isEqualTo(expected);
    }

    @Test
    void textThatIsNotAPaymentObjectIsAnError() {
        assertThatThrownBy(() -> toFis.fromEncodedPaymentObject("   "))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("empty");
        assertThatThrownBy(() -> toFis.fromEncodedPaymentObject(
                Base64.getEncoder().encodeToString("<xml/>".getBytes(StandardCharsets.UTF_8))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("not readable JSON");
        assertThatThrownBy(() -> toFis.fromPaymentObjectJson("null"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void aPaymentThatCannotBeMappedIsAMappingErrorAndNothingIsReturned() {
        var encoded = Base64.getEncoder().encodeToString(
                FisFixtures.payloadJson("invalid-missing-required-fields").getBytes(StandardCharsets.UTF_8));

        assertThatThrownBy(() -> toFis.fromEncodedPaymentObject(encoded)).isInstanceOf(MappingException.class);
    }
}
