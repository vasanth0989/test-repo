package com.capitalone.bank.wire.object.mapper.fis;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.util.List;
import java.util.stream.Stream;

/**
 * Writes the FIS JSON of the samples, so that it can be read and compared. Run with
 * {@code ./gradlew renderFisJson}.
 *
 * <p>Two ways, chosen by the first argument:
 * <ul>
 *   <li>{@code sdp <sample-dir> <out-dir> [name]}: every payment object sample is mapped to
 *       pain.001.001.11 and converted; {@code <name>.xml} and {@code <name>.json} are written side by
 *       side. Samples whose name starts with {@code invalid-} are expected to be rejected.</li>
 *   <li>{@code xml <file-or-dir> <out-dir> [name]}: XML that already exists is converted.</li>
 * </ul>
 * Every JSON is checked against the FIS contract; what the contract objects to is printed.
 */
public final class FisJsonSampleRenderer {

    private FisJsonSampleRenderer() {
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 3 || !(args[0].equals("sdp") || args[0].equals("xml"))) {
            System.err.println("usage: FisJsonSampleRenderer sdp|xml <input> <out-dir> [name]");
            System.exit(2);
        }
        var fromXml = args[0].equals("xml");
        var input = Path.of(args[1]);
        var outDir = Path.of(args[2]);
        var only = args.length > 3 ? args[3] : null;
        var extension = fromXml ? ".xml" : ".json";
        Files.createDirectories(outDir);

        List<Path> files;
        if (Files.isRegularFile(input)) {
            files = List.of(input);
        } else {
            try (Stream<Path> list = Files.list(input)) {
                files = list.filter(p -> p.getFileName().toString().endsWith(extension))
                        .filter(p -> only == null || p.getFileName().toString().equals(only + extension))
                        .sorted()
                        .toList();
            }
        }
        if (files.isEmpty()) {
            System.err.println("Nothing to convert in " + input + (only == null ? "" : " named " + only));
            System.exit(2);
        }

        var clock = "fixed".equals(System.getProperty("sample.clock")) ? FisFixtures.FIXED_CLOCK : Clock.systemUTC();
        var mapper = FisFixtures.mapper(clock);
        var converter = FisFixtures.converter();
        System.out.println("Names from the FIS contract " + converter.contract());
        int unexpected = 0;
        for (Path file : files) {
            var name = file.getFileName().toString().replaceFirst("\\.[a-z]+$", "");
            var expectedToFail = !fromXml && name.startsWith("invalid-");
            try {
                String json;
                if (fromXml) {
                    json = converter.toPrettyJson(Files.readString(file, StandardCharsets.UTF_8));
                } else {
                    var document = mapper.map(FisFixtures.JSON.readValue(Files.readAllBytes(file), SDPPayload.class));
                    Files.writeString(outDir.resolve(name + ".xml"), mapper.mapToXml(
                            FisFixtures.JSON.readValue(Files.readAllBytes(file), SDPPayload.class)), StandardCharsets.UTF_8);
                    json = converter.toPrettyJson(document);
                }
                var target = outDir.resolve(name + ".json");
                Files.writeString(target, json, StandardCharsets.UTF_8);
                var objections = FisContract.problems(json);
                if (objections.isEmpty() && !expectedToFail) {
                    System.out.println("OK       " + name + " -> " + target + " (" + json.lines().count()
                            + " lines, valid against the FIS contract)");
                } else {
                    unexpected++;
                    System.out.println("FAILED   " + name + (expectedToFail
                            ? ": expected a rejection, but it converted"
                            : ": the FIS contract objects (" + objections.size() + ")"));
                    objections.forEach(o -> System.out.println("         " + o));
                }
            } catch (MappingException e) {
                System.out.println((expectedToFail ? "REJECTED " : "FAILED   ") + name + " (not mapped: "
                        + e.problems().size() + " problem" + (e.problems().size() == 1 ? "" : "s") + ")");
                e.problems().forEach(problem -> System.out.println("         " + problem));
                if (!expectedToFail) {
                    unexpected++;
                }
            } catch (FisJsonConversionException e) {
                unexpected++;
                System.out.println("FAILED   " + name + " (not converted)");
                e.problems().forEach(problem -> System.out.println("         " + problem));
            }
        }
        System.out.println();
        System.out.println(files.size() + " sample(s), " + unexpected + " unexpected result(s); output in " + outDir);
        if (unexpected > 0) {
            System.exit(1);
        }
    }
}
