package com.capitalone.bank.wire.object.mapper.fis;

import com.capitalone.bank.wire.object.mapper.fis.FisHeader.Identifier;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.FinancialInstitution;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.InitiatingParty;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.InitiationSource;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules;
import com.capitalone.bank.wire.object.mapper.pain001.v11.Pain001V11Mapper;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** What the FIS JSON tests share: the header, the mapper set-up of the golden files, and the sample files. */
final class FisFixtures {

    /** The samples that have a golden XML file, and so a golden FIS JSON file. */
    static final List<String> SAMPLES = List.of("gpn-usd-wire", "corp-fx-eur-wire", "corp-on-behalf-of-wire",
            "fx-instructed-amount-only", "fis-bank-transfer", "fis-customer-transfer",
            "fis-intermediary-customer-transfer", "fis-drawdown-structured");

    /** The creation time of the golden files: 2026-10-23T13:56:05Z. */
    static final Clock FIXED_CLOCK = Clock.fixed(Instant.parse("2026-10-23T13:56:05Z"), ZoneOffset.UTC);

    static final ObjectMapper JSON = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private static final FisJsonConverter CONVERTER = new FisJsonConverter(header());

    private FisFixtures() {
    }

    /**
     * The header of the request used for the connectivity test with FIS. The identifiers are FIS's sample
     * values; the real ones are agreed with FIS per environment and come from the service configuration.
     */
    static FisHeader header() {
        return FisHeader.of(
                        List.of(new Identifier("POMBULK_CT", "paymentSystemId"),
                                new Identifier("custCBI_01", "coreBankIdentifier")),
                        List.of(new Identifier("XCT", "paymentSystemId"),
                                new Identifier("custCBI_01", "coreBankIdentifier"),
                                new Identifier("EC_CUSTCBI_01_POM_INCOMING", "endPointName")))
                .withCharacterSet("UTF-8")
                .withBusinessService("swift.cbprplus.02")
                .withMarketPractice("FIS EP Universal Execution", "{#:2022 Edition 3}");
    }

    static FisJsonConverter converter() {
        return CONVERTER;
    }

    /** The mapper as the golden XML files were made with it. */
    static Pain001V11Mapper mapper(Clock clock) {
        return new Pain001V11Mapper(new MappingContext(
                new InitiatingParty("Discover Bank", null, "US"),
                new FinancialInstitution(null, "USABA", "031100649", "Discover Bank"),
                new InitiationSource("Payment Exchange Wire Rail II", "Capital One", "1"),
                MappingContext.FisExtension.defaults(),
                clock,
                MappingRules.defaults()));
    }

    static String goldenXml(String name) {
        return resource("/golden/" + name + ".xml");
    }

    static String goldenJson(String name) {
        return resource("/golden/fis-json/" + name + ".json");
    }

    static String payloadJson(String name) {
        return resource("/samples/sdp/" + name + ".json");
    }

    static SDPPayload payload(String name) {
        try {
            return JSON.readValue(payloadJson(name), SDPPayload.class);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** One of FIS's own sample requests, shipped in the jar under /samples/fis. */
    static JsonNode fisSample(String file) {
        return tree(resource("/samples/fis/" + file));
    }

    static JsonNode tree(String json) {
        try {
            return JSON.readTree(json);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** A text resource, with the line ends of every operating system read as line feeds. */
    static String resource(String path) {
        try (InputStream in = FisFixtures.class.getResourceAsStream(path)) {
            if (in == null) {
                throw new IllegalStateException("No resource " + path);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8).replace("\r\n", "\n");
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** Every value of a JSON document by its path, for example {@code groupHeader.controlSum}. */
    static Map<String, String> flat(JsonNode node) {
        var out = new TreeMap<String, String>();
        flat(node, "", out);
        return out;
    }

    private static void flat(JsonNode node, String path, Map<String, String> out) {
        if (node.isObject()) {
            node.fieldNames().forEachRemaining(name ->
                    flat(node.get(name), path.isEmpty() ? name : path + "." + name, out));
        } else if (node.isArray()) {
            for (int i = 0; i < node.size(); i++) {
                flat(node.get(i), path + "[" + i + "]", out);
            }
        } else {
            out.put(path, node.asText());
        }
    }
}
