package com.capitalone.bank.wire.object.mapper.fis;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;

/**
 * The name table in the jar against the two files it is derived from. When FIS sends a new contract and
 * a name, a list or a required flag moved, the first test fails until the table is regenerated
 * ({@code ./gradlew generateFisNameTable}) and the difference has been looked at.
 */
class FisNameTableTest {

    private final FisNameTable table = FisNameTable.load();

    @Test
    void theTableInTheJarIsWhatTheSchemaAndTheContractGive() throws IOException {
        try (var xsd = getClass().getResourceAsStream("/xsd/pain.001.001.11.xsd");
             var contract = getClass().getResourceAsStream(FisContract.RESOURCE)) {
            var derived = FisNameTableGenerator.generate(xsd, contract);

            assertThat(derived.problems()).as("places where the schema and the contract do not line up").isEmpty();
            assertThat(derived.text()).isEqualTo(FisFixtures.resource(FisNameTable.RESOURCE));
        }
    }

    @Test
    void everyTypeOfTheSchemaHasItsNames() {
        // 99 complex types in pain.001.001.11; the two for supplementary data are replaced by the four the
        // contract has for the two places where a supplement may stand
        assertThat(table.isoTypes()).hasSize(101);
        assertThat(table.isoTypes().values()).allSatisfy(type ->
                assertThat(type.fields().isEmpty() && type.value() == null && !type.isEnvelope())
                        .as(type.name() + " has no names").isFalse());
    }

    @Test
    void theNamesAndTheirCasingAreTheOnesOfTheFisContract() {
        assertThat(name("Document", "CstmrCdtTrfInitn")).isEqualTo("customerCreditTransferInitiation");
        assertThat(name("CustomerCreditTransferInitiationV11", "GrpHdr")).isEqualTo("groupHeader");
        assertThat(name("CustomerCreditTransferInitiationV11", "PmtInf")).isEqualTo("paymentInformation");
        assertThat(name("CustomerCreditTransferInitiationV11", "SplmtryData")).isEqualTo("supplementaryData");
        assertThat(name("PaymentInstruction40", "CdtTrfTxInf")).isEqualTo("creditTransferTransactionInformation");
        assertThat(name("GroupHeader95", "CreDtTm")).isEqualTo("creationDateTime");
        assertThat(name("PartyIdentification135", "Nm")).isEqualTo("name");
        assertThat(name("ActiveOrHistoricCurrencyAndAmount", "Ccy")).isEqualTo("currency");
    }

    @Test
    void theFourTagsInCapitalsAreWrittenAsFisWritesThem() {
        assertThat(name("AccountIdentification4Choice", "IBAN")).isEqualTo("IBAN");
        assertThat(name("FinancialInstitutionIdentification18", "BICFI")).isEqualTo("BICFI");
        assertThat(name("FinancialInstitutionIdentification18", "LEI")).isEqualTo("LEI");
        assertThat(name("PaymentIdentification6", "UETR")).isEqualTo("UETR");

        // and the schemas of the contract spell them like this
        var asInTheSchemas = table.withContractNames();
        assertThat(name(asInTheSchemas, "AccountIdentification4Choice", "IBAN")).isEqualTo("iBAN");
        assertThat(name(asInTheSchemas, "FinancialInstitutionIdentification18", "BICFI")).isEqualTo("bICFI");
        assertThat(name(asInTheSchemas, "FinancialInstitutionIdentification18", "LEI")).isEqualTo("lEI");
        assertThat(name(asInTheSchemas, "PaymentIdentification6", "UETR")).isEqualTo("uetr");
    }

    @Test
    void whatRepeatsIsAListAndWhatIsTrueOrFalseIsABoolean() {
        assertThat(table.isoType("CustomerCreditTransferInitiationV11").field("PmtInf").list()).isTrue();
        assertThat(table.isoType("PaymentInstruction40").field("CdtTrfTxInf").list()).isTrue();
        assertThat(table.isoType("PostalAddress24").field("AdrLine").list()).isTrue();
        assertThat(table.isoType("GroupHeader95").field("MsgId").list()).isFalse();
        assertThat(table.isoType("PaymentInstruction40").field("BtchBookg").kind()).isEqualTo("boolean");
        assertThat(table.isoType("GroupHeader95").field("NbOfTxs").kind()).isEqualTo("string");
        assertThat(table.isoType("GroupHeader95").field("CtrlSum").kind()).isEqualTo("string");
    }

    @Test
    void theSupplementsFisTakesAreKnownByTheirSchemaName() {
        var atTheTransaction = table.isoType("SupplementaryData1CreditTransferTransaction54Envelope");
        var atTheMessage = table.isoType("SupplementaryData1CustomerCreditTransferInitiationV11Envelope");

        assertThat(atTheTransaction.supplements().keySet())
                .containsExactly("urn:fis:ep:supplement:pain.001.001.11:txinf:universal:1");
        assertThat(atTheMessage.supplements().keySet()).containsExactlyInAnyOrder(
                "urn:fis:ep:supplement:pain.001.001.11:pmtinf:universal:1",
                "urn:fis:ep:supplement:pain.001.001.11:msg:universal:1");
        assertThat(atTheMessage.supplements().get("urn:fis:ep:supplement:pain.001.001.11:pmtinf:universal:1").element())
                .isEqualTo("paymentInformationSupplement");
    }

    private String name(String type, String tag) {
        return name(table, type, tag);
    }

    private static String name(FisNameTable table, String type, String tag) {
        var def = table.isoType(type);
        if (def.value() != null) {
            return def.attributes().get(tag);
        }
        return table.jsonName(def, def.field(tag));
    }
}
