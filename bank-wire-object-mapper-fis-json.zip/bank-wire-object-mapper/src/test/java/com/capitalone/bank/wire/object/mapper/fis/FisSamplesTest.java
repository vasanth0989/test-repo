package com.capitalone.bank.wire.object.mapper.fis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * The converter against the requests FIS wrote itself: its four sample requests, the example inside its
 * contract, and the request of our connectivity test.
 */
class FisSamplesTest {

    private static final String INITIATION = "customerCreditTransferInitiation.";
    private static final String TRANSACTION = INITIATION + "paymentInformation[0].creditTransferTransactionInformation[0].";

    /**
     * The proof that the name table is right. Each request of FIS is read backwards into the XML it stands
     * for, and that XML is converted. What comes out has to be the request as FIS wrote it: every name,
     * every list, every value.
     */
    @ParameterizedTest
    @ValueSource(strings = {
            "fisopf_api_customer_transfer_req.json",
            "fisopf_api_bank_transfer_req.json",
            "fisopf_api_with_intermediary_customer_transfer_req.json",
            "fisopf_api_DRC_StructuredAndHybridAddress_StructuredRemittance_req.json",
            "fis-customer-credit-transfer-initiation-UC01.json",
            "fis-usd-wire-request-2026-10-22.json"})
    void aRequestOfFisReadAsXmlAndConvertedComesOutAsFisWroteIt(String file) {
        var fis = FisFixtures.fisSample(file);
        if (file.startsWith("fisopf_api_DRC")) {
            // FIS's drawdown sample has no end-to-end identification, which pain.001.001.11 and FIS's own
            // contract both require. As it stands it is refused; with one added it converts like the others.
            var incomplete = new FisSampleXml(fis.path("businessDocument")).xml();
            assertThatThrownBy(() -> FisFixtures.converter().toJson(incomplete))
                    .isInstanceOf(FisJsonConversionException.class).hasMessageContaining("EndToEndId");
            ((ObjectNode) fis.at("/businessDocument/customerCreditTransferInitiation/paymentInformation/0"
                    + "/creditTransferTransactionInformation/0/paymentIdentification"))
                    .put("endToEndIdentification", "NOTPROVIDED");
        }
        var asXml = new FisSampleXml(fis.path("businessDocument"));
        // our connectivity test request was written with the schema's "uetr"; FIS's own requests write "UETR"
        var converter = file.startsWith("fis-usd-wire-request")
                ? FisFixtures.converter().withName("PaymentIdentification6", "UETR", "uetr")
                : FisFixtures.converter();

        var converted = FisFixtures.tree(converter.toJson(asXml.xml()));

        assertThat(converted.path("businessDocument")).isEqualTo(asXml.documentWithoutStrays());
        // one name in one sample is not in the contract at all, so it has no XML tag either
        if (file.startsWith("fisopf_api_DRC")) {
            assertThat(asXml.strays()).containsExactly("businessDocument.customerCreditTransferInitiation"
                    + ".paymentInformation[0].creditTransferTransactionInformation[0].remittanceInformation"
                    + ".structured[0].invoicee.postalAddress.stateOrProvince");
        } else {
            assertThat(asXml.strays()).isEmpty();
        }
    }

    /**
     * One sample end to end against FIS's example of the same payment: the payment object shaped after
     * FIS's customer transfer sample, mapped and converted, set beside that sample. The structure is the
     * same; every difference is listed here, so that a new one fails the test.
     */
    @Test
    void ourCustomerTransferHasTheStructureOfFisCustomerTransferSample() {
        var ours = FisFixtures.tree(FisFixtures.converter().toJson(
                FisFixtures.mapper(FisFixtures.FIXED_CLOCK).map(FisFixtures.payload("fis-customer-transfer"))));
        var fis = FisFixtures.fisSample("fisopf_api_customer_transfer_req.json");

        // the wrapper and the header: the same parts in the same places
        assertThat(ours.fieldNames()).toIterable().containsExactly("businessApplicationHeader", "businessDocument");
        assertThat(fis.fieldNames()).toIterable().containsExactly("businessApplicationHeader", "businessDocument");
        assertThat(shape(ours.path("businessApplicationHeader")))
                .containsAll(shape(fis.path("businessApplicationHeader")));

        // the message
        Map<String, String> mine = FisFixtures.flat(ours.path("businessDocument"));
        Map<String, String> theirs = FisFixtures.flat(fis.path("businessDocument"));
        var onlyOurs = mine.keySet().stream().filter(k -> !theirs.containsKey(k)).collect(Collectors.toCollection(TreeSet::new));
        var onlyFis = theirs.keySet().stream().filter(k -> !mine.containsKey(k)).collect(Collectors.toCollection(TreeSet::new));
        var otherValue = mine.keySet().stream().filter(k -> theirs.containsKey(k) && !theirs.get(k).equals(mine.get(k)))
                .collect(Collectors.toCollection(TreeSet::new));

        assertThat(mine.keySet().stream().filter(k -> theirs.containsKey(k) && theirs.get(k).equals(mine.get(k))).count())
                .as("values that are the same at the same place").isEqualTo(35);
        // set by our side on purpose: when the message was made, and who initiates it (ours names the
        // payer, because the payment object names no initiating party; FIS's sample names the bank)
        assertThat(otherValue).containsExactlyInAnyOrder(
                INITIATION + "groupHeader.creationDateTime",
                INITIATION + "groupHeader.initiatingParty.name");
        // what our mapper writes and FIS's sample leaves out: sums, batch booking, UETR, priority;
        // and the local instrument, which we put on the transaction
        assertThat(onlyOurs).containsExactlyInAnyOrder(
                INITIATION + "groupHeader.controlSum",
                // the payer is mapped as the initiating party, so its address comes with it
                INITIATION + "groupHeader.initiatingParty.postalAddress.addressLine[0]",
                INITIATION + "groupHeader.initiatingParty.postalAddress.addressLine[1]",
                INITIATION + "groupHeader.initiatingParty.postalAddress.addressLine[2]",
                INITIATION + "paymentInformation[0].batchBooking",
                INITIATION + "paymentInformation[0].numberOfTransactions",
                INITIATION + "paymentInformation[0].controlSum",
                TRANSACTION + "paymentIdentification.UETR",
                TRANSACTION + "paymentTypeInformation.instructionPriority",
                TRANSACTION + "paymentTypeInformation.localInstrument.code");
        // what FIS's sample has and ours has not: the local instrument on the payment information, and a
        // placeholder template name
        assertThat(onlyFis).containsExactlyInAnyOrder(
                INITIATION + "paymentInformation[0].paymentTypeInformation.localInstrument.code",
                INITIATION + "supplementaryData[0].envelope.paymentInformationSupplement.extension.templateName");
    }

    /**
     * Why four names are written in capitals. The example request inside the FIS contract is not valid
     * against the schemas of that same contract, and only because of those names; read with the names as
     * FIS writes them, the example is valid.
     */
    @Test
    void theExampleInsideTheContractIsValidOnlyWithTheNamesAsFisWritesThem() {
        var example = FisFixtures.resource("/samples/fis/fis-customer-credit-transfer-initiation-UC01.json");

        var asPublished = FisContract.problemsAsPublished(example);

        assertThat(asPublished).isNotEmpty();
        assertThat(asPublished).allSatisfy(problem ->
                assertThat(problem).containsAnyOf("IBAN", "BICFI", "UETR", "creditorAccount/identification",
                        "debtorAccount/identification"));
        assertThat(FisContract.problems(example)).isEmpty();
    }

    /** The other way round: with the schema's own spelling an IBAN account is refused by the contract itself. */
    @Test
    void withTheSchemaSpellingAnIbanAccountCannotBeValid() {
        var schemaSpelling = FisFixtures.converter().withContractNames();

        var withIban = FisContract.problemsAsPublished(schemaSpelling.toJson(FisFixtures.goldenXml("corp-fx-eur-wire")));
        var withoutIban = FisContract.problemsAsPublished(schemaSpelling.toJson(FisFixtures.goldenXml("gpn-usd-wire")));

        assertThat(withoutIban).isEmpty();
        assertThat(withIban).isNotEmpty().allSatisfy(problem ->
                assertThat(problem).contains("creditorAccount/identification"));
    }

    /** The validator does object: a wrong value, an unknown name and a missing part are each found. */
    @Test
    void theContractCheckFindsWhatIsWrong() {
        var good = FisFixtures.goldenJson("gpn-usd-wire");

        assertThat(FisContract.problems(good)).isEmpty();
        assertThat(FisContract.problems(good.replace("\"currency\": \"USD\"", "\"currency\": \"usd\""))).isNotEmpty();
        assertThat(FisContract.problems(good.replace("\"groupHeader\":", "\"grpHdr\":"))).isNotEmpty();
        assertThat(FisContract.problems(good.replace("\"messageDefinitionIdentifier\": \"pain.001.001.11\",", ""))).isNotEmpty();
        assertThat(FisContract.problems(good.replace("\"batchBooking\": false", "\"batchBooking\": \"false\""))).isNotEmpty();
    }

    /** The paths of a JSON document without list positions and values: its structure. */
    private static Set<String> shape(com.fasterxml.jackson.databind.JsonNode node) {
        return FisFixtures.flat(node).keySet().stream()
                .map(path -> path.replaceAll("\\[\\d+]", "[]"))
                .collect(Collectors.toCollection(TreeSet::new));
    }
}
