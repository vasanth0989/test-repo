package com.capitalone.bank.wire.object.mapper.fis;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.PrettyPrinter;
import java.io.IOException;

/**
 * The layout of the readable form of the FIS JSON: two spaces per level, one property or list entry per
 * line, a line feed at the end of each line on every operating system. It is spelled out here instead of
 * taken from Jackson so that the golden files do not change with the Jackson version or the machine.
 *
 * <p>One instance per document: it counts the nesting.
 */
final class FisJsonLayout implements PrettyPrinter {

    private int depth;

    @Override
    public void writeRootValueSeparator(JsonGenerator g) throws IOException {
        g.writeRaw('\n');
    }

    @Override
    public void writeStartObject(JsonGenerator g) throws IOException {
        g.writeRaw('{');
        depth++;
    }

    @Override
    public void beforeObjectEntries(JsonGenerator g) throws IOException {
        newLine(g);
    }

    @Override
    public void writeObjectFieldValueSeparator(JsonGenerator g) throws IOException {
        g.writeRaw(": ");
    }

    @Override
    public void writeObjectEntrySeparator(JsonGenerator g) throws IOException {
        g.writeRaw(',');
        newLine(g);
    }

    @Override
    public void writeEndObject(JsonGenerator g, int nrOfEntries) throws IOException {
        depth--;
        if (nrOfEntries > 0) {
            newLine(g);
        }
        g.writeRaw('}');
    }

    @Override
    public void writeStartArray(JsonGenerator g) throws IOException {
        g.writeRaw('[');
        depth++;
    }

    @Override
    public void beforeArrayValues(JsonGenerator g) throws IOException {
        newLine(g);
    }

    @Override
    public void writeArrayValueSeparator(JsonGenerator g) throws IOException {
        g.writeRaw(',');
        newLine(g);
    }

    @Override
    public void writeEndArray(JsonGenerator g, int nrOfValues) throws IOException {
        depth--;
        if (nrOfValues > 0) {
            newLine(g);
        }
        g.writeRaw(']');
    }

    private void newLine(JsonGenerator g) throws IOException {
        g.writeRaw('\n');
        for (int i = 0; i < depth; i++) {
            g.writeRaw("  ");
        }
    }
}
