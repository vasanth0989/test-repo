package com.capitalone.bank.wire.object.mapper.fis;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.pain001.v11.Pain001V11Mapper;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Objects;

/**
 * The whole way in one call, as the service that submits to FIS needs it: the payment object as it is
 * stored (Base64 text), to the payment object, to the pain.001.001.11 message, to the FIS JSON. All of it
 * in memory; the XML is never written out.
 *
 * <pre>{@code
 * var toFis = new WirePaymentFisJson(new Pain001V11Mapper(context), new FisJsonConverter(header));
 * String request = toFis.fromEncodedPaymentObject(encodedPaymentObject);   // per payment
 * }</pre>
 *
 * <p>Account numbers are passed on as they arrive. Thread-safe.
 *
 * <p>Three things can go wrong, each with its own exception: the text is not a payment object
 * ({@link IllegalArgumentException}), the payment cannot be mapped ({@link MappingException}), or the
 * message cannot be written as FIS JSON ({@link FisJsonConversionException}). Nothing is returned then.
 */
public final class WirePaymentFisJson {

    private final Pain001V11Mapper mapper;
    private final FisJsonConverter converter;
    private final ObjectMapper payloads;

    public WirePaymentFisJson(Pain001V11Mapper mapper, FisJsonConverter converter) {
        this(mapper, converter, new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false));
    }

    /**
     * @param payloads the reader for the payment object JSON, for a service that already has one configured
     */
    public WirePaymentFisJson(Pain001V11Mapper mapper, FisJsonConverter converter, ObjectMapper payloads) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
        this.converter = Objects.requireNonNull(converter, "converter");
        this.payloads = Objects.requireNonNull(payloads, "payloads");
    }

    /** From the payment object as Base64 text (standard or URL-safe alphabet, line breaks allowed). */
    public String fromEncodedPaymentObject(String base64) {
        Objects.requireNonNull(base64, "base64");
        var text = base64.strip();
        if (text.isEmpty()) {
            throw new IllegalArgumentException("The payment object is empty");
        }
        byte[] decoded;
        try {
            var urlSafe = text.indexOf('-') >= 0 || text.indexOf('_') >= 0;
            decoded = urlSafe ? Base64.getUrlDecoder().decode(text) : Base64.getMimeDecoder().decode(text);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("The payment object is not Base64 text: " + e.getMessage(), e);
        }
        return fromPaymentObjectJson(new String(decoded, StandardCharsets.UTF_8));
    }

    /** From the payment object as JSON text. */
    public String fromPaymentObjectJson(String json) {
        Objects.requireNonNull(json, "json");
        SDPPayload payload;
        try {
            payload = payloads.readValue(json, SDPPayload.class);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("The payment object is not readable JSON: " + e.getOriginalMessage(), e);
        }
        if (payload == null) {
            throw new IllegalArgumentException("The payment object is empty");
        }
        return fromPaymentObject(payload);
    }

    /** From the payment object itself. */
    public String fromPaymentObject(SDPPayload payload) {
        return converter.toJson(mapper.map(payload));
    }
}
