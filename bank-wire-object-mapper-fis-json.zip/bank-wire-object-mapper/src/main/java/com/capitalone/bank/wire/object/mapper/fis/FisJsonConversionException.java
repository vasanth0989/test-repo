package com.capitalone.bank.wire.object.mapper.fis;

import java.util.List;

/**
 * The message could not be converted to the FIS JSON. Nothing is returned in that case: a conversion
 * either gives the whole request or this exception, never part of a request.
 *
 * <p>{@link #problems()} lists every problem found, each with the place in the XML it is about.
 */
public final class FisJsonConversionException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final List<String> problems;

    public FisJsonConversionException(List<String> problems) {
        super(describe(problems));
        this.problems = List.copyOf(problems);
    }

    public FisJsonConversionException(String problem) {
        this(List.of(problem));
    }

    public FisJsonConversionException(String problem, Throwable cause) {
        super(describe(List.of(problem)), cause);
        this.problems = List.of(problem);
    }

    /** Every problem found, in the order of the message. Never empty. */
    public List<String> problems() {
        return problems;
    }

    private static String describe(List<String> problems) {
        if (problems.isEmpty()) {
            throw new IllegalArgumentException("A conversion failure needs at least one problem");
        }
        return "The pain.001.001.11 message was not converted to FIS JSON ("
                + problems.size() + (problems.size() == 1 ? " problem): " : " problems): ")
                + String.join("; ", problems);
    }
}
