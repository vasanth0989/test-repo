package com.capitalone.bank.wire.object.mapper.fis;

import com.capitalone.bank.wire.object.mapper.fis.FisNameTable.Field;
import com.capitalone.bank.wire.object.mapper.fis.FisNameTable.Type;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ObjectFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.jspecify.annotations.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Converts a pain.001.001.11 message to the JSON request the FIS API takes
 * ({@code POST /customer-credit-transfer-initiations}): the message with FIS's long names, inside a
 * business application header.
 *
 * <p>Everything happens in memory. A message comes in as the mapped {@link Document} or as XML text and
 * goes out as JSON text; no file is written.
 *
 * <pre>{@code
 * var converter = new FisJsonConverter(header);          // once, at start-up; thread-safe
 * String json = converter.toJson(mapper.map(payload));   // per payment
 * }</pre>
 *
 * <p>What the conversion does:
 * <ul>
 *   <li>every XML tag gets the name the FIS contract gives it ({@code GrpHdr} becomes {@code groupHeader});
 *       the four tags written in capitals keep their capitals ({@code IBAN}, {@code BICFI}, {@code LEI},
 *       {@code UETR}), as in FIS's own requests, see {@link #withContractNames()};</li>
 *   <li>a tag that may repeat becomes a list, also when it is there once;</li>
 *   <li>a value stays text, exactly as it is in the XML (dates and times are already ISO 8601 there,
 *       codes are plain text); only what the contract types as true or false becomes a JSON boolean;</li>
 *   <li>a value with an attribute becomes an object ({@code <InstdAmt Ccy="USD">10.00</InstdAmt>} becomes
 *       {@code {"amount": "10.00", "currency": "USD"}});</li>
 *   <li>supplementary data becomes an object: the envelope gains {@code schema}, which is the namespace
 *       of the supplement in the XML;</li>
 *   <li>the business application header is put around the message.</li>
 * </ul>
 *
 * <p>The order of the JSON properties is the order of the elements in the message, which is the order of
 * the schema. Nothing depends on a clock, a random number or the order of a hash map, so the same message
 * always gives the same JSON, byte for byte.
 *
 * <p>The message is checked against the pain.001.001.11 schema before it is converted. Any problem, there
 * or in the conversion, ends in a {@link FisJsonConversionException} that lists every problem found; a
 * partial request is never returned.
 */
public final class FisJsonConverter {

    private static final String SCHEMA_RESOURCE = "/xsd/pain.001.001.11.xsd";
    private static final JsonNodeFactory NODES = JsonNodeFactory.instance;
    private static final ObjectMapper JSON = new ObjectMapper();

    private final FisHeader header;
    private final FisNameTable names;
    private final JAXBContext jaxb;
    private final Schema schema;
    private final ObjectFactory factory = new ObjectFactory();

    /**
     * @param header the business application header to put around every message; the identifiers come
     *               from the configuration of the calling service
     */
    public FisJsonConverter(FisHeader header) {
        this(header, FisNameTable.load(), newJaxbContext(), loadSchema());
    }

    private FisJsonConverter(FisHeader header, FisNameTable names, JAXBContext jaxb, Schema schema) {
        this.header = Objects.requireNonNull(header, "header");
        this.names = names;
        this.jaxb = jaxb;
        this.schema = schema;
    }

    /** The same converter with another header, for example with a business message identifier of its own. */
    public FisJsonConverter withHeader(FisHeader value) {
        return new FisJsonConverter(value, names, jaxb, schema);
    }

    /**
     * The same converter, writing the property names of the contract's schemas throughout.
     *
     * <p>Four names differ between the schemas of the FIS contract and the requests FIS writes itself
     * (the example inside the contract and its sample requests): the schemas say {@code iBAN},
     * {@code bICFI}, {@code lEI} and {@code uetr}; FIS's requests say {@code IBAN}, {@code BICFI} and
     * {@code UETR}. By default this converter writes them as FIS's requests do. This switch is for the
     * case that FIS confirms the schema spelling.
     */
    public FisJsonConverter withContractNames() {
        return new FisJsonConverter(header, names.withContractNames(), jaxb, schema);
    }

    /**
     * The same converter, writing another JSON name for one tag of one schema type: for a single name FIS
     * turns out to want spelled differently, without rebuilding the name table. Example:
     * {@code withName("FinancialInstitutionIdentification18", "LEI", "lei")}.
     */
    public FisJsonConverter withName(String schemaType, String xmlTag, String jsonName) {
        return new FisJsonConverter(header, names.withName(schemaType, xmlTag, jsonName), jaxb, schema);
    }

    /** The FIS request for a mapped message, on one line: what is sent. */
    public String toJson(Document document) {
        return write(convert(dom(document)), false);
    }

    /** The FIS request for a message given as pain.001.001.11 XML, on one line. */
    public String toJson(String pain001Xml) {
        return write(convert(dom(pain001Xml)), false);
    }

    /** The same request laid out over lines, for people and for the golden files. */
    public String toPrettyJson(Document document) {
        return write(convert(dom(document)), true);
    }

    /** The same request laid out over lines, for people and for the golden files. */
    public String toPrettyJson(String pain001Xml) {
        return write(convert(dom(pain001Xml)), true);
    }

    /** Title and version of the FIS contract the names come from. */
    public String contract() {
        return names.contract();
    }

    // ------------------------------------------------------------------ the message as a tree, in memory

    private org.w3c.dom.Document dom(Document document) {
        Objects.requireNonNull(document, "document");
        try {
            var dom = parserFactory(false).newDocumentBuilder().newDocument();
            var marshaller = jaxb.createMarshaller();
            marshaller.setSchema(schema);
            marshaller.marshal(factory.createDocument(document), dom);
            return dom;
        } catch (JAXBException e) {
            throw new FisJsonConversionException("the message is not valid pain.001.001.11: " + rootMessage(e), e);
        } catch (ParserConfigurationException e) {
            throw new IllegalStateException("No XML parser available", e);
        }
    }

    private org.w3c.dom.Document dom(String xml) {
        Objects.requireNonNull(xml, "pain001Xml");
        try {
            var builder = parserFactory(true).newDocumentBuilder();
            builder.setErrorHandler(new ErrorHandler() {
                @Override
                public void warning(SAXParseException e) {
                    // a warning does not stop the conversion
                }

                @Override
                public void error(SAXParseException e) throws SAXException {
                    throw e;
                }

                @Override
                public void fatalError(SAXParseException e) throws SAXException {
                    throw e;
                }
            });
            return builder.parse(new InputSource(new StringReader(xml)));
        } catch (SAXParseException e) {
            throw new FisJsonConversionException("the message is not valid pain.001.001.11 (line "
                    + e.getLineNumber() + "): " + e.getMessage(), e);
        } catch (SAXException | IOException e) {
            throw new FisJsonConversionException("the message is not valid pain.001.001.11: " + rootMessage(e), e);
        } catch (ParserConfigurationException e) {
            throw new IllegalStateException("No XML parser available", e);
        }
    }

    /** A parser that reads nothing from outside the text it is given; with {@code validating} it checks the schema. */
    private DocumentBuilderFactory parserFactory(boolean validating) throws ParserConfigurationException {
        var parsers = DocumentBuilderFactory.newInstance();
        parsers.setNamespaceAware(true);
        parsers.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        parsers.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        parsers.setXIncludeAware(false);
        parsers.setExpandEntityReferences(false);
        if (validating) {
            parsers.setSchema(schema);
        }
        return parsers;
    }

    // ------------------------------------------------------------------ tree to FIS JSON

    private ObjectNode convert(org.w3c.dom.Document dom) {
        var problems = new ArrayList<String>();
        var root = dom.getDocumentElement();
        if (root == null || !"Document".equals(root.getLocalName())
                || !names.namespace().equals(root.getNamespaceURI())) {
            throw new FisJsonConversionException("the message does not start with Document in the namespace "
                    + names.namespace());
        }
        var document = object(root, names.documentType(), true, names.namespace(), "Document", problems);
        var request = NODES.objectNode();
        request.set("businessApplicationHeader", header(root, problems));
        request.set("businessDocument", document);
        if (!problems.isEmpty()) {
            throw new FisJsonConversionException(problems);
        }
        return request;
    }

    /** One element with elements inside it. {@code iso} says whether the tags are ISO tags or FIS's own names. */
    private ObjectNode object(Element element, Type type, boolean iso, String namespace, String path,
                              List<String> problems) {
        if (type.open()) {
            return open(element, path, problems);
        }
        var out = NODES.objectNode();
        if (type.value() != null) {
            out.put(type.value(), text(element, path, problems));
            for (var attribute : type.attributes().entrySet()) {
                if (element.hasAttribute(attribute.getKey())) {
                    out.put(attribute.getValue(), element.getAttribute(attribute.getKey()));
                }
            }
            return out;
        }
        for (Element child : children(element)) {
            var tag = child.getLocalName();
            var field = type.field(tag);
            var name = field == null ? tag : names.jsonName(type, field);
            var at = path + "/" + tag;
            if (field != null && field.list()) {
                at = at + "[" + (out.path(name).size() + 1) + "]";
            }
            if (!namespace.equals(child.getNamespaceURI())) {
                problems.add(at + ": is in the namespace " + child.getNamespaceURI() + ", expected " + namespace);
                continue;
            }
            if (field == null) {
                problems.add(at + ": FIS has no such element in " + type.name());
                continue;
            }
            JsonNode value = value(child, field, iso, namespace, at, problems);
            if (field.list()) {
                var existing = out.get(name);
                ArrayNode list = existing instanceof ArrayNode array ? array : out.putArray(name);
                list.add(value);
            } else if (out.has(name)) {
                problems.add(at + ": is there more than once, and FIS takes it once");
            } else {
                out.set(name, value);
            }
        }
        for (Field field : type.fields()) {
            var name = names.jsonName(type, field);
            if (field.required() && !out.has(name)) {
                problems.add(path + ": " + field.tag() + " is missing, and FIS requires it"
                        + (field.tag().equals(field.json()) ? "" : " (" + field.json() + ")"));
            }
        }
        return out;
    }

    private JsonNode value(Element element, Field field, boolean iso, String namespace, String path,
                           List<String> problems) {
        if (field.type() == null) {
            return scalar(element, field.kind(), path, problems);
        }
        var type = iso ? names.isoTypes().get(field.type()) : names.fisType(field.type());
        if (type == null) {
            problems.add(path + ": the name table has no type " + field.type());
            return NODES.objectNode();
        }
        if (type.isEnvelope()) {
            return envelope(element, type, path, problems);
        }
        return object(element, type, iso, namespace, path, problems);
    }

    /** The envelope of supplementary data: the schema name, then the supplement under its own name. */
    private ObjectNode envelope(Element element, Type type, String path, List<String> problems) {
        var out = NODES.objectNode();
        var inside = children(element);
        if (inside.size() != 1) {
            problems.add(path + ": holds " + inside.size() + " elements, and FIS takes exactly one supplement");
            return out;
        }
        var content = inside.get(0);
        var supplement = type.supplements().get(String.valueOf(content.getNamespaceURI()));
        if (supplement == null) {
            problems.add(path + "/" + content.getLocalName() + ": FIS takes no supplement with the schema "
                    + content.getNamespaceURI() + " here (it takes " + String.join(", ", type.supplements().keySet()) + ")");
            return out;
        }
        if (!supplement.element().equals(content.getLocalName())) {
            problems.add(path + "/" + content.getLocalName() + ": the supplement of the schema "
                    + supplement.schema() + " is called " + supplement.element());
            return out;
        }
        var contentType = names.fisType(supplement.type());
        if (contentType == null) {
            problems.add(path + ": the name table has no type " + supplement.type());
            return out;
        }
        out.put("schema", supplement.schema());
        out.set(supplement.element(), object(content, contentType, false, supplement.schema(),
                path + "/" + content.getLocalName(), problems));
        return out;
    }

    /** An object FIS does not describe further: names as they are, text as it is, a repeated name as a list. */
    private ObjectNode open(Element element, String path, List<String> problems) {
        var out = NODES.objectNode();
        var count = new LinkedHashMap<String, Integer>();
        var inside = children(element);
        for (Element child : inside) {
            count.merge(child.getLocalName(), 1, Integer::sum);
        }
        for (Element child : inside) {
            var name = child.getLocalName();
            JsonNode value = children(child).isEmpty()
                    ? NODES.textNode(child.getTextContent())
                    : open(child, path + "/" + name, problems);
            if (count.get(name) > 1) {
                var existing = out.get(name);
                ArrayNode list = existing instanceof ArrayNode array ? array : out.putArray(name);
                list.add(value);
            } else {
                out.set(name, value);
            }
        }
        return out;
    }

    private JsonNode scalar(Element element, String kind, String path, List<String> problems) {
        var text = text(element, path, problems);
        switch (kind) {
            case "boolean" -> {
                var word = text.strip();
                if (word.equals("true") || word.equals("1")) {
                    return NODES.booleanNode(true);
                }
                if (word.equals("false") || word.equals("0")) {
                    return NODES.booleanNode(false);
                }
                problems.add(path + ": FIS takes true or false here, found \"" + text + "\"");
                return NODES.nullNode();
            }
            case "integer" -> {
                try {
                    return NODES.numberNode(new BigInteger(text.strip()));
                } catch (NumberFormatException e) {
                    problems.add(path + ": FIS takes a whole number here, found \"" + text + "\"");
                    return NODES.nullNode();
                }
            }
            case "number" -> {
                try {
                    return NODES.numberNode(new BigDecimal(text.strip()));
                } catch (NumberFormatException e) {
                    problems.add(path + ": FIS takes a number here, found \"" + text + "\"");
                    return NODES.nullNode();
                }
            }
            default -> {
                return NODES.textNode(text);
            }
        }
    }

    private static String text(Element element, String path, List<String> problems) {
        if (!children(element).isEmpty()) {
            problems.add(path + ": holds elements, and FIS takes a plain value here");
            return "";
        }
        return element.getTextContent();
    }

    private static List<Element> children(Element element) {
        var out = new ArrayList<Element>();
        for (Node node = element.getFirstChild(); node != null; node = node.getNextSibling()) {
            if (node instanceof Element child) {
                out.add(child);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ the header around the message

    private ObjectNode header(Element document, List<String> problems) {
        var out = NODES.objectNode();
        if (header.characterSet() != null) {
            out.put("characterSet", header.characterSet());
        }
        out.set("from", party(header.from()));
        out.set("to", party(header.to()));
        var identifier = header.businessMessageIdentifier() != null
                ? header.businessMessageIdentifier()
                : groupHeader(document, "MsgId");
        if (identifier == null || identifier.isBlank()) {
            problems.add("businessApplicationHeader: no business message identifier, and the message has no GrpHdr/MsgId to take it from");
        } else {
            out.put("businessMessageIdentifier", identifier);
        }
        out.put("messageDefinitionIdentifier", header.messageDefinitionIdentifier());
        if (header.businessService() != null) {
            out.put("businessService", header.businessService());
        }
        if (header.marketPracticeRegistry() != null) {
            var practice = out.putObject("marketPractice");
            practice.put("registry", header.marketPracticeRegistry());
            practice.put("identification", header.marketPracticeIdentification());
        }
        var created = header.creationDate() != null ? header.creationDate() : groupHeader(document, "CreDtTm");
        if (created == null || created.isBlank()) {
            problems.add("businessApplicationHeader: no creation date, and the message has no GrpHdr/CreDtTm to take it from");
        } else {
            out.put("creationDate", created);
        }
        return out;
    }

    private static ObjectNode party(List<FisHeader.Identifier> identifiers) {
        var party = NODES.objectNode();
        var others = party.putObject("organisationIdentification")
                .putObject("identification")
                .putObject("organisationIdentification")
                .putArray("other");
        for (var identifier : identifiers) {
            var other = others.addObject();
            other.put("identification", identifier.identification());
            other.putObject("schemeName").put("proprietary", identifier.scheme());
        }
        return party;
    }

    /** The text of {@code Document/CstmrCdtTrfInitn/GrpHdr/<tag>}, or null. */
    private static @Nullable String groupHeader(Element document, String tag) {
        Element at = document;
        for (String step : new String[] {"CstmrCdtTrfInitn", "GrpHdr", tag}) {
            @Nullable Element next = null;
            for (Element child : children(at)) {
                if (step.equals(child.getLocalName())) {
                    next = child;
                    break;
                }
            }
            if (next == null) {
                return null;
            }
            at = next;
        }
        return at.getTextContent();
    }

    // ------------------------------------------------------------------ writing and set-up

    private static String write(ObjectNode request, boolean pretty) {
        try {
            return pretty
                    ? JSON.writer(new FisJsonLayout()).writeValueAsString(request) + "\n"
                    : JSON.writeValueAsString(request);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Cannot write the FIS JSON", e);
        }
    }

    private static JAXBContext newJaxbContext() {
        try {
            return JAXBContext.newInstance(Document.class);
        } catch (JAXBException e) {
            throw new IllegalStateException("Cannot initialise JAXB for pain.001.001.11", e);
        }
    }

    private static Schema loadSchema() {
        try (var xsd = FisJsonConverter.class.getResourceAsStream(SCHEMA_RESOURCE)) {
            if (xsd == null) {
                throw new IllegalStateException("The schema " + SCHEMA_RESOURCE + " is not on the classpath");
            }
            var schemas = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemas.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            schemas.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            return schemas.newSchema(new StreamSource(xsd));
        } catch (SAXException | IOException e) {
            throw new IllegalStateException("Cannot read the schema " + SCHEMA_RESOURCE, e);
        }
    }

    private static String rootMessage(Throwable t) {
        var cause = t;
        while (cause.getCause() != null) {
            cause = cause.getCause();
        }
        return String.valueOf(cause.getMessage());
    }
}
