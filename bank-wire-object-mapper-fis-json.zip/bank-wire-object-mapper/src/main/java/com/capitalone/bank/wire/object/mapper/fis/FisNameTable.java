package com.capitalone.bank.wire.object.mapper.fis;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.jspecify.annotations.Nullable;

/**
 * The name table: for every type of pain.001.001.11, each XML tag and the name the FIS contract gives it,
 * whether FIS takes it as a list, and whether its value is text or true/false. The table is a resource
 * ({@value #RESOURCE}) derived from the schema and the FIS contract by the {@code generateFisNameTable}
 * task; nothing in it is typed by hand.
 *
 * <p>Two sets of types: {@code iso} for the message itself (the tag is the ISO short name) and
 * {@code fis} for what sits inside a supplementary data envelope (FIS's own elements, whose tag already
 * is the JSON name). Immutable and thread-safe.
 */
final class FisNameTable {

    static final String RESOURCE = "/fis/pain001-v11-fis-names.json";

    /**
     * One element of a type.
     *
     * @param json the property name in the schemas of the FIS contract
     * @param sent the name as FIS writes it in its own requests, where that differs ({@code IBAN} for
     *             the contract's {@code iBAN}); null where the two are the same
     * @param type null for a plain value
     */
    record Field(String tag, String json, @Nullable String sent, @Nullable String type, boolean list, String kind,
                 boolean required) {
    }

    /** What a supplementary data envelope may hold at one place of the message. */
    record Supplement(String schema, String element, String type) {
    }

    /**
     * @param fields      the elements, in the order of the schema
     * @param value       for a value with attributes (an amount with its currency): the JSON name of the value
     * @param attributes  XML attribute to JSON name
     * @param open        an object FIS does not describe further: element names are taken as they are
     * @param supplements for an envelope: the supplements FIS takes there, by their schema name
     */
    record Type(String name, List<Field> fields, @Nullable String value, Map<String, String> attributes,
                boolean open, Map<String, Supplement> supplements) {

        @Nullable Field field(String tag) {
            for (Field field : fields) {
                if (field.tag().equals(tag)) {
                    return field;
                }
            }
            return null;
        }

        boolean isEnvelope() {
            return !supplements.isEmpty();
        }
    }

    private final String contract;
    private final String namespace;
    private final String documentType;
    private final Map<String, Type> iso;
    private final Map<String, Type> fis;
    /** "Type/Tag" to the JSON name to write instead of the table's. */
    private final Map<String, String> renames;
    /** Write the property names of the contract's schemas, also where FIS's own requests spell them otherwise. */
    private final boolean contractNames;

    private FisNameTable(String contract, String namespace, String documentType, Map<String, Type> iso,
                         Map<String, Type> fis, Map<String, String> renames, boolean contractNames) {
        this.contract = contract;
        this.namespace = namespace;
        this.documentType = documentType;
        this.iso = iso;
        this.fis = fis;
        this.renames = renames;
        this.contractNames = contractNames;
    }

    /** Reads the table shipped in the jar. */
    static FisNameTable load() {
        try (InputStream in = FisNameTable.class.getResourceAsStream(RESOURCE)) {
            if (in == null) {
                throw new IllegalStateException("The FIS name table " + RESOURCE + " is not on the classpath");
            }
            return parse(new ObjectMapper().readTree(in));
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read the FIS name table " + RESOURCE, e);
        }
    }

    static FisNameTable parse(JsonNode root) {
        return new FisNameTable(
                root.path("contract").asText(),
                root.path("namespace").asText(),
                root.path("documentType").asText(),
                types(root.path("isoTypes")),
                types(root.path("fisTypes")),
                Map.of(),
                false);
    }

    private static Map<String, Type> types(JsonNode node) {
        var out = new LinkedHashMap<String, Type>();
        for (String name : names(node)) {
            var def = node.get(name);
            var fields = new ArrayList<Field>();
            for (JsonNode f : def.path("fields")) {
                fields.add(new Field(
                        f.path("tag").asText(),
                        f.path("json").asText(),
                        f.hasNonNull("sent") ? f.get("sent").asText() : null,
                        f.hasNonNull("type") ? f.get("type").asText() : null,
                        f.path("list").asBoolean(false),
                        f.path("kind").asText("string"),
                        f.path("required").asBoolean(false)));
            }
            var attributes = new LinkedHashMap<String, String>();
            for (String attribute : names(def.path("attributes"))) {
                attributes.put(attribute, def.path("attributes").get(attribute).asText());
            }
            var supplements = new LinkedHashMap<String, Supplement>();
            for (String schema : names(def.path("supplements"))) {
                var supplement = def.path("supplements").get(schema);
                supplements.put(schema, new Supplement(schema,
                        supplement.path("element").asText(), supplement.path("type").asText()));
            }
            out.put(name, new Type(name, List.copyOf(fields),
                    def.hasNonNull("value") ? def.get("value").asText() : null,
                    Collections.unmodifiableMap(attributes),
                    def.path("open").asBoolean(false),
                    Collections.unmodifiableMap(supplements)));
        }
        return Collections.unmodifiableMap(out);
    }

    /** The property names of a JSON object, in the order they are written. */
    private static List<String> names(JsonNode object) {
        var out = new ArrayList<String>();
        object.fieldNames().forEachRemaining(out::add);
        return out;
    }

    /** A copy of the table that writes {@code jsonName} for one tag of one type. */
    FisNameTable withName(String type, String tag, String jsonName) {
        var def = iso.containsKey(type) ? iso.get(type) : fis.get(type);
        if (def == null || def.field(tag) == null) {
            throw new IllegalArgumentException("The name table has no tag " + tag + " in the type " + type);
        }
        var copy = new LinkedHashMap<>(renames);
        copy.put(type + "/" + tag, jsonName);
        return new FisNameTable(contract, namespace, documentType, iso, fis, Collections.unmodifiableMap(copy),
                contractNames);
    }

    /** A copy of the table that writes the property names of the contract's schemas throughout. */
    FisNameTable withContractNames() {
        return new FisNameTable(contract, namespace, documentType, iso, fis, renames, true);
    }

    /**
     * The JSON name of an element: the one asked for with {@link #withName}, else the one FIS writes in
     * its own requests, else the property name of the contract.
     */
    String jsonName(Type type, Field field) {
        var asked = renames.isEmpty() ? null : renames.get(type.name() + "/" + field.tag());
        if (asked != null) {
            return asked;
        }
        return field.sent() != null && !contractNames ? field.sent() : field.json();
    }

    /** Title and version of the FIS contract the table was derived from. */
    String contract() {
        return contract;
    }

    /** The namespace of pain.001.001.11. */
    String namespace() {
        return namespace;
    }

    /** The schema type of the {@code Document} element. */
    Type documentType() {
        return isoType(documentType);
    }

    Type isoType(String name) {
        var type = iso.get(name);
        if (type == null) {
            throw new IllegalStateException("The FIS name table has no type " + name);
        }
        return type;
    }

    @Nullable Type fisType(String name) {
        return fis.get(name);
    }

    Map<String, Type> isoTypes() {
        return iso;
    }

    Map<String, Type> fisTypes() {
        return fis;
    }
}
