package com.capitalone.bank.wire.object.mapper.fis;

import java.util.List;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

/**
 * The business application header FIS wants around the message. It is not in the pain.001: the sender
 * adds it. The identifiers of {@code from} and {@code to} are agreed with FIS per environment, so they
 * come from the configuration of the service that calls FIS, never from this library.
 *
 * <p>Two values default to the message itself when left null, which keeps the conversion free of clocks
 * and random numbers (the same XML always gives the same JSON):
 * {@code businessMessageIdentifier} takes {@code GrpHdr/MsgId} and {@code creationDate} takes
 * {@code GrpHdr/CreDtTm}.
 *
 * @param characterSet                 for example "UTF-8"; null leaves it out
 * @param from                         who sends: one identifier per scheme, in the order FIS expects
 * @param to                           who receives
 * @param businessMessageIdentifier    null takes the message identification of the group header
 * @param messageDefinitionIdentifier  the message type, {@value #PAIN_001_V11}
 * @param businessService              for example "swift.cbprplus.02"; null leaves it out
 * @param marketPracticeRegistry       for example "FIS EP Universal Execution"; written only with the identification
 * @param marketPracticeIdentification for example "{#:2022 Edition 3}"
 * @param creationDate                 an ISO 8601 date and time; null takes the creation time of the group header
 */
public record FisHeader(
        @Nullable String characterSet,
        List<Identifier> from,
        List<Identifier> to,
        @Nullable String businessMessageIdentifier,
        String messageDefinitionIdentifier,
        @Nullable String businessService,
        @Nullable String marketPracticeRegistry,
        @Nullable String marketPracticeIdentification,
        @Nullable String creationDate) {

    public static final String PAIN_001_V11 = "pain.001.001.11";

    /**
     * One identifier of a party in the header.
     *
     * @param identification the value, for example "XCT"
     * @param scheme         FIS's name for what the value is, for example "paymentSystemId"
     */
    public record Identifier(String identification, String scheme) {

        public Identifier {
            requireText(identification, "identification");
            requireText(scheme, "scheme");
        }
    }

    public FisHeader {
        from = List.copyOf(Objects.requireNonNull(from, "from"));
        to = List.copyOf(Objects.requireNonNull(to, "to"));
        if (from.isEmpty() || to.isEmpty()) {
            throw new IllegalArgumentException("The FIS header needs at least one identifier in from and in to");
        }
        requireText(messageDefinitionIdentifier, "messageDefinitionIdentifier");
        if ((marketPracticeRegistry == null) != (marketPracticeIdentification == null)) {
            throw new IllegalArgumentException("The market practice needs both its registry and its identification, or neither");
        }
    }

    /** A header with the two parties and the message type; everything else left out or taken from the message. */
    public static FisHeader of(List<Identifier> from, List<Identifier> to) {
        return new FisHeader(null, from, to, null, PAIN_001_V11, null, null, null, null);
    }

    public FisHeader withCharacterSet(@Nullable String value) {
        return new FisHeader(value, from, to, businessMessageIdentifier, messageDefinitionIdentifier,
                businessService, marketPracticeRegistry, marketPracticeIdentification, creationDate);
    }

    public FisHeader withBusinessMessageIdentifier(@Nullable String value) {
        return new FisHeader(characterSet, from, to, value, messageDefinitionIdentifier,
                businessService, marketPracticeRegistry, marketPracticeIdentification, creationDate);
    }

    public FisHeader withBusinessService(@Nullable String value) {
        return new FisHeader(characterSet, from, to, businessMessageIdentifier, messageDefinitionIdentifier,
                value, marketPracticeRegistry, marketPracticeIdentification, creationDate);
    }

    public FisHeader withMarketPractice(@Nullable String registry, @Nullable String identification) {
        return new FisHeader(characterSet, from, to, businessMessageIdentifier, messageDefinitionIdentifier,
                businessService, registry, identification, creationDate);
    }

    public FisHeader withCreationDate(@Nullable String value) {
        return new FisHeader(characterSet, from, to, businessMessageIdentifier, messageDefinitionIdentifier,
                businessService, marketPracticeRegistry, marketPracticeIdentification, value);
    }

    private static void requireText(@Nullable String value, String name) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("The FIS header needs a value for " + name);
        }
    }
}
