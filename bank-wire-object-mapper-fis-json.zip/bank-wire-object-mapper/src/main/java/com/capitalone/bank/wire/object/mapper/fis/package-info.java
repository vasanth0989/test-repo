/**
 * Phase 1 only: the pain.001.001.11 message as the JSON request of the FIS API.
 *
 * <p>The package stands on its own so that it can move to the service that calls FIS, or be deleted when
 * the FIS connection goes away, without touching the mapping to XML. Nothing outside this package refers
 * to it. It needs from the rest of the library only the generated message classes, the schema, and, for
 * {@link com.capitalone.bank.wire.object.mapper.fis.WirePaymentFisJson}, the mapper.
 *
 * <ul>
 *   <li>{@link com.capitalone.bank.wire.object.mapper.fis.FisJsonConverter}: message to FIS JSON;</li>
 *   <li>{@link com.capitalone.bank.wire.object.mapper.fis.FisHeader}: the header FIS wants around it;</li>
 *   <li>{@link com.capitalone.bank.wire.object.mapper.fis.WirePaymentFisJson}: stored payment object to FIS JSON in one call;</li>
 *   <li>{@link com.capitalone.bank.wire.object.mapper.fis.FisJsonConversionException}: the one way a conversion fails.</li>
 * </ul>
 *
 * <p>The names come from the resource {@code /fis/pain001-v11-fis-names.json}, which the build derives
 * from the pain.001.001.11 schema and the FIS contract.
 */
@NullMarked
package com.capitalone.bank.wire.object.mapper.fis;

import org.jspecify.annotations.NullMarked;
