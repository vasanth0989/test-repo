# bank-wire-object-mapper

Maps the Payment Exchange payment object (`SDPPayload`) for an outbound GPN or corporate wire to an
ISO 20022 **pain.001.001.11** customer credit transfer initiation, as schema-valid XML. Used inside
Wire Rail II, which receives the payment from the PayX integration service after OFAC, converts it with
this library, detokenises the account numbers, calls the FIS OPF API and returns OPF's HTTP code.

The XML is the Phase 2 asset: what Capital One will send to the banks directly once OPF is gone. For
Phase 1 the same message is converted to the FIS JSON (pain.001.001.11 with FIS's names, inside a
business application header) by the package `fis`, see "The FIS JSON (Phase 1 only)".

Java 21, Gradle, MapStruct, Jakarta XML Binding, Jackson. No Spring: the library is plain Java and is
wired into a Spring service as beans (`new Pain001V11Mapper(context)`, `new FisJsonConverter(header)`).

## Where the mapping is

The whole mapping is declared in one MapStruct interface, in the same style as the SWIFT mapper
(`bank-swift-object-mapper`):

```
src/main/java/com/capitalone/bank/wire/object/mapper/mappers/WireCreditTransferPain001V11.java
```

It reads top-down in message order, one method per ISO block: `Document`, `CstmrCdtTrfInitn`, `GrpHdr`,
`PmtInf`, `CdtTrfTxInf` (with `PmtId` and `PmtTpInf`), then the reusable types (party, postal address,
agent, financial institution, cash account). Every line names an ISO element and the payment-object
field it comes from:

```java
@Mapping(target = "pmtInfId", source = "clientTransactionId")
@Mapping(target = "pmtMtd", constant = "TRF")
@Mapping(target = "reqdExctnDt.dt", source = "valueDate", qualifiedByName = "valueDate")
@Mapping(target = "dbtr", source = "payer", qualifiedByName = "toParty")
@Mapping(target = "dbtrAcct", source = "payer", qualifiedByName = "toDebtorAccount")
@Mapping(target = "dbtrAgt", source = ".", qualifiedByName = "debtorAgent")
PaymentInstruction40 toPaymentInformation(SDPPayload payload, @Context MappingContext context);
```

- A plain `source` is a direct copy (trimmed; a blank value is never written).
- `constant` is a fixed value.
- `qualifiedByName` names a rule. A line with `source = "."` is derived from more than one field.
- An ISO element with no line is not written.

The rules are the `@Named` methods lower in the same interface. Each is a choice, a code translation or
a derived value and delegates to `util/WireMapperCommon`; single-value qualifiers (BIC, LEI, country,
currency, dates, UETR) are in `util/WireQualifierUtil`. MapStruct generates the implementation at
compile time (`build/generated/sources/annotationProcessor/.../WireCreditTransferPain001V11Impl.java`),
so what runs is ordinary Java that can be read and debugged.

## Build and run

```bash
./gradlew build            # generates the V11 classes from the XSD and the MapStruct implementation, runs the tests
./gradlew renderSamples    # maps every sample payment object to XML in build/samples and validates it
./gradlew renderSamples -Psample=gpn-usd-wire
./gradlew renderFisJson    # maps every sample and converts it to the FIS JSON in build/samples/fis-json, checked against the FIS contract
./gradlew renderFisJson -Psample=gpn-usd-wire
./gradlew renderFisJson -Pxml=path/to/message.xml     # converts pain.001.001.11 XML that already exists (a file or a folder)
./gradlew generateFisNameTable                        # rebuilds the XML tag to FIS JSON name table from the schema and the FIS contract
./gradlew publishToMavenLocal
```

The repositories are the Capital One Artifactory (`maven-auth`, `maven-internalfacing`), with the
credentials taken from the environment: `ARTIFACTORY_USERNAME` and `ARTIFACTORY_IDENTITY_TOKEN`. Put
the version of the payment object library in `~/.gradle/gradle.properties`:

```
payxPayloadVersion=2.16-beta
```

On a computer that cannot reach Artifactory, add `-I gradle/home.init.gradle` to any command
(`./gradlew test -I gradle/home.init.gradle`). It swaps the repositories for Maven Central and, when no
JDK 21 is installed, compiles with the JDK that runs Gradle. The build files themselves stay as they are.

`payxPayloadVersion` switches the payment object dependency to the real library
`com.capitalone.commercial:payx-payload` (2.16-beta, the version the Wire II integration service uses,
with its `jackson-databind` excluded as that service does). Without it the build uses
`payx-payload-local`, a stand-in written from the field lists of the 2.16-beta sources, with the same
package, class, field and accessor names (`com.capitalone.commercial.payx.sdp.payload.model`), limited
to the fields a wire uses. The library therefore builds and tests off the network, and code that
compiles against the stand-in compiles against the real jar. The module can be deleted once every build
uses the real artifact; nothing else references it.

Payload 2.16-beta has no `countryOfResidence`, `issuer`, `debtorAgentAccount`, `creditorAgentAccount` or
`tertiaryIntermediaryBank`, so the mapper does not write `CtryOfRes`, `Issr` or `IntrmyAgt3`, and takes
`DbtrAgtAcct` from `payerBank.bankAccountNumber` and `CdtrAgtAcct` from `payeeBank.bankAccountNumber`.
Each missing one is one more `@Mapping` line once the payload library carries the field. Two spellings to know in that version: the country of
birth is `customerPersonalInfo.countryofbirth` (lower case), and `Account` carries an
`accountHolderFullName`, which the mapper uses when `accountName` is blank.

A JDK 21 is used through the Gradle toolchain.

## Using it

```java
var context = new MappingContext(
        new MappingContext.InitiatingParty("Discover Bank", null, "US"),
        null,                                     // fixed debtor agent, used only when payerBank is absent
        null,                                     // initiation source (off by default)
        MappingContext.FisExtension.defaults(),   // instMethod, templateName, accountType, waiveFees
        Clock.systemUTC(),
        MappingRules.defaults());
var mapper = new Pain001V11Mapper(context);

String xml = mapper.mapToXml(payload);        // schema-validated pain.001.001.11
Document document = mapper.map(payload);      // the message in memory, for the FIS JSON (see below)
```

`Pain001V11Mapper` is the entry point. It validates the payment object, then calls the MapStruct mapper.
A payment that cannot be mapped throws `MappingException`. Its `problems()` list every reason at once,
each with the payment-object path that caused it (`payload.payee.accountNumber: is required`). Messages
never contain field values, so they are safe to log; the library itself logs nothing.

## How the payment object becomes pain.001

1. **Receive and validate** (`PayloadPreconditions`). Everything the schema makes mandatory and every
   length or format it enforces is checked against the payment object first: a message id of at most 35
   characters, a UETR that is a UUID v4, a value date in `yyyy-MM-dd`, a positive amount with an ISO
   currency, a payer and a payee each with an account number and a name, and the lengths and formats of
   every party, bank and address field. Any miss rejects the payment with the full list of reasons before
   anything is built.
2. **Group header.** Message id from `clientTransactionId`; creation time now, UTC, milliseconds; one
   transaction; control sum equal to the amount written; initiating party from the payment object when it
   has a name, otherwise the payer mapped as the initiating party (a rule can ask for the fixed party of the context instead).
3. **Payment information (debit side).** Payment information id from `clientTransactionId`; method TRF;
   no batch booking; requested execution date from `valueDate` as a date only; debtor from `payer`;
   debtor account from `payer`; debtor agent from `payerBank` as received.
4. **Credit transfer transaction (credit side).** Instruction id from `instructionId` and end-to-end id
   from `endToEndId`, each falling back to `clientTransactionId`; UETR from
   `swiftEndToEndTransactionReference`; priority HIGH; local instrument from `paymentTypeCode` converted
   to the ISO code; service level and category purpose when present; the amount; charge bearer from
   `chargedTo`; ultimate debtor from `ultimateDebtor`; two intermediary agents with their accounts;
   creditor agent from `payeeBank` as received, with its account; creditor and creditor account from
   `payee`; ultimate creditor; `bankToBank` as instructions for the creditor agent; purpose from
   `transactionReasonCd`; remittance information; the two FIS supplements.
5. **Amount and FX.** No `exchangeRate`: `InstdAmt` is `transactionAmount` in `currencyCode`. With a
   foreign currency and no debit amount: `InstdAmt` is `exchangeRate.instructedAmount` in the foreign
   currency. With both: `EqvtAmt` (the debit amount plus the currency of transfer) by default, or
   `InstdAmt` in the foreign currency when the rule says so. Rate, rate type (SPOT, SALE, AGRD) and
   contract id go to `XchgRateInf`. Amounts are rounded half-up to the currency's minor unit.
6. **XML.** The document is marshalled with JAXB and validated against `pain.001.001.11.xsd`, which is
   shipped inside the jar. The JSON rendering for FIS is the next step, in Wire Rail II.

## Mapping summary

The interface is the authority; this table is the same content for readers without the code open.

| pain.001.001.11 | Source in the payment object | Rule |
|---|---|---|
| GrpHdr/MsgId | clientTransactionId | copy |
| GrpHdr/CreDtTm | clock | UTC, milliseconds |
| GrpHdr/NbOfTxs, PmtInf/NbOfTxs | constant | 1 |
| GrpHdr/CtrlSum, PmtInf/CtrlSum | the amount written | equals InstdAmt or EqvtAmt/Amt |
| GrpHdr/InitgPty | initiatingParty, else the payer | party rule, on the initiating party when the payment object names one, otherwise on the payer. `header.initiatingPartyFallback` can ask for the fixed party of the context instead |
| GrpHdr/InitnSrc | context | off by default (not in the FIS samples) |
| PmtInf/PmtInfId | clientTransactionId | copy |
| PmtInf/PmtMtd, BtchBookg | constants | TRF, false |
| PmtInf/ReqdExctnDt/Dt | valueDate | strict yyyy-MM-dd, date only |
| PmtInf/Dbtr | payer | party rule |
| PmtInf/DbtrAcct | payer | IBAN when accountIdType is IBAN; else Othr/Id with no scheme; Tp/Cd from accountIdType (DDA to CACC, savings to SVGS, else OTHR); Ccy only when the account carries a currency |
| PmtInf/DbtrAgt | payerBank | agent rule, as received; when absent, the fixed agent of the context if configured, else an empty FinInstnId (the schema requires the element) |
| PmtInf/DbtrAgtAcct | payerBank.bankAccountNumber | Othr/Id, no scheme; written only when the payer bank carries an account number |
| CdtTrfTxInf/PmtId/InstrId | instructionId, else clientTransactionId | copy |
| CdtTrfTxInf/PmtId/EndToEndId | endToEndId, else clientTransactionId | copy |
| CdtTrfTxInf/PmtId/UETR | the field `identifiers.uetrSource` names: swiftEndToEndTransactionReference by default, or transactionId or traceNumber | lower-case UUID v4 |
| CdtTrfTxInf/PmtTpInf/InstrPrty | constant | HIGH |
| CdtTrfTxInf/PmtTpInf/LclInstrm | paymentTypeCode | BTRC to BTR, CTRC to CTR; BTR, CTR, DRC pass through; written as Cd |
| CdtTrfTxInf/PmtTpInf/SvcLvl, CtgyPurp | serviceLevelCd, categoryPurpose | ISO external code to Cd, otherwise Prtry |
| CdtTrfTxInf/Amt, XchgRateInf | transactionAmount, currencyCode, exchangeRate | see "Amount and FX" |
| CdtTrfTxInf/ChrgBr | chargedTo | as received: DEBT, CRED, SHAR, SLEV and the usual words for them; not written when absent; unknown rejected |
| CdtTrfTxInf/UltmtDbtr | ultimateDebtor | party rule |
| CdtTrfTxInf/IntrmyAgt1, IntrmyAgt2 (+Acct) | firstIntermediaryBank, secondaryIntermediaryBank | agent rule; account from bankAccountNumber |
| CdtTrfTxInf/CdtrAgt (+Acct) | payeeBank | agent rule, as received; omitted when absent; account from bankAccountNumber |
| CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI | payeeBank.swiftBankIdentifierCode | 8 or 11 characters |
| CdtTrfTxInf/CdtrAgt/FinInstnId/ClrSysMmbId | payeeBank.bankSystemIdentifier, payeeBank.bankCode | ClrSysId/Cd and MmbId |
| CdtTrfTxInf/CdtrAgt/FinInstnId/LEI, Nm | payeeBank.legalEntityIdentifier, payeeBank.bankName | optional |
| CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr | payeeBank.address | postal address rule; optional, written only when the address carries a value |
| CdtTrfTxInf/Cdtr | payee | party rule |
| CdtTrfTxInf/CdtrAcct | payee | IBAN, or Othr/Id with SchmeNm/Prtry "Proprietary" and no type; Ccy only when the account carries a currency |
| CdtTrfTxInf/UltmtCdtr | ultimateCreditor | party rule |
| CdtTrfTxInf/InstrForCdtrAgt | bankToBank | one InstrInf per line, each split at 140 |
| CdtTrfTxInf/Purp | transactionReasonCd | ISO external code to Cd, otherwise Prtry |
| CdtTrfTxInf/RmtInf/Ustrd | remitterInfo.unstructuredInfo | one per line; split at 140 by default |
| CdtTrfTxInf/RmtInf/Strd/Invcr, Invcee | remitterInfo.invoicerIdentification, invoiceeIdentification | Id/OrgId/Othr/Id |
| CdtTrfTxInf/SplmtryData | clientTransactionId | FIS transaction supplement: transactionTraceIdentification |
| CstmrCdtTrfInitn/SplmtryData | clientTransactionId, context | FIS payment information supplement: receipt and trace identification, extension block |

Reusable types:

| Type | Mapping |
|---|---|
| Party (Dbtr, Cdtr, UltmtDbtr, UltmtCdtr, InitgPty) | Nm from accountName, else accountHolderFullName, else the name parts; PstlAdr from address; Id as OrgId (organisation id number, LEI, BIC) or else PrvtId (identification number, date and place of birth), never both |
| Postal address (every party and every agent, including `payerBank.address` and `payeeBank.address`) | department to Dept, subDepartment to SubDept, streetName to StrtNm, buildingNumber to BldgNb, buildingName to BldgNm, floor to Flr, postalBox to PstBx, room to Room, postalCode to PstCd, city or townName to TwnNm, townLocationName to TwnLctnNm, districtName to DstrctNm, stateCode or stateProvince to CtrySubDvsn, countryCode to Ctry; addressLine1 to 4 as AdrLine; an address with no values is not written. Every field is optional. Only the payment object is read: an address held in the addendum is not picked up |
| Agent | BICFI from swiftBankIdentifierCode; ClrSysMmbId from bankCode with bankSystemIdentifier (a nine-digit code without one is USABA); LEI; Nm from bankName; PstlAdr from address |

Text rules everywhere: values are trimmed and blank values skipped; Max35Text identifiers, Max140Text
names and lines, Max70Text street names and address lines, Max16Text building numbers and post codes,
Max34Text account ids; over length is rejected by the validation step unless a policy says truncate or
split. Country codes are two letters upper case, BICs 8 or 11 characters, LEIs 20.

## The rules (`MappingRules`)

A rule exists only where a decision is still open with FIS or may differ per deployment.

| Rule | Default | Alternatives |
|---|---|---|
| identifiers.uetrRequired | true | false (the FIS API does not require a UETR) |
| identifiers.uetrSource | SWIFT_END_TO_END_TRANSACTION_REFERENCE | TRANSACTION_ID, TRACE_NUMBER |
| parties.addressStyle | STRUCTURED_AND_LINES | STRUCTURED_ONLY, LINES_ONLY |
| parties.namePolicy | REJECT over 140 | TRUNCATE |
| accounts.debtorScheme, debtorType | NONE, FROM_ACCOUNT_ID_TYPE (FIS samples) | BBAN or PROPRIETARY; CACC, NONE or PROPRIETARY_RAW |
| accounts.creditorScheme, creditorType | PROPRIETARY, NONE (FIS samples) | same |
| codes.localInstrumentStyle | EXTERNAL_CODE | PROPRIETARY |
| codes.chargeBearerPolicy | REJECT unknown | OMIT |
| codes.rateTypePolicy | REJECT unknown | OMIT |
| codes.inferUsabaFromNineDigitBankCode | true | false |
| amounts.fxAmountStyle | EQUIVALENT_AMOUNT | INSTRUCTED_AMOUNT_ONLY |
| texts.remittancePolicy | SPLIT | TRUNCATE, REJECT |
| texts.bankToBankSlashCleanup | false | true (TMOBS, TMOBSDOM, OBS senders: slashes become spaces) |
| header.emitInitiationSource | false | true |
| header.initiatingPartyFallback | PAYER | CONTEXT_PARTY (the fixed party of the context) |
| supplements.emitFisSupplements | true | false |

## The FIS sample requests

FIS provided four sample requests (bank transfer, customer transfer, customer transfer with an
intermediary agent, and a drawdown with structured and hybrid addresses and structured remittance). They
are bundled under `src/main/resources/samples/fis`, and each is rebuilt from a payment object under
`src/test/resources/samples/sdp/fis-*.json`; `FisSampleEquivalenceTest` checks the mapped message
against the FIS JSON value by value. What the samples settled:

- The payment type (BTR, CTR, DRC) is `localInstrument.code`, not proprietary.
- The debtor account is `other.identification` with no scheme and a `type.code` (OTHR or CACC); the
  creditor account is `other.identification` with `schemeName.proprietary: "Proprietary"` and no type.
  Neither carries a currency.
- The debtor agent is a BIC or a USABA member id; the intermediary agent is a USABA member id with no
  account; agents may carry a structured address and no name.
- Addresses are either address lines only or fully structured plus address lines; both pass.
- Remittance and instructions for the creditor agent repeat as arrays of short lines.
- Every request carries the two FIS supplements with the message id as trace id and an extension block
  (internationalPayment, instMethod, templateName, accountType, waiveFees).
- The samples carry no UETR and the drawdown carries no end-to-end id; the mapper writes the UETR and
  falls back to the message id for the end-to-end id, which the schema allows.
- The business application header (sender PaymentSystemId and CoreBankIdentifier, receiver OPF with an
  endPointName, market practice "FIS EP Universal Execution, 2022 Edition 3, SuppressCallBack:Test") is
  JSON-level and belongs to Wire Rail II.

Not reproduced because the payment object has no source for them: the garnishment block of the
structured remittance, and the names and addresses of the invoicer and invoicee (only their
identifications are mapped).

## The FIS JSON (Phase 1 only)

The FIS API (`POST /customer-credit-transfer-initiations`) takes the pain.001.001.11 message as JSON
with FIS's own long names, inside a business application header. The package
`com.capitalone.bank.wire.object.mapper.fis` does that conversion. It stands on its own: nothing outside
it refers to it, so it can move to the service that calls FIS, or be deleted in Phase 2, without touching
the mapping to XML.

### Using it

```java
// once, at start-up; both objects are thread-safe
var header = FisHeader.of(
                List.of(new FisHeader.Identifier("<our payment system id>", "paymentSystemId"),
                        new FisHeader.Identifier("<core bank id>", "coreBankIdentifier")),
                List.of(new FisHeader.Identifier("<FIS payment system id>", "paymentSystemId"),
                        new FisHeader.Identifier("<core bank id>", "coreBankIdentifier"),
                        new FisHeader.Identifier("<end point name>", "endPointName")))
        .withMarketPractice("FIS EP Universal Execution", "{#:2022 Edition 3}");
var converter = new FisJsonConverter(header);
var toFis = new WirePaymentFisJson(new Pain001V11Mapper(context), converter);

// per payment: the stored payment object (Base64) straight to the request body
String request = toFis.fromEncodedPaymentObject(encodedPaymentObject);

// or step by step
String sameRequest = converter.toJson(mapper.map(payload));   // from the message in memory
String fromXml = converter.toJson(xmlText);                   // from pain.001.001.11 XML text
String readable = converter.toPrettyJson(xmlText);            // laid out over lines, for people
```

Everything happens in memory: Base64 text to payment object, to the message, to JSON. No XML text is
produced on the way unless it is asked for, and no file is written. Account numbers are passed on as they
arrive.

In a Spring service the two objects are two beans; the header values come from the service configuration,
because the identifiers are agreed with FIS per environment.

### What the conversion does

| In the XML | In the FIS JSON |
|---|---|
| a tag, such as `GrpHdr` or `CdtTrfTxInf` | the name the FIS contract gives it: `groupHeader`, `creditTransferTransactionInformation` |
| a tag that may repeat (`PmtInf`, `AdrLine`) | a list, also when it is there once |
| a value | text, exactly as in the XML: dates and times are already ISO 8601 there, codes are plain text, sums and counts stay text |
| `true` or `false` (`BtchBookg`) | a JSON boolean |
| a value with an attribute: `<InstdAmt Ccy="USD">10.00</InstdAmt>` | an object: `{"amount": "10.00", "currency": "USD"}` |
| `SplmtryData` | an object; the envelope gains `schema`, which is the namespace of the supplement in the XML |
| nothing | the business application header, put around the message |

The header takes two values from the message unless they are set on the `FisHeader`: the business message
identifier is `GrpHdr/MsgId` and the creation date is `GrpHdr/CreDtTm`.

The same message always gives the same JSON, byte for byte: the properties come in the order of the
elements in the message, which is the order of the schema, and nothing depends on a clock, a random
number or the order of a hash map.

### Where the names come from

Nothing is typed by hand. The FIS contract keeps the type names of the ISO schema and lists the properties
of a type in the order the schema lists its elements, so the two are lined up type by type and position by
position. The result is the name table `src/main/resources/fis/pain001-v11-fis-names.json` (161 types,
626 names). `./gradlew generateFisNameTable` rebuilds it, and a test fails while the table and the
contract disagree. When FIS sends a new contract: replace `src/test/resources/fis/EP-POM-CCTI.json`, run
the task, read the difference in the table.

### Four names the contract does not agree with itself on

The schemas of the contract declare the properties `iBAN`, `bICFI`, `lEI` and `uetr`. The example
request inside the same contract, and FIS's sample requests, write `IBAN`, `BICFI` and `UETR`. The
schema of an account identification even declares `iBAN` and requires `IBAN`, so an IBAN account can
never be valid against the contract as published.

The converter writes these four as FIS writes them in its own requests (`IBAN`, `BICFI`, `LEI`,
`UETR`). The tests check the output against the contract with those four names read that way.
`converter.withContractNames()` switches to the schema spelling, and `converter.withName(type, tag, name)`
changes a single name. Which spelling the API accepts is a question for FIS (below).

### When it fails

The message is checked against the pain.001.001.11 schema first. Any problem, there or in the conversion,
ends in a `FisJsonConversionException` whose `problems()` list every problem with its place in the XML
(`Document/CstmrCdtTrfInitn/PmtInf[1]/CdtTrfTxInf[1]/...`). A partial request is never returned.
`WirePaymentFisJson` adds two more: `IllegalArgumentException` when the text is not a payment object, and
the mapper's `MappingException` when the payment cannot be mapped.

### What the tests show

| Check | Test |
|---|---|
| Every golden XML gives its golden JSON, byte for byte (`src/test/resources/golden/fis-json`) | `FisJsonGoldenTest` |
| Every golden JSON is valid against the FIS contract | `FisJsonGoldenTest`, `FisContract` |
| The names and their casing are the contract's | `FisNameTableTest` |
| Dates are ISO 8601 text, supplementary data is an object, codes are plain text | `FisJsonConverterTest` |
| The same XML gives the same bytes; the message in memory and its XML text give the same bytes | `FisJsonConverterTest` |
| A failure is an error with every problem listed, never part of a request | `FisJsonConverterTest` |
| Each request FIS wrote itself, read as XML and converted, comes out as FIS wrote it | `FisSamplesTest` |
| Our customer transfer against FIS's customer transfer sample: same structure, every difference listed | `FisSamplesTest` |
| Stored payment object (Base64) to the request in one call | `WirePaymentFisJsonTest` |

Refresh the golden JSON after a deliberate change, and read the difference before committing it:

```bash
./gradlew renderFisJson -Pxml=src/test/resources/golden -PoutDir=src/test/resources/golden/fis-json
```

### Questions for FIS from this work

1. `IBAN`, `BICFI`, `LEI`, `UETR`: the schemas of the contract spell them `iBAN`, `bICFI`, `lEI`,
   `uetr`; the example in the contract and the sample requests spell them in capitals. Which does the API
   accept?
2. The drawdown sample has no end-to-end identification, which the contract requires. Is the sample out of
   date, or is the field optional for drawdowns?
3. The header: which identifiers go in `from` and `to` for our environments, and may the business message
   identifier be the message identification of the group header?

## What is not in this library, and why

- **The call to FIS.** The library builds the request body. The HTTP call, its headers (`uuid`,
  `idempotency-key`), retries and the response belong to the service.
- **The old placeholder.** `pain001/v11/json/Pain001V11JsonRenderer` still throws, as before; the package
  `fis` replaces it. It can be deleted together with the one test that expects it to throw; its
  `sample(...)` helper is used by two tests.
- **Detokenisation.** Account numbers arrive tokenised; Wire Rail II detokenises them through Turing.
  The mapper copies what it is given.
- **On-behalf-of payer.** In the existing PIE flow `onBehalfOfPayer` feeds the debtor agent. That is
  specific to PIE and is not expected on Discover's wires, so it is not mapped.
- **PIE supplementary data.** The V9 converter wrote a PIE-specific client-data envelope (FX debit
  currency and amount, initiator, approver). OPF does not read it; it is not written.
- **Garnishment and referred documents.** No source in the payment object.
- **Address standardisation.** The V9 converter called the ACE address service for one channel and
  payment type and blanked structured agent addresses as a PIE work-around. Neither is carried over.
- **Correspondent and instructing agents, clearing references, message format.** They belong to the
  clearing leg (pacs.008), not to pain.001.
- **Payment status, returns, ACH, card, RTP and letter fields** of the payment object are not read.

## Mapping decisions

Settled in the mapping review and implemented:

1. **Local instrument.** Payment Exchange issues BTRC and CTRC; BKP and NOS are not possible through the
   external API. BTR, CTR and DRC are ISO external local instrument codes, so the conversion from the
   Payment Exchange code to the ISO code is done in this layer.
2. **Agents.** The wire layer adds no agent of its own. An ordinary outbound wire carries a creditor
   agent and no debtor agent; a drawdown carries a debtor agent and no creditor agent. Whatever the
   payment object carries is mapped.
3. **Charge bearer and rate type.** Mapped from the payment object as received; nothing is hard-coded or
   defaulted.
4. **Names.** A name over 140 characters is already rejected by the external API; the mapper rejects
   too and never truncates by default.
5. **Ultimate debtor.** Mapped from `ultimateDebtor` only; there is no precedence with
   `onBehalfOfPayer`, which is not mapped.
6. **Initiating party.** From the payment object when it names one; otherwise the payer is mapped as the
   initiating party, by the same party rule (name, address, identification). It is a required ISO element,
   so it is never left out. FIS's sample requests name the bank here, not the payer;
   `header.initiatingPartyFallback = CONTEXT_PARTY` gives that form.
7. **Debtor agent account.** From the payer bank's account number, as the creditor agent account is from
   the payee bank's. Accounts of the intermediary agents are written the same way.
8. **No third intermediary.** The external API does not accept one, so none is mapped.
9. **Values changed after the wire was created** (value date, BIC, clearing code, banks) are applied by
   Payment Exchange before it calls; the mapper reads the payment object only.
10. **Every problem at once.** An unknown charge bearer is found in the first checks, together with every
   other problem of the payment, not later while the message is built.

## Open questions

### Mapping decisions still open

1. The Payment Exchange payment type code for a drawdown is not defined yet; DRC is expected.
2. Account type: the FIS samples carry `Tp/Cd` (CACC, OTHR), while existing PIE messages carry the
   account id type as `Tp/Prtry` (DDA, IBAN). The default follows the FIS samples; the proprietary form
   is one rule away.
3. Which payment-object fields carry the message id, payment information id, instruction id and
   end-to-end id for GPN and corporate wires, and who generates them.
4. Whether `onBehalfOfPayer` can occur on Discover's wires at all.
5. How the debtor and creditor agents arrive for a drawdown, and whether an empty debtor agent on an
   ordinary wire is acceptable to OPF.
6. The exact `chargedTo` values the channels send; the mapper accepts the ISO codes and the words
   originator, beneficiary and shared.
7. **Which field carries the UETR, and whether it is required.** Nothing upstream fills
   `swiftEndToEndTransactionReference` for a wire from the external API; its payment id is to be carried in
   the transaction id or the trace number. Until that is settled the field is a rule
   (`identifiers.uetrSource`), and with the default every such wire is rejected for the missing UETR.
8. **Which bank the debtor agent names on a credit transfer.** The payer bank is expected on drawdowns
   only, so an ordinary wire arrives without one and gets the fixed agent of the context, or an empty one.
9. **Where the source channel goes.** OPF needs it for reconciliation; the sender member id is in the
   payment object and is not written anywhere yet. `GrpHdr/InitnSrc` is a possible place, not confirmed.
10. **Bank drawdown request (DRB).** The code passes through like DRC; which parties and agents it must
   carry has not been said.
11. **Which currency is which on an FX wire.** The mapper reads `currencyCode` as the currency debited and
   `foreignExchangeCurrencyCode` as the currency sent; the mapping sheet of the external API reads them the
   other way round.
12. **The international flag** of the FIS supplement is worked out from the currency, so a dollar wire to a
   bank abroad gets N. Whether the flag means a foreign currency or a wire that leaves the country is a
   question for FIS.

### Questions for FIS

7. Does OPF accept `EqvtAmt` for FX wires, or only `InstdAmt`?
8. Which address form does OPF require per rail (structured, hybrid, address lines), and does it reject
   structured fields combined with address lines?
9. Is `InstrForCdtrAgt/InstrInf` the right carrier for bank-to-bank text, and what chunking and line
   markers does OPF expect?
10. Does OPF require a BIC for GPN agents? (The clearing system codes themselves come from the ISO
    external code list.)
11. Does OPF read `InitnSrc` or any supplementary data beyond its own two envelopes?
12. Which V11 elements survive OPF's conversion to pain.001 V3 for the correspondent banks? This goes
    hand in hand with the address question.
13. Does OPF keep the UETR Capital One sends all the way to the network? V3 carries the end-to-end id
    rather than a UETR, and the samples carry none.
14. The extension block of the payment information supplement: what do instMethod ("Person"),
    accountType ("Consumer", "consumer"), templateName and waiveFees mean for Discover's wires, and which
    values does OPF expect from Capital One?
15. The creditor account scheme "Proprietary" and the debtor account type OTHR versus CACC: are these
    validated, and does OPF accept ISO codes instead?
16. Drawdown requests (DRC): the sample has no end-to-end id; is one required for Discover?
17. The invoicee address in the drawdown sample uses "stateOrProvince", which is not in the API
    specification; it looks like an older sample, with `countrySubDivision` the intended element.

Whether service level, category purpose, purpose, regulatory reporting and the date precision of the
requested execution date are required is answered by the API specification and needs no question.

## Samples and tests

`src/test/resources/samples/sdp` holds nine payment objects:

| Sample | What it covers |
|---|---|
| fis-bank-transfer | the FIS bank transfer sample (BTR): BIC debtor agent, OTHR account type, two remittance lines, two instructions |
| fis-customer-transfer | the FIS customer transfer sample (CTR): USABA agents, CACC debtor account |
| fis-intermediary-customer-transfer | the FIS customer transfer with intermediary sample (CTR): BIC debtor agent, USABA intermediary agent 1 without an account, two remittance lines, two instructions |
| fis-drawdown-structured | the FIS drawdown sample (DRC): structured and hybrid addresses on every party and agent, ultimate parties, intermediary agent, invoicer and invoicee |
| gpn-usd-wire | domestic USD wire with the Payment Exchange code CTRC, USABA agents, organisation id, category purpose, remittance, long bank-to-bank text |
| corp-fx-eur-wire | USD-to-EUR wire with equivalent amount and exchange rate, LEI, BIC agents, IBAN creditor, intermediary agent, address lines, remittance split |
| corp-on-behalf-of-wire | composed personal name, private identification with date and place of birth, creditor agent account, ultimate creditor, an on-behalf-of party that is not mapped |
| fx-instructed-amount-only | FX wire with no debit amount: instructed amount in JPY rounded to no decimals, BIC-only agents |
| invalid-missing-required-fields | rejected with seven reasons at once |

`src/test/resources/golden` holds the XML of the eight valid samples with a fixed creation time; the
golden test compares the full output. After a deliberate mapping change, regenerate them with
`./gradlew renderSamples -Pclock=fixed` and copy `build/samples/*.xml` over after reviewing the diff.

## Layout

```
build.gradle, settings.gradle          Gradle 9, Java 21 toolchain, XSD code generation, MapStruct, the renderSamples,
                                       renderFisJson and generateFisNameTable tasks
gradle/home.init.gradle                for building where Artifactory cannot be reached
payx-payload-local/                    stand-in for the payment object library (off-network builds only)
src/main/resources/xsd/                pain.001.001.11.xsd (also shipped in the jar for validation)
src/main/resources/samples/fis/        the four FIS sample requests, the example from the FIS contract, and the request used for the Code Connect connectivity test
src/main/java/com/capitalone/bank/wire/object/mapper/
  mappers/                             WireCreditTransferPain001V11: the MapStruct mapping, all in one interface
  util/                                WireQualifierUtil (value qualifiers), WireMapperCommon (choices, code tables, amounts, supplements)
  pain001/v11/                         Pain001V11Mapper (entry point), MappingContext, MappingRules,
                                       PayloadPreconditions (validation), Pain001V11Marshaller
  pain001/v11/json/                    Pain001V11JsonRenderer (the old placeholder; replaced by fis/)
  fis/                                 Phase 1 only: FisJsonConverter (message to FIS JSON), FisHeader,
                                       WirePaymentFisJson (stored payment object to FIS JSON), FisJsonConversionException
src/main/resources/fis/                the name table: XML tag to FIS JSON name, derived from the schema and the FIS contract
src/test/resources/fis/                the FIS contract (OpenAPI), for the tests and the name table
src/test/resources/golden/fis-json/    the golden FIS JSON of the eight valid samples
  common/                              Text, IsoDates, Amounts, MappingException, MappingProblem, Problems
  generated/pain001v11/                generated at build time from the XSD (not in the repository)
src/test/                              tests, sample payment objects, golden XML, SampleRenderer
docs/                                  payment object inventory, field mapping analysis, V11 element tree
```
