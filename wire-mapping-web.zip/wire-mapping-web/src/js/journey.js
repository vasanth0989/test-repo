// The opening of the trainer: where a wire starts, and how it travels to the rail.
// The wire form is an illustration: the real channel screens are not on the shelf. Each box is
// defined by the payload field it fills, and the payload and the message beside it are real cases.
(function () {
  const WT = window.WT; const h = WT.h; const C = WT.content; const V = WT.views;

  // ---- the form: sections and boxes, each box named the way wire people name it
  C.form = [
    { title: 'The wire', boxes: [['Wire type', 'paymentTypeCode'], ['Amount', 'transactionAmount'], ['Currency', 'currencyCode'], ['Value date', 'valueDate'], ['Charges paid by', 'chargedTo'], ['Service level', 'serviceLevelCd']] },
    { title: 'From: the originator', boxes: [['Name', 'payer.accountName'], ['Title', 'payer.accountPrefixName'], ['First name', 'payer.accountFirstName'], ['Middle name', 'payer.accountMiddleName'], ['Last name', 'payer.accountLastName'], ['Account number', 'payer.accountNumber'], ['Account type', 'payer.accountIdType'], ['Account currency', 'payer.currencyCode'], ['Address', 'payer.address'], ['Company id', 'payer.organizationIdentificationNumber'], ['Kind of company id', 'payer.organizationIdentificationNumberType'], ['LEI', 'payer.legalEntityIdentifier'], ['Personal id', 'payer.identificationNumber'], ['Kind of personal id', 'payer.identificationNumberType'], ['Date of birth', 'payer.customerPersonalInfo.dateOfBirth'], ['City of birth', 'payer.customerPersonalInfo.cityOfBirth'], ['Country of birth', 'payer.customerPersonalInfo.countryofbirth']] },
    { title: 'The originator\'s bank', boxes: [['Bank name', 'payerBank.bankName'], ['Routing number or bank code', 'payerBank.bankCode'], ['Clearing system', 'payerBank.bankSystemIdentifier'], ['BIC', 'payerBank.swiftBankIdentifierCode'], ['Address', 'payerBank.address']] },
    { title: 'To: the beneficiary', boxes: [['Name', 'payee.accountName'], ['Account number', 'payee.accountNumber'], ['Kind of account number', 'payee.accountIdType'], ['Account currency', 'payee.currencyCode'], ['Address', 'payee.address']] },
    { title: 'The beneficiary\'s bank', boxes: [['Bank name', 'payeeBank.bankName'], ['Routing number or bank code', 'payeeBank.bankCode'], ['Clearing system', 'payeeBank.bankSystemIdentifier'], ['BIC', 'payeeBank.swiftBankIdentifierCode'], ['LEI', 'payeeBank.legalEntityIdentifier'], ['Its own account at the next bank', 'payeeBank.bankAccountNumber'], ['Address', 'payeeBank.address']] },
    { title: 'Intermediary bank', boxes: [['Bank name', 'firstIntermediaryBank.bankName'], ['Routing number or bank code', 'firstIntermediaryBank.bankCode'], ['Clearing system', 'firstIntermediaryBank.bankSystemIdentifier'], ['BIC', 'firstIntermediaryBank.swiftBankIdentifierCode'], ['Its own account at the next bank', 'firstIntermediaryBank.bankAccountNumber'], ['Address', 'firstIntermediaryBank.address']] },
    { title: 'Second intermediary bank', boxes: [['Bank name', 'secondaryIntermediaryBank.bankName'], ['BIC', 'secondaryIntermediaryBank.swiftBankIdentifierCode']] },
    { title: 'Paying on behalf of', boxes: [['Name', 'ultimateDebtor.accountName'], ['Address', 'ultimateDebtor.address']] },
    { title: 'Final beneficiary', boxes: [['Name', 'ultimateCreditor.accountName'], ['Address', 'ultimateCreditor.address']] },
    { title: 'Requested by', boxes: [['Name', 'initiatingParty.accountName'], ['Address', 'initiatingParty.address']] },
    { title: 'On-behalf-of payer', boxes: [['Name', 'onBehalfOfPayer.accountName'], ['Company id', 'onBehalfOfPayer.organizationIdentificationNumber'], ['Kind of company id', 'onBehalfOfPayer.organizationIdentificationNumberType']] },
    { title: 'Exchange', boxes: [['Rate', 'exchangeRate.exchangeRate'], ['Rate type', 'exchangeRate.foreignExchangeTrade'], ['Currency to send', 'exchangeRate.foreignExchangeCurrencyCode'], ['Amount to send', 'exchangeRate.instructedAmount'], ['FX contract', 'exchangeRate.contractId']] },
    { title: 'Details', boxes: [['Reference for the beneficiary', 'endToEndId'], ['Purpose', 'transactionReasonCd'], ['Kind of payment', 'categoryPurpose'], ['Payment details', 'remitterInfo.unstructuredInfo'], ['Invoice issued by', 'remitterInfo.invoicerIdentification'], ['Invoice issued to', 'remitterInfo.invoiceeIdentification'], ['Document type', 'remitterInfo.documentCode'], ['Document number', 'remitterInfo.documentProprietary'], ['Message to the beneficiary\'s bank', 'bankToBank'], ['Local instrument', 'localInstrumentCode']] },
  ];
  // ---- payload fields nobody types: what they are, and where they come from
  C.added = {
    clientTransactionId: { label: 'Sender\'s reference', keyed: 'Set by the channel when the wire is created.', gateway: 'From the request: its partner payment reference.' },
    instructionId: { label: 'Instruction id', keyed: 'An id for this instruction, set on the way in.' },
    swiftEndToEndTransactionReference: { label: 'UETR', keyed: 'Who creates it is not settled. Proposed: the payment id the front door generates. Keyed wires need their own source.', gateway: 'No field of the request fills it. A wire from the gateway arrives without it today, and the mapper rejects such a wire. Proposed: the payment id the front door generates.', open: true },
    messageTransmissionId: { label: 'Transmission id', keyed: 'Payment Exchange\'s own id for the transmission.' },
    transactionId: { label: 'Transaction id', keyed: 'Payment Exchange\'s own id for the transaction.' },
    // fields that only the real wires from UAT carry
    traceNumber: { label: "Trace number", keyed: "Not typed by anyone: set by the sending channel." },
    "payer.accountHolderFullName": { label: "Full name of the account holder", keyed: "Not typed by anyone: set by the sending channel." },
    "payer.customerId": { label: "Customer number", keyed: "Not typed by anyone: looked up for the payer's account." },
    "payer.sorId": { label: "System id of the account", keyed: "Not typed by anyone: looked up for the payer's account." },
    "payer.customerPersonalInfo": { label: "Personal details", keyed: "Not typed by anyone: sent as null in the real payloads." },
    "payee.accountHolderFullName": { label: "Full name of the account holder", keyed: "Not typed by anyone: set by the sending channel." },
    "payee.customerPersonalInfo": { label: "Personal details", keyed: "Not typed by anyone: sent as null in the real payloads." },
    "additionalInfoByChannel.destinationType": { label: "Kind of receiver", keyed: "Not typed by anyone: set by the sending channel." },
    "additionalInfoByChannel.feeAmount": { label: "Fee", keyed: "Not typed by anyone: set by the sending channel." },
    paymentStatus: { label: "Payment status", keyed: "Not typed by anyone: set by Payment Exchange." },
    "onBehalfOfPayer.accountNumber": { label: "On-behalf-of account", keyed: "Not typed by anyone: set by the sending channel." },
    "onBehalfOfPayer.accountIdType": { label: "Kind of on-behalf-of account", keyed: "Not typed by anyone: set by the sending channel." },
    "onBehalfOfPayer.address": { label: "On-behalf-of address", keyed: "Not typed by anyone: set by the sending channel." },
    "onBehalfOfPayer.customerPersonalInfo": { label: "Personal details", keyed: "Not typed by anyone: sent as null in the real payloads." },
    "ultimateCreditor.customerPersonalInfo": { label: "Personal details", keyed: "Not typed by anyone: sent as null in the real payloads." },
    "ultimateDebtor.customerPersonalInfo": { label: "Personal details", keyed: "Not typed by anyone: sent as null in the real payloads." },
    paymentType: { label: 'Route', keyed: 'Says which route the wire takes: Frb for the Fed, Nos for SWIFT.' },
    clearingSystem: { label: 'Network', keyed: 'A network name that only the samples of the mapper carry. A real payload has no such field.' },
    paymentSourceChannelId: { label: 'Channel', keyed: 'The channel the wire came in through.' },
    'supplementaryData.initiatorId': { label: 'Keyed by', keyed: 'Who keyed the wire.' },
    'supplementaryData.approverId': { label: 'Approved by', keyed: 'Who approved the wire.' },
    'optionalHeaderInfo.senderMemberId': { label: 'Sender member id', keyed: 'The value of the keying channel. HERA picks the saga by it.', gateway: 'Set from the source of the request, such as PULSE-WIRE or MP-ACQ. HERA picks the saga by it.' },
  };
  C.friendly = { CTRC: 'Customer transfer', BTRC: 'Bank transfer', CTR: 'Customer transfer', BTR: 'Bank transfer', DRC: 'Drawdown request', SHAR: 'Shared', DEBT: 'The originator', CRED: 'The beneficiary', OUR: 'The originator', BEN: 'The beneficiary', SHA: 'Shared', DDA: 'Checking', SAV: 'Savings', IBAN: 'IBAN', USABA: 'US routing number', SPOT: 'Spot rate', AGRD: 'Agreed rate', SALE: 'Sale rate' };
  // ---- the stops on the way, for each of the two ways a wire starts
  const hera = (which) => ({ t: 'HERA builds the payment object', shape: 'The SDP payload', col: 'payload', say: ['HERA checks the wire against the wire schema and turns it into the payment object: the SDP payload.', which] });
  const tail = [
    { t: 'Payment Exchange runs its stages', shape: 'The SDP payload', col: 'payload', say: ['INIT, CLIENTREGISTRY, BANKVALIDATION, ACCOUNTQUALIFICATION, then OFAC screening. For screening it builds its own pain.001 in version 9, the only version the screening engine reads.', 'A sanctions hit stops the wire for an analyst. Only a wire that passes goes on to the rail.'] },
    { t: 'Wire II builds the message', shape: 'pain.001', col: 'xml', say: ['Payment Exchange calls the rail with the payment object in plain text and three ids: payment lifecycle id, exchange object id and saga type. Values changed after the wire was created are already applied. The rail maps the payment object to pain.001 version 11: the mapping you are learning.', 'It stores the request, answers at once, and sends the message to OPF in the background. When OPF has answered, it calls Payment Exchange back with the request as it received it, plus the result.'] },
    { t: 'OPF and the bank', shape: 'JSON to FIS', col: 'xml', say: ['The message goes to FIS as JSON over an API. OPF routes it, sets the value date and delivers it to the bank. The banks see no change.', 'How every tag of the message is written in that JSON is on the screen "To FIS JSON".'] },
  ];
  C.journey = {
    keyed: { title: 'Keyed by an operator', sub: 'a corporate wire', formTitle: 'Wire entry screen', stops: [
      { t: 'An operator keys the wire', shape: 'A screen', col: 'form', say: ['Corporate wires are keyed by operations staff in OnePay. It takes this job over from the PO screens of OPF.', 'The operator works from an instruction: who pays, who is paid, how much, when and why.'] },
      { t: 'The wire is verified', shape: 'A screen', col: 'form', say: ['OnePay has a verification queue: a keyed wire is checked before it goes on.', 'The payment object can carry who keyed the wire and who approved it. Neither reaches pain.001.'] },
      hera('It picks the saga by the sender member id. The value of the keying channel leads to the corporate wire saga. As designed; not built yet.'), ...tail] },
    gateway: { title: 'Sent by the Payment Network Gateway', sub: 'a network wire', formTitle: 'API request', stops: [
      { t: 'The gateway sends the wire', shape: 'An API request', col: 'form', say: ['Discover\'s Payment Network Gateway creates wires from its settlement files. No person types anything.', 'It makes one API call per wire to Capital One, with the account numbers encrypted.'] },
      { t: 'The front door checks it', shape: 'An API request', col: 'form', say: ['The external payment API checks the caller, refuses a repeat by its idempotency key and swaps both account numbers for tokens. It validates every field itself, because HERA drops a field it does not know without a word.', 'It answers with a payment id, which the caller uses to ask for the status. The idempotency key stays here; it does not reach the payload.'] },
      hera('It picks the saga by the sender member id: PULSE and the other gateway senders lead to the network wire saga, a drawdown type to the drawdown saga. As designed; not built yet.'), ...tail] },
  };

  // ---- the left column of one case: what a person keys (an illustration), or what the gateway sends
  // (the real request fields, from the mapping sheet in data/external-map.json), and the payload
  // fields that neither of them supplies
  const addr = (p) => { const i = p.indexOf('.address.'); return i > 0 ? p.slice(0, i) + '.address' : p; };
  // how the request spells a value that the external API changes on the way in
  const BACK = {
    paymentTypeCode: { CTRC: 'CUSTOMER_CREDIT_TRANSFER', BTRC: 'BANK_TRANSFER', DRC: 'CUSTOMER_DRAWDOWN_REQUEST', DRB: 'BANK_DRAWDOWN_REQUEST' },
    paymentType: { Frb: 'FED', Nos: 'SWIFT' }, chargedTo: { SHAR: 'SHARED', DEBT: 'ORIGINATOR', CRED: 'BENEFICIARY' },
    accountIdType: { DDA: 'BANK_ACCOUNT_NUMBER', IBAN: 'INTERNATIONAL_BANK_ACCOUNT_NUMBER' }, foreignExchangeTrade: { AGRD: 'AGREED' },
  };
  WT.formModel = function (c, way) {
    const ids = [...new Set(c.fields.map((f) => addr(f.p)))];
    const count = (id) => c.fields.filter((f) => addr(f.p) === id).length;
    const val = (id) => (id.endsWith('.address') ? count(id) + ' fields' : id.split('.').reduce((a, k) => (a == null ? a : a[k]), c.payload));
    const real = way === 'gateway' && !!WT.S.external;
    const boxes = [];
    if (real) {
      const X = WT.S.external.fields;
      const targets = (f) => (f.payload.length ? f.payload : /^[a-zA-Z][\w.]*$/.test(f.janus) ? [f.janus] : []);
      for (const id of ids) {
        let row = X.find((f) => targets(f).includes(id)); const group = !row && id.endsWith('.address');
        if (group) row = X.find((f) => targets(f).some((t) => t.startsWith(id + '.')));
        if (!row) continue;
        const ext = group ? row.ext.slice(0, row.ext.indexOf('.address') + 8) : row.ext;
        const same = boxes.find((b) => b.ext === ext);          // one request field can fill two payload fields
        if (same) { same.ids.push(id); continue; }
        const raw = val(id); const key = id.split('.').pop();
        const v = group ? raw : key === 'accountNumber' ? 'sent encrypted' : (BACK[key] && BACK[key][raw]) || raw;
        boxes.push({ id, ids: [id], ext, label: ext.includes('.') ? ext.split('.').slice(1).join('.') : ext, section: ext.includes('.') ? ext.split('.')[0] : 'the wire', v, group, row: row.row, note: group ? '' : row.note, changed: !group && WT.fmt(v) !== WT.fmt(raw) });
      }
      boxes.sort((a, b) => a.row - b.row);
    } else {
      for (const sec of C.form) for (const [label, id] of sec.boxes) if (ids.includes(id)) boxes.push({ id, ids: [id], label, section: sec.title, v: val(id), group: id.endsWith('.address') });
    }
    const onForm = new Set(boxes.flatMap((b) => b.ids));
    const system = ids.filter((id) => !onForm.has(id)).map((id) => {
      const a = C.added[id] || {};
      const note = (way === 'gateway' && a.gateway) || a.keyed || (real ? 'The external API request has no field for this. A wire from the gateway arrives without it; this sample carries it all the same.' : 'Added on the way in.');
      return { id, ids: [id], label: a.label || id.split('.').pop(), v: val(id), note, open: !!a.open, missing: real && !C.added[id] };
    });
    return { boxes, system, real, sections: [...new Set(boxes.map((b) => b.section))] };
  };
  WT.show = (v) => { const s = WT.fmt(v); return C.friendly[s] ? C.friendly[s] + ' (' + s + ')' : s; };

  // ---------------------------------------------------------------- the screen
  V.journey = function (main, p) {
    const way = p.way || 'keyed'; const kind = p.kind || (way === 'gateway' && WT.original('gateway') ? 'gateway' : 'customer');
    const c = WT.original(kind); const J = C.journey[way]; WT.journeyWay = way;
    // version 9 is the same mapping written as pain.001.001.09, without the supplementary data, which is for FIS only
    const V9 = WT.S.v9 && WT.S.v9.cases[c.id] ? WT.S.v9.cases[c.id] : null;
    const ver = WT.journeyVer === '9' && V9 && V9.msg ? '9' : '11';
    const cc = ver === '9' ? Object.assign({}, c, { leaves: V9.msg.leaves, fields: V9.msg.fields }) : c;
    const f = WT.formModel(c, way); const m = WT.model(cc, null); WT.infoCase = cc;
    const boxOf = (id) => f.boxes.find((b) => b.ids.includes(id)) || f.system.find((b) => b.ids.includes(id));
    const slotsOf = (id) => m.slots.filter((s) => s.src.includes(id));
    const el = { box: {}, field: {}, slot: {} };

    const boxNode = function (b, cls) {
      const n = h('button', { class: 'box' + cls, type: 'button', data: { id: b.id, ids: b.ids.join(','), info: 'field:' + b.id, infomode: 'full' } }, h('span', { class: 'l' }, b.label), h('span', { class: 'i' }, WT.short(f.real || cls ? WT.fmt(b.v) : WT.show(b.v), 40)));
      for (const id of b.ids) el.box[id] = n;
      return n;
    };
    const formCol = h('div', { class: 'col jcol form' + (f.real ? ' real' : '') }, h('h3', {}, J.formTitle, h('em', {}, f.real ? 'field names from the mapping sheet' : 'an illustration')),
      f.sections.map((s) => h('fieldset', {}, h('legend', {}, s), f.boxes.filter((b) => b.section === s).map((b) => boxNode(b, '')))),
      f.system.length ? h('fieldset', { class: 'sys' }, h('legend', {}, f.real ? 'In the payload, with no field in the request' : 'Not typed by anyone: added on the way in'),
        f.system.map((b) => boxNode(b, ' sys' + (b.open ? ' open' : '') + (b.missing ? ' missing' : '')))) : null);
    const groups = []; for (const ch of m.chips) { const g = ch.id.includes('.') ? ch.id.split('.')[0] : 'top level'; let e = groups.find((x) => x.g === g); if (!e) groups.push(e = { g, chips: [] }); e.chips.push(ch); }
    const payCol = h('div', { class: 'col jcol payload' }, h('h3', {}, 'SDP payload', h('em', {}, 'the payment object')),
      groups.map((g) => h('section', { class: 'grp' }, h('h4', {}, g.g), g.chips.map((ch) => (el.field[ch.id] = h('button', { class: 'line' + (ch.mapped || slotsOf(ch.id).length ? '' : ' dead'), type: 'button', data: { id: ch.id, info: 'field:' + ch.id, infomode: 'full' } },
        h('span', { class: 'k' }, ch.id.includes('.') ? ch.id.split('.').slice(1).join('.') : ch.id), h('span', { class: 'v' }, WT.short(WT.fmt(ch.v), 30))))))));
    // version 11 against version 9: a mark on each row that differs, and above the rows the new elements the mapper does not write
    const vmark = (p) => { const v = WT.v11Of(p); return v ? h('span', { class: 'vtag ' + v.kind }, WT.v11Label(v.kind)) : null; };
    const xmlRows = WT.rows(m.slots);
    const V11 = WT.content.v11; const v11List = h('div', { class: 'v11list' }); v11List.innerHTML = V11.map((v) => WT.v11Html(v, true)).join('');
    const v11Bar = h('details', { class: 'v11bar' },
      h('summary', {}, h('b', {}, 'Version 11 compared with version 9'), h('span', {}, V11.length + ' differences in the whole message. ' + V11.filter((v) => v.touches).length + ' in what a wire sends.')),
      h('p', {}, 'From the two official schemas, compared element by element. A row below that differs carries ', h('span', { class: 'vtag changed' }, 'changed in V11'), '.'),
      v11List);
    // the switch sits in the heading of the message column. Changing it draws the screen again where it stands.
    const setVer = function (v) { WT.journeyVer = v; const top = main.scrollTop; V.journey(main, p); main.scrollTop = top; window.dispatchEvent(new Event('resize')); };
    const verSeg = h('div', { class: 'seg vseg', role: 'group', 'aria-label': 'Version of pain.001' }, ['11', '9'].map((v) => h('button', { class: 'segb' + (v === ver ? ' on' : ''), type: 'button', 'aria-pressed': String(v === ver), data: { ver: v }, onclick: () => setVer(v) }, 'V' + v)));
    const nsLine = h('div', { class: 'nsline' + (ver === '9' ? ' alt' : '') }, h('span', { class: 'tag' }, 'Document'), h('code', {}, 'urn:iso:std:iso:20022:tech:xsd:pain.001.001.', h('b', {}, ver === '9' ? '09' : '11')));
    const D9 = ver === '9' ? V9.msg : null;
    const fact = (k, v, cls) => (v ? [h('span', {}, k), h('p', cls ? { class: cls } : {}, v)] : []);
    // nothing is shown when the message passes, as for version 11; a box appears only if it fails the schema
    const v9Box = D9 && !D9.valid ? h('details', { class: 'v9box' + (D9.valid ? '' : ' warn') },
      h('summary', {}, h('b', {}, 'Version 9'), h('span', { class: D9.valid ? 'ok' : 'bad' }, D9.valid ? 'A message is built and passes the schema.' : 'A message is built, but it fails the schema.'), h('i', {}, 'details')),
      h('div', { class: 'vcmp' },
        fact('Result', D9.valid ? 'A message is built. It passes the version 9 schema.' : 'A message is built. It does not pass the version 9 schema.', D9.valid ? 'ok' : 'bad'),
        fact('Why', D9.valid ? '' : D9.why),
        fact('Mapping', 'The same as version 11. Every tag has the same value and comes from the same field.'),
        fact('Left out', D9.left ? 'The supplementary data. It is for FIS only.' : ''))) : null;
    // folded to one line unless the reader opened it; the choice stays while moving between wires
    if (v9Box) { v9Box.open = !!WT.v9BoxOpen; v9Box.addEventListener('toggle', (e) => { if (e.target !== v9Box) return; WT.v9BoxOpen = v9Box.open; window.dispatchEvent(new Event('resize')); }); }
    const mark = (id) => (ver === '9' ? null : vmark(id));
    // search the message by tag or by the name in full; any part of a word; every match is lit
    const findInput = h('input', { type: 'search', class: 'findin', placeholder: 'Search a tag or its name: Agt, creditor, clearing', 'aria-label': 'Search the message by tag or by name', value: WT.journeyFind || '' });
    const findCount = h('span', { class: 'findn', 'aria-live': 'polite' }, '');
    const findPrev = h('button', { type: 'button', class: 'findb', 'aria-label': 'Previous match', title: 'Previous match (Shift+Enter)', onclick: () => findStep(-1) }, '\u2039');
    const findNext = h('button', { type: 'button', class: 'findb', 'aria-label': 'Next match', title: 'Next match (Enter)', onclick: () => findStep(1) }, '\u203A');
    const findBar = h('div', { class: 'findbar' }, findInput, findCount, findPrev, findNext);
    const xmlCol = h('div', { class: 'col jcol message', data: { ver } }, h('h3', {}, 'pain.001', verSeg, h('em', {}, ver === '9' ? 'the same mapping, as version 9' : 'what the mapper built'), findBar), nsLine, v9Box, ver === '9' ? null : v11Bar,
      xmlRows.map((r) => (r.slot ? (el.slot[r.slot.id] = h('button', { class: 'row xr' + (r.slot.src.length ? '' : ' fixed'), type: 'button', style: `--d:${r.depth}`, data: { id: r.slot.id, info: 'el:' + r.slot.id, infomode: 'full' } }, h('span', { class: 'tag' }, r.tag), mark(r.slot.p, true), h('span', { class: 'val' }, r.slot.group ? r.slot.v : r.slot.v === '' ? '(empty block)' : WT.short(r.slot.v, 30))))
        : h('div', { class: 'row xg', style: `--d:${r.depth}`, data: { info: 'grp:' + r.path, infomode: 'full' } }, h('span', { class: 'tag' }, r.tag), mark(r.path, false)))));
    // one entry per row: its tag as shown, its name in full, and the tags and names of the path it sits in
    const fullOf = (t) => (WT.content.short[t] && WT.content.short[t][0]) || WT.content.tags[t] || '';
    const rowEls = [...xmlCol.querySelectorAll('.row')];
    const findMeta = xmlRows.map((r, i) => {
      const raw = r.slot ? r.slot.p : r.path; const segs = WT.norm(raw).split('@')[0].split('/'); const t = segs[segs.length - 1]; const attr = raw.includes('@');
      const full = fullOf(t) + (attr && fullOf(t) ? ', its currency' : '');
      return { el: rowEls[i], tagEl: rowEls[i].querySelector('.tag'), text: r.tag, full: full && full.toLowerCase() !== r.tag.toLowerCase() ? full : '', own: (r.tag + ' ' + full).toLowerCase(), path: segs.map((x) => x + ' ' + fullOf(x)).join(' ').toLowerCase() };
    });
    let findHits = []; let findCur = -1;
    const lit = function (text, toks) {   // the text with every found part marked
      const low = text.toLowerCase(); let out = ''; let i = 0;
      while (i < text.length) { const k = toks.find((x) => low.startsWith(x, i)); if (k) { out += '<mark>' + WT.esc(text.slice(i, i + k.length)) + '</mark>'; i += k.length; } else { out += WT.esc(text[i]); i++; } }
      return out;
    };
    const find = function () {
      WT.journeyFind = findInput.value; const toks = findInput.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
      findHits = []; findCur = -1;
      for (const m of findMeta) {
        // every word must be found in the tag or its name; with several words they may also be spread over the path, as in "creditor name"
        const hit = toks.length > 0 && (toks.every((k) => m.own.includes(k)) || (toks.length > 1 && toks.every((k) => m.path.includes(k)) && toks.some((k) => m.own.includes(k))));
        m.el.classList.toggle('found', hit); m.el.classList.remove('cur');
        const old = m.el.querySelector('.fn'); if (old) old.remove();
        if (hit) { m.tagEl.innerHTML = lit(m.text, toks); if (m.full) { const fn = document.createElement('span'); fn.className = 'fn'; fn.innerHTML = lit(m.full, toks); m.tagEl.after(fn); } findHits.push(m); } else m.tagEl.textContent = m.text;
      }
      xmlCol.classList.toggle('searching', toks.length > 0);
      findCount.textContent = toks.length ? (findHits.length ? findHits.length + (findHits.length === 1 ? ' match' : ' matches') : 'no match') : '';
      findBar.classList.toggle('none', toks.length > 0 && !findHits.length);
      findPrev.disabled = findNext.disabled = findHits.length === 0;
    };
    const findStep = function (d) {
      if (!findHits.length) return;
      if (findCur >= 0) findHits[findCur].el.classList.remove('cur');
      findCur = findCur < 0 ? (d > 0 ? 0 : findHits.length - 1) : (findCur + d + findHits.length) % findHits.length;
      const m = findHits[findCur]; m.el.classList.add('cur');
      const top = m.el.offsetTop - xmlCol.querySelector('h3').offsetHeight - 40; xmlCol.scrollTop = Math.max(0, top);
      findCount.textContent = (findCur + 1) + ' of ' + findHits.length;
    };
    findInput.addEventListener('input', find);
    findInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); findStep(e.shiftKey ? -1 : 1); } else if (e.key === 'Escape' && findInput.value) { e.stopPropagation(); findInput.value = ''; find(); } });
    find();
    const cords = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); cords.setAttribute('class', 'cords');
    const trio = h('div', { class: 'trio' }, formCol, payCol, xmlCol, cords);
    const info = h('div', { class: 'feedback trace' }, h('span', { class: 'hint' }, 'Click any box, field or element to follow it from the screen to the message.'));
    let picked = { fields: [], slots: [] };

    const draw = function () {
      const box = trio.getBoundingClientRect();
      cords.setAttribute('width', box.width); cords.setAttribute('height', box.height); cords.replaceChildren();
      const line = function (a, b, cls) {
        const ra = a.getBoundingClientRect(); const rb = b.getBoundingClientRect(); const pa = a.closest('.jcol').getBoundingClientRect(); const pb = b.closest('.jcol').getBoundingClientRect();
        const clamp = (y, r) => Math.min(Math.max(y, r.top + 34), r.bottom - 8);
        const x1 = ra.right - box.left, y1 = clamp(ra.top + ra.height / 2, pa) - box.top, x2 = rb.left - box.left, y2 = clamp(rb.top + rb.height / 2, pb) - box.top;
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', `M${x1},${y1} C${x1 + 34},${y1} ${x2 - 34},${y2} ${x2},${y2}`); path.setAttribute('class', 'cord ' + cls); cords.append(path);
      };
      for (const id of picked.fields) { if (el.box[id] && el.field[id]) line(el.box[id], el.field[id], 'c0'); for (const s of slotsOf(id)) if (picked.slots.includes(s.id)) line(el.field[id], el.slot[s.id], 'c1'); }
    };
    const pick = function (fields, slots, from) {
      picked = { fields, slots };
      trio.querySelectorAll('.hit').forEach((e) => e.classList.remove('hit'));
      for (const id of fields) { for (const side of ['box', 'field']) if (el[side][id]) { el[side][id].classList.add('hit'); if (side !== from) el[side][id].scrollIntoView({ block: 'nearest' }); } }
      for (const id of slots) { el.slot[id].classList.add('hit'); }
      if (slots.length && from !== 'slot') el.slot[slots[0]].scrollIntoView({ block: 'nearest' });
      const parts = [];
      for (const id of fields) {
        const b = boxOf(id); const to = slotsOf(id);
        const where = b && b.section
          ? (f.real ? `<b>${WT.esc(b.ext)}</b> in the request` : `<b>${WT.esc(b.section.replace(/^(From|To): /, ''))}, ${WT.esc(b.label.toLowerCase())}</b> on the screen`)
          : `<b>${WT.esc(b ? b.label : id)}</b> ${f.real ? 'has no field in the request' : 'is not typed by anyone'}. ${WT.esc(b ? b.note : '')}`;
        const then = to.length ? ` It fills ${to.slice(0, 4).map((s) => `<code>${WT.esc(WT.shortPath(s.p))}</code>`).join(', ')}${to.length > 4 ? ' and ' + (to.length - 4) + ' more' : ''}. ${WT.esc(WT.ruleFor(to[0].p))}` : ` It goes nowhere in the message. ${WT.esc(WT.fieldNote(id) || '')}`;
        parts.push(`${where}${b && b.section ? ' becomes' : ' In the payload it is'} <code>${WT.esc(id)}</code>.${then}`);
        if (f.real && b && b.section && b.changed) parts.push(`<span class="sheetnote">The request says <code>${WT.esc(WT.fmt(b.v))}</code>; the payload holds <code>${WT.esc(WT.fmt(id.split('.').reduce((a, k) => (a == null ? a : a[k]), c.payload)))}</code>.</span>`);
        if (f.real && b && b.section && b.note && id === b.id) parts.push(`<span class="sheetnote">On the mapping sheet: ${WT.esc(WT.short(b.note, 260))}</span>`);
      }
      if (!fields.length && slots.length) { const s = m.slots.find((x) => x.id === slots[0]); parts.push(`<code>${WT.esc(WT.shortPath(s.p))}</code> is not from the payload: ${{ constant: 'a constant', clock: 'the clock', context: 'a fixed setting in the mapper', envelope: 'the PayX envelope' }[s.how]}. ${WT.esc(WT.ruleFor(s.p))}`); }
      info.className = 'feedback trace on'; info.innerHTML = parts.join('<br>');
      requestAnimationFrame(draw);
    };
    // a second click on the same box, field or element takes the lines away again
    let pickedKey = null;
    const unpick = function () {
      picked = { fields: [], slots: [] }; pickedKey = null;
      trio.querySelectorAll('.hit').forEach((e) => e.classList.remove('hit'));
      info.className = 'feedback trace'; info.replaceChildren(h('span', { class: 'hint' }, 'Click any box, field or element to follow it from the screen to the message.'));
      requestAnimationFrame(draw);
    };
    trio.addEventListener('click', (e) => {
      const b = e.target.closest('.box'); const l = e.target.closest('.line'); const x = e.target.closest('.xr');
      const key = b ? 'box:' + b.dataset.ids : l ? 'field:' + l.dataset.id : x ? 'slot:' + x.dataset.id : null;
      if (key && key === pickedKey) { unpick(); return; }
      if (key) pickedKey = key;
      if (b) { const ids = b.dataset.ids.split(','); pick(ids, ids.flatMap((id) => slotsOf(id).map((s) => s.id)), 'box'); }
      else if (l) pick([l.dataset.id], slotsOf(l.dataset.id).map((s) => s.id), 'field');
      else if (x) { const s = m.slots.find((q) => q.id === x.dataset.id); pick(s.src.slice(), [s.id], 'slot'); }
    });
    [formCol, payCol, xmlCol].forEach((col) => col.addEventListener('scroll', draw)); window.addEventListener('resize', draw);

    const stopBody = h('div', { class: 'stopbody' });
    const strip = h('ol', { class: 'strip' }, J.stops.map((s, i) => h('li', {}, h('button', { class: 'stop', type: 'button', data: { i }, onclick: () => stop(i) }, h('b', {}, i + 1), h('span', {}, s.t), h('em', {}, s.shape)))));
    const stop = function (i) {
      const s = J.stops[i];
      strip.querySelectorAll('.stop').forEach((b, k) => b.classList.toggle('on', k === i));
      stopBody.replaceChildren(h('h3', {}, s.t), ...s.say.map((t) => h('p', {}, t)));
      trio.dataset.focus = s.col;
    };
    const kinds = ['gateway', 'customer', 'bank', 'intermediary', 'drawdown', 'fx', 'onbehalf', 'uatfed', 'uatintl', 'uatinter'].filter((k) => WT.original(k));
    // how to read this screen: open the first time, then remembered as closed
    const seen = (WT.S.P.steps['guide:journey'] || {}).closed;
    const guide = h('details', { class: 'guide', open: !seen },
      h('summary', {}, 'How to read this screen'),
      h('ol', {},
        h('li', {}, h('b', {}, 'Read the three columns from left to right.'), ' Left: what a person fills in, or what the gateway sends. Middle: the payload, which is what the rail is handed. Right: the pain.001 the rail builds from it.'),
        h('li', {}, h('b', {}, 'Click the numbered stops above, 1 to 6.'), ' Each one says what happens to the wire there. The column that shows the wire at that point gets a green frame.'),
        h('li', {}, h('b', {}, 'Click anything in any column.'), ' It lights up in all three, lines join them, and the bar at the bottom says what it becomes and why. For the gateway the left column shows the real field names of the request.'),
        h('li', {}, h('b', {}, 'Three things to notice.'), ' Dashed boxes at the end of the left column are fields nobody types. A payload field with a line through it goes nowhere in the message. A value in italics on the right is not from the payload.'),
        h('li', {}, h('b', {}, 'Rest the pointer on anything for a moment.'), ' A card says what it is, why it exists and how it is used. On a value such as SHAR it explains the value.'),
        h('li', {}, h('b', {}, 'Then follow it to FIS.'), ' Press "This wire as FIS JSON" at the top right: the same message as the FIS API takes it, with the row you picked still lit. Change the wire or the way it starts at any time, in the bar above the stops.')));
    guide.addEventListener('toggle', () => { WT.S.P.steps['guide:journey'] = { closed: !guide.open }; WT.save(); requestAnimationFrame(draw); });
    main.replaceChildren(
      h('header', { class: 'vh' }, h('div', {}, h('h1', {}, 'A wire, end to end'), h('p', {}, 'Where a wire starts, what it looks like at each stop, and where each thing on the screen ends up in the message.')),
        h('div', { class: 'actions' }, h('button', { class: 'btn primary', data: { act: 'tofis' }, title: 'The same wire as the FIS API takes it. A row you picked in the message stays picked.', onclick: () => WT.go('fisjson', { ex: c.id, pick: ver === '11' ? picked.slots[0] : undefined }) }, 'This wire as FIS JSON'))),
      h('div', { class: 'jbar' },
        h('div', { class: 'seg', role: 'group', 'aria-label': 'How the wire starts' }, Object.entries(C.journey).map(([k, j]) => h('button', { class: 'segb' + (k === way ? ' on' : ''), data: { way: k }, onclick: () => WT.go('journey', { way: k, kind: p.kind }) }, j.title, h('em', {}, j.sub)))),
        h('label', { class: 'pickwire' }, 'The wire ', h('select', { 'aria-label': 'Which wire', onchange: (e) => WT.go('journey', { way, kind: e.target.value }) }, kinds.map((k) => h('option', { value: k, selected: k === kind }, C.kinds[k].title))))),
      h('div', { class: 'journey' }, strip, stopBody),
      guide, trio, h('div', { class: 'dock' }, info));
    stop(0);
    if (!WT.S.P.steps.journey) WT.stepDone('journey', 100);
  };
})();
