// "To FIS JSON": the message the mapper built, and the same message as the FIS API takes it.
// Left the pain.001 XML, right the FIS JSON. Click a row on either side and its partner lights up, joined by a line.
// The data is built by tools/build-fisjson.js from the pain.001 schema, the FIS contract and FIS's own sample requests.
(function () {
  const WT = window.WT; const h = WT.h; const C = WT.content; const V = WT.views;

  // what happens to a tag on the way, one sentence per kind
  const RULES = {
    name: 'The value stays the same. Only the name is written in full.',
    list: 'The tag may repeat, so the JSON holds a list, even when there is one value.',
    type: 'Written as true or false, not as text.',
    value: 'The text of the tag becomes a field of its own, because the currency now sits beside it.',
    attr: 'An attribute in the XML becomes a field in the JSON.',
    same: 'One of FIS\'s own names. It is spelled the same in the XML and in the JSON.',
    fis: 'Added for FIS. The XML has no tag for it.',
    header: 'Part of the header around the message. The XML has no tag for it.',
    stray: 'Written by FIS in its sample, but not a name of its own contract.',
    spelling: 'FIS\'s contract and FIS\'s own samples spell this name differently.',
  };
  const KINDS = [['name', 'names written in full'], ['list', 'in a list'], ['attr', 'attribute to field'], ['type', 'true or false'], ['same', 'FIS\'s own names'], ['fis', 'added for FIS'], ['spelling', 'spelled two ways'], ['stray', 'not in the contract']];
  const fullOf = (t) => (C.short[t] && C.short[t][0]) || C.tags[t] || '';
  const lastTag = (path) => WT.norm(path).split('/').pop();
  const seg = (path) => path.split('.').pop();
  const jName = (path) => seg(path).replace(/\[\d+\]$/, '');
  const jIndex = (path) => { const m = /\[(\d+)\]$/.exec(seg(path)); return m ? Number(m[1]) : -1; };
  const shortJ = (path) => path.replace('businessDocument.customerCreditTransferInitiation.', '');
  const spellNote = (q) => (q.alt ? ' ' + (q.altFrom === 'samples' ? `The contract of FIS spells it <code>${WT.esc(q.json)}</code>; FIS's own sample requests spell it <code>${WT.esc(q.alt)}</code>. Which one the API accepts is a question for FIS.` : `FIS spells it <code>${WT.esc(q.json)}</code> in this sample; its contract spells it <code>${WT.esc(q.alt)}</code>.`) : '');
  const rulesOf = (q) => (q.why ? [q.why] : q.k.filter((k) => k !== 'spelling').map((k) => RULES[k]));

  // the card of a row of the JSON column (explain.js asks for it)
  WT.fisCardHtml = function (id) {
    const q = WT.fisLookup && WT.fisLookup[id]; if (!q) return '';
    const row = (k, v) => (v ? `<dt>${k}</dt><dd>${v}</dd>` : '');
    const tag = q.tag ? q.tag.split(' ')[0] : '';
    let s = `<h4><code>${WT.esc(q.json)}</code><span>${q.box ? 'a block' : 'a field'} of the FIS JSON</span></h4><dl>`;
    s += row('In the XML', q.tag ? `<code>${WT.esc(q.tag)}</code> ${WT.esc(fullOf(tag))}` : q.box ? 'Nothing. FIS wraps the message in this block.' : 'Nothing.');
    s += row('What changes', (q.box ? [q.tag ? RULES.name.replace('The value stays the same. ', '') : ''].concat(q.list ? [RULES.list] : []) : rulesOf(q)).filter(Boolean).map(WT.esc).join(' ') + spellNote(q));
    if (!q.box) s += row('Value here', `<code>${WT.esc(WT.short(String(q.v), 70))}</code>`);
    s += row('Where', `<code>${WT.esc(shortJ(id))}</code>`);
    return s + '</dl>';
  };

  V.fisjson = function (main, p) {
    p = p || {}; const F = WT.S.fis;
    const headEl = h('header', { class: 'vh' }, h('div', {}, h('h1', {}, 'From the message to the FIS request'),
      h('p', {}, 'Wire II does not send the XML. It sends the same message as JSON to the FIS API. Nothing is added to the payment and nothing is dropped: only the way it is written changes, and a header goes around it.')));
    if (!F) { main.replaceChildren(headEl, h('div', { class: 'fatal' }, h('h1', {}, 'The data for this screen is missing'), h('p', {}, 'The data files of this app are incomplete.'))); return; }
    const ex = F.examples.find((e) => e.id === (p.ex || WT.fisEx)) || F.examples.find((e) => e.id === 'gpn-usd-wire') || F.examples[0]; WT.fisEx = ex.id;
    const back = ex.group === 'ours' ? WT.S.cases.find((c) => c.id === ex.id && c.original && WT.original(c.kind) === c) : null;
    if (back) headEl.append(h('div', { class: 'actions' }, h('button', { class: 'btn', data: { act: 'toend' }, title: 'Where this message comes from: the screen or the request, the payload, and the mapping.', onclick: () => WT.go('journey', { kind: back.kind, way: back.kind === 'gateway' ? 'gateway' : WT.journeyWay }) }, 'This wire, end to end')));
    const body = ex.pairs.filter((q) => q.k[0] !== 'header'); const header = ex.pairs.filter((q) => q.k[0] === 'header');
    const jOfBox = ex.boxes; const xOfBox = Object.fromEntries(Object.entries(ex.boxes).map(([x, j]) => [j, x]));
    const el = { x: {}, xb: {}, j: {}, jb: {} }; const lookup = WT.fisLookup = {};

    // ---- the XML column
    const xRows = WT.rows(body.filter((q) => q.x).map((q) => ({ id: q.x, p: q.x, v: q.v, src: [1] })), '/');
    const xCol = h('div', { class: 'col jcol message fx' }, h('h3', {}, 'pain.001 XML', h('em', {}, ex.group === 'fis' ? 'the same request, written with the tags' : 'what the mapper built')),
      xRows.map((r) => (r.slot
        ? (el.x[r.slot.id] = h('button', { class: 'row xr', type: 'button', style: `--d:${r.depth}`, data: { side: 'x', id: r.slot.id, info: 'tag:' + lastTag(r.slot.id), infomode: 'meaning' } }, h('span', { class: 'tag' }, r.tag), h('span', { class: 'val' }, WT.short(r.slot.v, 26))))
        : (el.xb[r.path] = h('button', { class: 'row xg', type: 'button', style: `--d:${r.depth}`, data: { side: 'x', box: r.path, info: 'tag:' + lastTag(r.path), infomode: 'meaning' } }, h('span', { class: 'tag' }, r.tag))))));

    // ---- the JSON column
    const jRows = WT.rows(body.map((q) => ({ id: q.j, p: q.j, v: q.v, src: [1], q })), '.');
    const listTag = (path) => { const i = jIndex(path); return i < 0 ? null : h('span', { class: 'ltag' }, i ? 'list, item ' + (i + 1) : 'list'); };
    const flag = (q) => (q.k.includes('stray') ? h('span', { class: 'vtag new' }, 'not in the contract') : q.k.includes('fis') ? h('span', { class: 'vtag only11' }, 'added for FIS') : q.k.includes('spelling') ? h('span', { class: 'vtag changed' }, 'spelled two ways') : null);
    const jCol = h('div', { class: 'col jcol message fj' }, h('h3', {}, 'FIS JSON', h('em', {}, ex.group === 'fis' ? 'what FIS sent as its sample' : 'the same message, as FIS takes it')),
      jRows.map((r) => {
        if (r.slot) {
          const q = r.slot.q; lookup[q.j] = q;
          return (el.j[q.j] = h('button', { class: 'row xr' + (q.x ? '' : ' fixed'), type: 'button', style: `--d:${r.depth}`, data: { side: 'j', id: q.j, info: 'fj:' + q.j, infomode: 'meaning' } },
            h('span', { class: 'tag' }, jName(q.j)), listTag(q.j), flag(q), h('span', { class: 'val' }, q.k.includes('type') ? String(q.v) : '"' + WT.short(q.v, 24) + '"')));
        }
        const x = xOfBox[r.path]; lookup[r.path] = { box: true, json: jName(r.path), tag: x ? lastTag(x) : '', list: jIndex(r.path) >= 0 };
        return (el.jb[r.path] = h('button', { class: 'row xg' + (x ? '' : ' fixed'), type: 'button', style: `--d:${r.depth}`, data: { side: 'j', box: r.path, info: 'fj:' + r.path, infomode: 'meaning' } }, h('span', { class: 'tag' }, jName(r.path)), listTag(r.path)));
      }));

    const cords = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); cords.setAttribute('class', 'cords');
    const duo = h('div', { class: 'trio duo' }, xCol, jCol, cords);
    const HINT = 'Click a tag on the left or a name on the right to see its partner on the other side.';
    const info = h('div', { class: 'feedback trace' }, h('span', { class: 'hint' }, HINT));

    // ---- following a row to its partner
    let lines = []; let pickedKey = null;
    const draw = function () {
      const box = duo.getBoundingClientRect(); cords.setAttribute('width', box.width); cords.setAttribute('height', box.height); cords.replaceChildren();
      for (const [a, b] of lines) {
        const ra = a.getBoundingClientRect(); const rb = b.getBoundingClientRect(); const pa = xCol.getBoundingClientRect(); const pb = jCol.getBoundingClientRect();
        const clamp = (y, r) => Math.min(Math.max(y, r.top + 34), r.bottom - 8);
        const x1 = pa.right - box.left, y1 = clamp(ra.top + ra.height / 2, pa) - box.top, x2 = pb.left - box.left, y2 = clamp(rb.top + rb.height / 2, pb) - box.top;
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', `M${x1},${y1} C${x1 + 34},${y1} ${x2 - 34},${y2} ${x2},${y2}`); path.setAttribute('class', 'cord c1'); cords.append(path);
      }
    };
    const unpick = function () { lines = []; pickedKey = null; duo.querySelectorAll('.hit').forEach((e) => e.classList.remove('hit')); info.className = 'feedback trace'; info.replaceChildren(h('span', { class: 'hint' }, HINT)); requestAnimationFrame(draw); };
    const show = function (xs, js, from, html) {
      duo.querySelectorAll('.hit').forEach((e) => e.classList.remove('hit'));
      xs = xs.filter(Boolean); js = js.filter(Boolean);
      for (const e of [...xs, ...js]) e.classList.add('hit');
      const bring = (e, col) => { const top = e.offsetTop - col.querySelector('h3').offsetHeight - 60; if (e.offsetTop < col.scrollTop + 40 || e.offsetTop > col.scrollTop + col.clientHeight - 40) col.scrollTop = Math.max(0, top); };
      if (from !== 'x' && xs[0]) bring(xs[0], xCol); if (from !== 'j' && js[0]) bring(js[0], jCol);
      lines = xs.length && js.length ? js.map((j) => [xs[0], j]) : [];
      info.className = 'feedback trace on'; info.innerHTML = html; requestAnimationFrame(draw);
    };
    const leafText = (q) => (q.x
      ? `<code>${WT.esc(q.tag)}</code>${fullOf(q.tag.split(' ')[0]) ? ' (' + WT.esc(fullOf(q.tag.split(' ')[0])) + ')' : ''} is written <code>${WT.esc(q.json)}</code>. ${rulesOf(q).map(WT.esc).join(' ')}${spellNote(q)}`
      : `<code>${WT.esc(q.json)}</code> has no tag in the XML. ${rulesOf(q).map(WT.esc).join(' ')}`);
    const boxText = (x, j) => (x
      ? `<code>${WT.esc(lastTag(x))}</code>${fullOf(lastTag(x)) ? ' (' + WT.esc(fullOf(lastTag(x))) + ')' : ''} is the block <code>${WT.esc(jName(j))}</code>.${jIndex(j) >= 0 ? ' ' + WT.esc(RULES.list) : ''}`
      : `<code>${WT.esc(jName(j))}</code> has no tag in the XML: it is part of the wrapper FIS puts around the message.`);
    duo.addEventListener('click', (e) => {
      const r = e.target.closest('.row'); if (!r) return;
      const key = r.dataset.side + ':' + (r.dataset.id || 'box:' + r.dataset.box);
      if (key === pickedKey) { unpick(); return; } pickedKey = key;
      if (r.dataset.id && r.dataset.side === 'x') { const qs = body.filter((q) => q.x === r.dataset.id); show([r], qs.map((q) => el.j[q.j]), 'x', qs.map(leafText).join('<br>')); }
      else if (r.dataset.id) { const q = lookup[r.dataset.id]; show([q.x ? el.x[q.x] : null], [r], 'j', leafText(q)); }
      else if (r.dataset.side === 'x') { const j = jOfBox[r.dataset.box]; show([r], [el.jb[j] || el.j[j]], 'x', boxText(r.dataset.box, j)); }
      else { const x = xOfBox[r.dataset.box]; show([x ? (el.xb[x] || el.x[x]) : null], [r], 'j', boxText(x, r.dataset.box)); }
    });
    [xCol, jCol].forEach((col) => col.addEventListener('scroll', draw)); window.addEventListener('resize', draw);

    // ---- lighting rows: by a search in either column, or by one kind of change
    // Each column has its own search box in its heading. A search looks at the names of its own side (on the XML side the
    // tag and its name in full, on the JSON side the JSON name) and lights the partner rows on the other side as well.
    const rowsOf = []; // every pair of rows with the text each side answers to
    for (const q of body) { const tag = q.tag ? q.tag.split(' ')[0] : ''; rowsOf.push({ hx: q.x ? ((q.tag || '') + ' ' + fullOf(tag)).toLowerCase() : '', hj: q.json.toLowerCase(), kinds: q.k, els: [q.x ? el.x[q.x] : null, el.j[q.j]].filter(Boolean) }); }
    for (const [x, j] of Object.entries(jOfBox)) if (el.xb[x] || el.jb[j]) rowsOf.push({ hx: (lastTag(x) + ' ' + fullOf(lastTag(x))).toLowerCase(), hj: jName(j).toLowerCase(), kinds: jIndex(j) >= 0 ? ['list'] : [], els: [el.xb[x], el.jb[j]].filter(Boolean), box: true });
    for (const j of Object.keys(el.jb)) if (!xOfBox[j]) rowsOf.push({ hx: '', hj: jName(j).toLowerCase(), kinds: [], els: [el.jb[j]], box: true });
    const texts = new Map(); duo.querySelectorAll('.row .tag').forEach((t) => texts.set(t, t.textContent));
    const lit = function (text, toks) { const low = text.toLowerCase(); let out = ''; let i = 0; while (i < text.length) { const k = toks.find((x) => low.startsWith(x, i)); if (k) { out += '<mark>' + WT.esc(text.slice(i, i + k.length)) + '</mark>'; i += k.length; } else { out += WT.esc(text[i]); i++; } } return out; };
    let hits = []; let cur = -1; let kindOn = null; let active = null;
    const light = function (test, toks, side) {
      duo.querySelectorAll('.row').forEach((r) => { r.classList.remove('found', 'cur'); const fn = r.querySelector('.fn'); if (fn) fn.remove(); });
      texts.forEach((txt, t) => { t.textContent = txt; });
      hits = test ? rowsOf.filter(test) : []; cur = -1;
      for (const m of hits) for (const e of m.els) {
        e.classList.add('found'); const t = e.querySelector('.tag');
        if (!toks || !toks.length || e.dataset.side !== side) continue;          // the typed part is marked on the side that was searched
        t.innerHTML = lit(texts.get(t), toks);
        if (side === 'x') { const full = fullOf(lastTag(e.dataset.id || e.dataset.box).split('@')[0]); if (full && full.toLowerCase() !== texts.get(t).toLowerCase()) { const fn = document.createElement('span'); fn.className = 'fn'; fn.innerHTML = lit(full, toks); t.after(fn); } }
      }
      xCol.classList.toggle('searching', !!test); jCol.classList.toggle('searching', !!test);
    };
    const step = function (d) {
      if (!hits.length) return; if (cur >= 0) hits[cur].els.forEach((e) => e.classList.remove('cur'));
      cur = cur < 0 ? (d > 0 ? 0 : hits.length - 1) : (cur + d + hits.length) % hits.length;
      for (const e of hits[cur].els) { e.classList.add('cur'); const col = e.closest('.jcol'); col.scrollTop = Math.max(0, e.offsetTop - col.querySelector('h3').offsetHeight - 60); }
      if (active) active.count.textContent = (cur + 1) + ' of ' + hits.length;
    };
    const finder = function (side, placeholder, label) {
      const input = h('input', { type: 'search', class: 'findin', placeholder, 'aria-label': label, value: WT.fisFind && WT.fisFind.side === side ? WT.fisFind.text : '' });
      const count = h('span', { class: 'findn', 'aria-live': 'polite' }, '');
      const bar = h('div', { class: 'findbar' }, input, count,
        h('button', { type: 'button', class: 'findb', 'aria-label': 'Previous match', title: 'Previous match (Shift+Enter)', onclick: () => step(-1) }, '\u2039'),
        h('button', { type: 'button', class: 'findb', 'aria-label': 'Next match', title: 'Next match (Enter)', onclick: () => step(1) }, '\u203A'));
      const me = { side, input, count, bar };
      const run = function () {
        const other = finders.find((x) => x !== me); if (input.value && other) { other.input.value = ''; other.count.textContent = ''; other.bar.classList.remove('none'); }
        const toks = input.value.trim().toLowerCase().split(/\s+/).filter(Boolean); kindOn = null; chips.forEach((c) => c.classList.remove('on'));
        WT.fisFind = toks.length ? { side, text: input.value } : null; active = toks.length ? me : null;
        light(toks.length ? (m) => { const hay = side === 'x' ? m.hx : m.hj; return hay !== '' && toks.every((k) => hay.includes(k)); } : null, toks, side);
        count.textContent = toks.length ? (hits.length ? hits.length + (hits.length === 1 ? ' match' : ' matches') : 'no match') : '';
        bar.classList.toggle('none', toks.length > 0 && !hits.length);
      };
      me.run = run; input.addEventListener('input', run);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); step(e.shiftKey ? -1 : 1); } else if (e.key === 'Escape' && input.value) { e.stopPropagation(); input.value = ''; run(); } });
      return me;
    };
    const finders = [finder('x', 'Search a tag or its name: MsgId, creditor, clearing', 'Search the XML by tag or by name'), finder('j', 'Search a JSON name: messageIdent, creditorAgent, currency', 'Search the FIS JSON by name')];
    xCol.querySelector('h3').append(finders[0].bar); jCol.querySelector('h3').append(finders[1].bar);
    const clearFinders = function () { for (const x of finders) { x.input.value = ''; x.count.textContent = ''; x.bar.classList.remove('none'); } WT.fisFind = null; active = null; };
    // ---- what changes on the way, counted for this message; a click lights those rows
    const count = (k) => body.filter((q) => q.k.includes(k)).length + (k === 'list' ? Object.values(jOfBox).filter((j) => jIndex(j) >= 0).length : 0);
    const chips = KINDS.filter(([k]) => count(k)).map(([k, label]) => h('button', { class: 'kchip', type: 'button', data: { kind: k }, onclick: (e) => {
      const b = e.currentTarget; if (kindOn === k) { kindOn = null; b.classList.remove('on'); light(null); kcount.textContent = ''; return; }
      clearFinders(); chips.forEach((c) => c.classList.toggle('on', c === b)); kindOn = k; light((m) => m.kinds.includes(k), null); kcount.textContent = hits.length + ' rows lit';
    } }, h('b', {}, String(count(k))), ' ' + label));
    const kcount = h('span', { class: 'findn' }, '');
    const changes = h('div', { class: 'kbar' }, h('span', { class: 'klead' }, 'What changes on the way'), chips, kcount);

    // ---- which message
    const opt = (e) => h('option', { value: e.id, selected: e.id === ex.id }, e.title);
    const picker = h('label', { class: 'pickwire' }, 'The message ', h('select', { 'aria-label': 'Which message', onchange: (e) => WT.go('fisjson', { ex: e.target.value }) },
      h('optgroup', { label: 'Messages our mapper builds' }, F.examples.filter((e) => e.group === 'ours').map(opt)),
      h('optgroup', { label: 'FIS\'s own sample requests' }, F.examples.filter((e) => e.group === 'fis').map(opt))));

    // ---- around the message: the header, the call, and FIS's sample of the same kind
    const fact = (k, v) => [h('span', {}, k), h('p', {}, v)];
    const headBox = h('details', { class: 'fbox' }, h('summary', {}, h('b', {}, 'The header around the message'), ' ' + header.length + ' fields. They are not in the pain.001.'),
      h('p', {}, header.length ? header[0].why : ''),
      h('div', { class: 'vcmp wide' }, header.map((q) => fact(q.j.replace('businessApplicationHeader.', ''), '"' + q.v + '"'))));
    const callBox = h('details', { class: 'fbox' }, h('summary', {}, h('b', {}, 'How it is sent'), ' One call to the FIS API, with ' + F.call.headers.length + ' headers.'),
      h('div', { class: 'vcmp wide' }, fact('Call', F.call.method + ' ' + F.call.path), fact('Body', 'One JSON object with two parts: ' + F.wrapper.join(' and ') + '.'),
        F.call.headers.map((x) => fact(x.name, x.required ? 'A header of the call. Required by the contract.' : 'A header of the call. Optional in the contract.'))),
      h('p', { class: 'vnote' }, 'From the FIS contract ' + F.contract.title + '.'));
    const A = ex.against; const fisTitle = A ? (F.examples.find((e) => e.id === A.id) || {}).title : '';
    const againstBox = A ? h('details', { class: 'fbox' }, h('summary', {}, h('b', {}, 'Set against ' + fisTitle), ' ' + [A.same + ' fields the same', A.differ.length + ' with another value', A.onlyOurs.length + ' only in ours', A.onlyFis.length + ' only in FIS\'s'].join(', ') + '.'),
      h('div', { class: 'vcmp wide' },
        A.differ.map((d) => fact(d.j, 'Ours: "' + d.ours + '". FIS\'s: "' + d.fis + '".')),
        A.onlyOurs.map((d) => fact(d.j, 'Only in ours: "' + WT.short(d.v, 60) + '".')),
        A.onlyFis.slice(0, 40).map((d) => fact(d.j, 'Only in FIS\'s sample: "' + WT.short(d.v, 60) + '".'))),
      A.onlyFis.length > 40 ? h('p', { class: 'vnote' }, 'And ' + (A.onlyFis.length - 40) + ' more fields that only FIS\'s sample has.') : null,
      h('p', { class: 'vnote' }, 'Our message was built by the mapper from a payload shaped like this sample, then written as JSON here.')) : null;

    main.replaceChildren(headEl,
      h('div', { class: 'jbar' }, picker, h('span', { class: 'fnote' }, ex.note)),
      changes, duo, info, h('div', { class: 'fboxes' }, againstBox, headBox, callBox));
    const again = finders.find((x) => x.input.value); if (again) again.run();
    requestAnimationFrame(draw);
    if (p.pick && el.x[p.pick]) el.x[p.pick].click();
  };
})();
