// Core: small DOM helpers, the data, the learner's progress, and the question generators.
(function () {
  const WT = window.WT;
  const C = WT.content;

  // ---------------------------------------------------------------- dom
  WT.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'data') for (const [d, dv] of Object.entries(v)) el.dataset[d] = dv;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat(Infinity)) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  };
  WT.esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  WT.toast = function (msg) { const t = document.getElementById('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(WT._tt); WT._tt = setTimeout(() => t.classList.remove('on'), 2600); };
  WT.shuffle = function (a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  WT.sample = (a, n) => WT.shuffle(a).slice(0, n);
  WT.short = (s, n = 46) => { s = String(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

  // ---------------------------------------------------------------- names
  WT.norm = (p) => p.replace(/\[\d+\]/g, '');
  WT.tagOf = (p) => WT.norm(p).split('/').pop();
  WT.tagName = function (tag) { const [t, attr] = tag.split('@'); const n = C.tags[t] || t; return attr ? n + ', its currency' : n; };
  WT.shortPath = (p) => WT.norm(p).replace('PmtInf/CdtTrfTxInf/', '').replace(/^PmtInf\//, '').replace(/^SplmtryData\/Envlp\//, '').replace(/SplmtryData\/Envlp\//, '');
  WT.ruleFor = function (p) { const n = WT.norm(p); for (const [re, text] of C.rules) if (re.test(n)) return text; return 'Copied as received.'; };
  WT.fieldNote = function (p) {
    if (C.nowhere[p]) return C.nowhere[p];
    if (p.endsWith('exchangeRate.exchangeRate')) return C.fields.exchangeRate_exchangeRate;
    return C.fields[p.split('.').pop()] || '';
  };
  WT.fmt = (v) => (v === null || v === undefined ? '' : typeof v === 'string' ? v : JSON.stringify(v));

  // ---------------------------------------------------------------- time
  WT.now = () => (WT.S.today ? new Date(WT.S.today + 'T12:00:00').getTime() + (Date.now() - WT.S.t0) : Date.now());
  WT.day = (t) => { const d = new Date(t === undefined ? WT.now() : t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const DAY = 86400000;
  const GAP = [0, 0, 1, 2, 4, 8];   // days until a card in box n comes back

  // ---------------------------------------------------------------- store
  WT.S = { cases: [], byId: {}, universe: null, P: null, today: null, t0: Date.now() };
  WT.load = async function () {
    const d = await window.trainer.load();
    const S = WT.S;
    S.cases = d.cases; S.universe = d.universe; S.external = d.external || null; S.v9 = d.v9 || null; S.fis = d.fis || null; S.today = d.today; S.test = d.test;
    S.byId = Object.fromEntries(d.cases.map((c) => [c.id, c]));
    S.P = Object.assign({ v: 1, cards: {}, blocks: {}, sheets: [], links: {}, steps: {}, used: [] }, d.progress || {});
    S.elements = d.universe.elements.map((e) => e.p);
  };
  let saveT = null;
  WT.save = function () { clearTimeout(saveT); saveT = setTimeout(() => window.trainer.save(WT.S.P).catch((e) => WT.toast('Could not save: ' + e.message)), 250); };

  // ---------------------------------------------------------------- cards (spaced repetition)
  WT.decks = {
    syl: { title: 'Tag syllables', say: 'The short pieces every ISO tag is built from.', cards: () => C.syllables.map(([f, b]) => ({ id: f, front: f, back: b })) },
    tag: { title: 'Whole tags', say: 'Read a tag you meet in the message.', cards: () => [...new Set(WT.S.elements.flatMap((p) => p.split('/').map((t) => t.split('@')[0])))].filter((t) => C.tags[t] && /^[A-Z]/.test(t)).map((t) => ({ id: t, front: t, back: C.tags[t] })) },
    term: { title: 'Terms', say: 'What people say in meetings: CTRC, UETR, charge bearer.', cards: () => C.terms.map(([f, b]) => ({ id: f, front: f, back: b })) },
    field: { title: 'Payload fields', say: 'What each field of the payload means.', cards: () => Object.entries(C.fields).map(([k, b]) => ({ id: k, front: k === 'exchangeRate_exchangeRate' ? 'exchangeRate.exchangeRate' : k, back: b })) },
  };
  WT.card = (deck, id) => WT.S.P.cards[deck + ':' + id] || { box: 0, due: 0, ms: 0, n: 0 };
  WT.rate = function (deck, id, correct, ms) {
    const c = Object.assign({}, WT.card(deck, id));
    c.n++; c.ms = ms;
    c.box = correct ? Math.min(5, Math.max(1, c.box) + (ms <= 6000 ? 1 : 0)) : 1;
    c.due = WT.now() + (correct ? GAP[c.box] * DAY : 0);
    WT.S.P.cards[deck + ':' + id] = c; WT.save();
  };
  WT.deckState = function (deck) {
    const cards = WT.decks[deck].cards(); const now = WT.now();
    let fresh = 0, due = 0, solid = 0;
    for (const c of cards) { const s = WT.card(deck, c.id); if (!s.n) fresh++; else if (s.due <= now) due++; if (s.box >= 3 && s.ms <= 3000) solid++; }
    return { total: cards.length, fresh, due, solid };
  };
  // cards to ask now: those that are due, then new ones
  WT.pickCards = function (deck, n) {
    const cards = WT.decks[deck].cards(); const now = WT.now();
    const due = cards.filter((c) => { const s = WT.card(deck, c.id); return s.n && s.due <= now; });
    const fresh = cards.filter((c) => !WT.card(deck, c.id).n);
    const rest = cards.filter((c) => { const s = WT.card(deck, c.id); return s.n && s.due > now; });
    return [...WT.shuffle(due), ...fresh, ...WT.shuffle(rest)].slice(0, n);
  };
  WT.cardQuestion = function (deck, card) {
    const others = WT.sample(WT.decks[deck].cards().filter((c) => c.id !== card.id && c.back !== card.back), 3).map((c) => c.back);
    const options = WT.shuffle([card.back, ...others]);
    return { deck, id: card.id, q: card.front, mono: true, options, answer: options.indexOf(card.back), why: card.back };
  };

  // ---------------------------------------------------------------- links (what was mapped right or wrong)
  WT.linkHit = function (fields, el, correct) {
    for (const f of fields) {
      const k = f + '>' + WT.norm(el);
      const s = WT.S.P.links[k] || { ok: 0, miss: 0 };
      if (correct) s.ok++; else s.miss++;
      s.at = WT.now();
      WT.S.P.links[k] = s;
    }
    WT.save();
  };
  WT.weakLinks = () => Object.entries(WT.S.P.links).filter(([, s]) => s.miss > s.ok).map(([k]) => k.split('>'));

  // ---------------------------------------------------------------- results
  WT.blockKey = (kind, block, level) => `${kind}|${block}|${level}`;
  WT.blockBest = (kind, block, level) => (WT.S.P.blocks[WT.blockKey(kind, block, level)] || {}).best;
  WT.blockDone = function (kind, block, level, pct) {
    const k = WT.blockKey(kind, block, level); const b = WT.S.P.blocks[k] || { n: 0 };
    b.n++; b.best = Math.max(b.best || 0, pct); b.last = pct; b.at = WT.now();
    WT.S.P.blocks[k] = b; WT.save();
  };
  WT.stepDone = function (id, pct) { const s = WT.S.P.steps[id] || { n: 0 }; s.n++; s.best = Math.max(s.best || 0, pct); s.at = WT.now(); WT.S.P.steps[id] = s; WT.save(); };
  WT.state = (pct) => (pct === undefined ? 'new' : pct >= 90 ? 'solid' : 'shaky');
  WT.passMark = function () {
    const P = WT.S.P; const kinds = ['customer', 'bank', 'drawdown'];
    const sheets = kinds.map((k) => { const days = new Set(P.sheets.filter((s) => s.kind === k && s.pct >= 90).map((s) => WT.day(s.at))); return { kind: k, days: days.size, best: Math.max(0, ...P.sheets.filter((s) => s.kind === k).map((s) => s.pct)) }; });
    const speed = ['syl', 'term'].map((d) => Object.assign({ deck: d }, WT.deckState(d)));
    return { sheets, speed, passed: sheets.every((s) => s.days >= 2) && speed.every((s) => s.solid >= Math.ceil(s.total * 0.9)) };
  };

  // ---------------------------------------------------------------- the bench model
  const addrOfField = (p) => { const i = p.indexOf('.address.'); return i > 0 ? p.slice(0, i) + '.address' : null; };
  const addrOfLeaf = (p) => { const i = p.indexOf('/PstlAdr/'); return i > 0 ? p.slice(0, i) + '/PstlAdr' : null; };
  WT.blocksOf = function (c) {
    const present = new Set(c.leaves.map((l) => l.b));
    const list = C.blocks.filter((b) => present.has(b.id));
    if (c.leaves.some((l) => l.p.startsWith('PmtInf/Dbtr/PstlAdr/'))) list.splice(Math.max(1, list.findIndex((b) => b.id === 'debtor') + 1), 0, { id: 'address', title: 'Postal address', say: 'Every party and every bank uses the same address parts. Learn them once, on the debtor.' });
    return list;
  };
  // slots (XML side) and chips (payload side) for one case, one block or the whole message
  WT.model = function (c, block) {
    const open = 'PmtInf/Dbtr/PstlAdr';
    const slots = []; const groups = {};
    for (const l of c.leaves) {
      const g = addrOfLeaf(l.p);
      if (block === 'address') { if (g === open) slots.push({ id: l.p, p: l.p, v: l.v, src: l.src.slice(), how: l.how }); continue; }
      if (g) {
        if (block && l.b !== block) continue;
        let s = groups[g];
        if (!s) { s = groups[g] = { id: g, p: g, group: true, n: 0, src: [], how: 'copy', v: '' }; slots.push(s); }
        s.n++; for (const f of l.src) { const a = addrOfField(f) || f; if (!s.src.includes(a)) s.src.push(a); }
        continue;
      }
      if (block && l.b !== block) continue;
      slots.push({ id: l.p, p: l.p, v: l.v, src: l.src.slice(), how: l.how });
    }
    for (const s of slots) if (s.group) s.v = s.n + (s.n === 1 ? ' part' : ' parts');
    const need = new Set(slots.flatMap((s) => s.src));
    const chips = []; const seen = {};
    for (const f of c.fields) {
      const a = block === 'address' && f.p.startsWith('payer.address.') ? null : addrOfField(f.p);
      const id = a || f.p;
      if (seen[id]) { seen[id].n++; continue; }
      const chip = seen[id] = { id, group: !!a, v: f.v, n: 1, mapped: f.to.length > 0 };
      chips.push(chip);
    }
    for (const ch of chips) if (ch.group) ch.v = ch.n + (ch.n === 1 ? ' field' : ' fields');
    let shown = chips;
    if (block) {
      const mine = chips.filter((ch) => need.has(ch.id));
      const extra = WT.sample(chips.filter((ch) => !need.has(ch.id) && ch.mapped && !ch.group), Math.min(3, Math.max(1, Math.round(mine.length / 3))));
      shown = WT.shuffle([...mine, ...extra]);
    }
    return { slots, chips: shown };
  };
  // the rows of the XML side: ancestors as plain rows, leaves as slots
  WT.rows = function (slots, sep = '/') {
    const rows = []; let prev = [];
    for (const s of slots) {
      const segs = s.p.split(sep); const leaf = segs.pop();
      let i = 0; while (i < segs.length && prev[i] === segs[i]) i++;
      for (; i < segs.length; i++) rows.push({ depth: i, tag: segs[i].replace(/\[\d+\]/, ''), path: segs.slice(0, i + 1).join(sep) });
      prev = segs;
      rows.push({ depth: segs.length, tag: leaf.replace(/\[(\d+)\]/, ' ($1)').replace('@', ' @'), slot: s });
    }
    return rows;
  };

  // ---------------------------------------------------------------- pick a case
  WT.pickCase = function (kind, fresh) {
    const pool = WT.S.cases.filter((c) => c.kind === kind && c.xml && (!fresh || !c.original));
    const unused = pool.filter((c) => !WT.S.P.used.includes(c.id));
    const c = (unused.length ? WT.sample(unused, 1) : WT.sample(pool, 1))[0];
    if (fresh && c) { WT.S.P.used.push(c.id); if (!unused.length) WT.S.P.used = [c.id]; WT.save(); }
    return c;
  };
  WT.original = (kind) => WT.S.cases.find((c) => c.kind === kind && c.original);

  // ---------------------------------------------------------------- question generators
  const OUTCOMES = ['The mapper rejects the payment.', 'The element it feeds is left out.', 'Another value is used in its place.', 'Nothing changes in the message.'];
  const excerpt = function (c, field) {      // the part of the payload a question is about
    const top = field.split('.')[0]; const v = c.payload[top];
    return JSON.stringify(v && typeof v === 'object' ? { [top]: v } : Object.fromEntries(Object.entries(c.payload).filter(([, x]) => typeof x !== 'object')), null, 1);
  };
  WT.genWithout = function (c, n) {
    const qs = [];
    for (const f of WT.shuffle(c.fields)) {
      const w = f.without; let answer, why;
      if (w.rejected) { answer = 0; why = 'The mapper answers: ' + w.rejected[0].replace('payload.', '') + '.'; }
      else if (w.gone.length) { answer = 1; why = [...new Set(w.gone.map(WT.shortPath))].slice(0, 3).join(', ') + ' is not written when the field is absent.'; }
      else if (w.changed.length) { answer = 2; why = WT.shortPath(w.changed[0][0]) + ' becomes ' + WT.short(w.changed[0][1], 40) + '. ' + WT.ruleFor(w.changed[0][0]); }
      else { answer = 3; why = f.to.length ? 'The output stays the same. ' + WT.ruleFor(f.to[0]) : (WT.fieldNote(f.p) || 'The mapper does not read this field.'); }
      qs.push({ q: 'The payload arrives without this field. What happens?', code: f.p, ctx: excerpt(c, f.p), options: OUTCOMES, answer, why, link: f.to[0] ? [[f.p], f.to[0]] : null });
    }
    // an even mix of the four outcomes
    const by = [0, 1, 2, 3].map((a) => qs.filter((q) => q.answer === a)); const out = [];
    for (let i = 0; out.length < n && i < 40; i++) { const q = by[i % 4].shift(); if (q) out.push(q); }
    return WT.shuffle(out);
  };
  WT.genValues = function (c, n) {
    const pool = {};
    for (const o of WT.S.cases) if (o.xml) for (const l of o.leaves) (pool[WT.norm(l.p)] = pool[WT.norm(l.p)] || new Set()).add(l.v);
    const qs = [];
    for (const l of WT.shuffle(c.leaves)) {
      if (l.how !== 'changed' || !l.src.length || l.v.length > 34) continue;
      const raw = WT.fmt(c.payload && l.src.reduce((a, f) => a || f.split('.').reduce((x, k) => (x == null ? x : x[k]), c.payload), null));
      if (raw !== '' && Number(raw) === Number(l.v)) continue;
      const others = WT.shuffle([...pool[WT.norm(l.p)]].filter((v) => v !== l.v && v !== raw)).slice(0, 2);
      const fill = ['OTHR', 'CACC', 'SHAR', 'CTR', 'BTR', 'DEBT', 'N', 'Y'].filter((v) => v !== l.v && v !== raw && !others.includes(v));
      const options = WT.shuffle([...new Set([l.v, raw, ...others, ...fill])].filter((v) => v !== '').slice(0, 4));
      if (options.length < 3 || !options.includes(l.v)) continue;
      qs.push({ q: 'What does this element contain?', code: WT.shortPath(l.p), ctx: excerpt(c, l.src[0]), options, answer: options.indexOf(l.v), why: WT.ruleFor(l.p), link: [l.src, l.p] });
      if (qs.length >= n) break;
    }
    return qs;
  };
  WT.genBackwards = function (c, n) {
    const qs = [];
    for (const l of WT.shuffle(c.leaves)) {
      if (!l.src.length || /PstlAdr/.test(l.p)) continue;
      const same = c.fields.filter((f) => !l.src.includes(f.p) && f.p.split('.').pop() === l.src[0].split('.').pop()).map((f) => f.p);
      const others = WT.shuffle(c.fields.filter((f) => !l.src.includes(f.p) && !same.includes(f.p) && !/\.address\./.test(f.p)).map((f) => f.p));
      const options = WT.shuffle([l.src[0], ...same.slice(0, 2), ...others].slice(0, 4));
      qs.push({ q: 'Which payload field does this element come from?', code: WT.shortPath(l.p) + (l.v ? '  =  ' + WT.short(l.v, 40) : ''), options, mono: true, answer: options.indexOf(l.src[0]), why: WT.ruleFor(l.p) + (l.src.length > 1 ? ' It is built from ' + l.src.length + ' fields.' : ''), link: [l.src, l.p] });
      if (qs.length >= n) break;
    }
    return qs;
  };
  WT.genForward = function (pairs) {         // weak links: field -> element
    return pairs.map(([f, el]) => {
      const options = WT.shuffle([el, ...WT.sample(WT.S.elements.filter((e) => e !== el && WT.tagOf(e) !== WT.tagOf(el)), 3)]);
      return { q: 'Which element does this field fill?', code: f, options: options.map(WT.shortPath), mono: true, answer: options.indexOf(el), why: WT.ruleFor(el), link: [[f], el] };
    });
  };
  WT.genReject = function (c) {
    const all = [...new Set(WT.S.cases.filter((x) => x.problems).flatMap((x) => x.problems))];
    const options = WT.shuffle([...c.problems, ...WT.sample(all.filter((p) => !c.problems.includes(p)), Math.max(3, 7 - c.problems.length))]);
    return { q: 'Which problems does the mapper report for this payload? Choose every one.', ctx: JSON.stringify(c.payload, null, 1), tall: true, options: options.map((p) => p.replace(/^payload\./, '')), answers: options.map((p, i) => (c.problems.includes(p) ? i : -1)).filter((i) => i >= 0), why: 'The first check reports all its problems at once, and nothing is built. A few checks, such as an unknown charge bearer, come later and show only when the first ones pass.' };
  };
  // optional parts of a message: is each one in this case?
  WT.PARTS = [
    ['Dbtr/Id', 'An identification of the debtor'], ['DbtrAcct/Tp', 'A type on the debtor account'], ['DbtrAgt/FinInstnId/BICFI', 'A BIC for the debtor agent'],
    ['DbtrAgt/FinInstnId/ClrSysMmbId', 'A clearing member id for the debtor agent'], ['UltmtDbtr', 'An ultimate debtor'], ['PmtTpInf/SvcLvl', 'A service level'],
    ['PmtTpInf/CtgyPurp', 'A category purpose'], ['Amt/InstdAmt', 'An instructed amount'], ['Amt/EqvtAmt', 'An equivalent amount'], ['XchgRateInf', 'Exchange rate information'],
    ['ChrgBr', 'A charge bearer'], ['IntrmyAgt1/', 'A first intermediary agent'], ['IntrmyAgt1Acct', 'An account for the first intermediary'], ['IntrmyAgt2/', 'A second intermediary agent'],
    ['CdtrAgt/FinInstnId/BICFI', 'A BIC for the creditor agent'], ['CdtrAgt/FinInstnId/ClrSysMmbId', 'A clearing member id for the creditor agent'], ['CdtrAgtAcct', 'An account for the creditor agent'],
    ['CdtrAcct/Id/IBAN', 'The creditor account as an IBAN'], ['CdtrAcct/Id/Othr', 'The creditor account as another id'], ['UltmtCdtr', 'An ultimate creditor'],
    ['InstrForCdtrAgt', 'Instructions for the creditor agent'], ['Purp/', 'A purpose'], ['RmtInf/Ustrd', 'Unstructured remittance text'], ['RmtInf/Strd', 'Structured remittance'],
  ];
  WT.partsOf = (c) => WT.PARTS.map(([key, label]) => ({ id: key, label, sub: key.replace(/\/$/, ''), bin: c.leaves.some((l) => WT.norm(l.p).includes(key)) ? 'in' : 'out' }));
})();
