// "What is this?" Hover any field, tag or code and a card says what it is, why it exists and how it is used.
// The three tables below are hand-written. Where a card shows where a field goes or what happens
// without it, that part comes from the traced cases, not from here.
(function () {
  const WT = window.WT; const C = WT.content;

  // ---- codes: the values that sit in fields and elements
  C.values = {
    CTRC: { of: 'paymentTypeCode', what: 'Customer transfer, in the payload\'s own spelling.', why: 'A wire is either a customer paying a customer, a bank paying a bank, or a request to be paid. Every system on the way treats these differently.', how: 'The mapper writes it as CTR in LclInstrm. The network reads that code.' },
    BTRC: { of: 'paymentTypeCode', what: 'Bank transfer, in the payload\'s own spelling.', why: 'Banks also move their own money between themselves. That is not a customer payment and settles under different rules.', how: 'The mapper writes it as BTR in LclInstrm.' },
    CTR: { of: 'LclInstrm', what: 'Customer transfer: a customer or company pays another customer or company.', why: 'The network needs to know the kind of wire to pick the right message and rules. CTR is the Fedwire code for it.', how: 'It tells the correspondent bank to send a customer credit transfer. Debtor and creditor are customers; both banks are only agents.' },
    BTR: { of: 'LclInstrm', what: 'Bank transfer: one bank pays another bank for its own account.', why: 'A bank moving its own funds has no customer behind it, so there is less to carry and to screen.', how: 'It tells the correspondent bank to send a bank-to-bank transfer. Debtor and creditor are banks.' },
    DRC: { of: 'LclInstrm', what: 'Drawdown request for a customer or company: a request to be paid.', why: 'Sometimes the party that is owed starts the wire. It asks the payer\'s bank to send money from an account it is allowed to draw on.', how: 'It passes through the mapper unchanged. The bank that receives it answers with a payment, if the account holder has agreed to drawdowns.' },
    DRB: { of: 'LclInstrm', what: 'Drawdown request between banks.', why: 'The bank-to-bank form of a drawdown.', how: 'It passes through the mapper unchanged. HERA is to route it to the drawdown saga beside DRC and does not accept it yet.' },
    SHAR: { of: 'ChrgBr', what: 'Shared charges. Each side pays its own bank.', why: 'Banks charge for a wire. Someone has to say who pays, or a bank on the way would not know whether it may take its fee out of the money.', how: 'The originator pays the sending bank\'s fee on top. The beneficiary pays its own bank\'s fee, and on an international wire the banks in between may take theirs out of the amount.' },
    DEBT: { of: 'ChrgBr', what: 'All charges are paid by the debtor, the originator.', why: 'Used when the beneficiary must get the full amount, for example to settle an invoice exactly.', how: 'No bank on the way may deduct a fee from the amount. They bill the sending side.' },
    CRED: { of: 'ChrgBr', what: 'All charges are paid by the creditor, the beneficiary.', why: 'Used when the originator will not carry any cost of the transfer.', how: 'Every bank on the way takes its fee out of the amount, so the beneficiary gets less than was sent.' },
    SLEV: { of: 'ChrgBr', what: 'Charges follow the rules of the service level.', why: 'Some schemes fix who pays, so the wire only points at the scheme.', how: 'Rare for the wires here. The mapper passes it through.' },
    OUR: { of: 'chargedTo', what: 'The older word for "the originator pays all charges".', why: 'It comes from the SWIFT message that came before ISO 20022. Many channels still send it.', how: 'The mapper turns it into DEBT.' },
    BEN: { of: 'chargedTo', what: 'The older word for "the beneficiary pays all charges".', why: 'It comes from the SWIFT message that came before ISO 20022.', how: 'The mapper turns it into CRED.' },
    SHA: { of: 'chargedTo', what: 'The older word for shared charges.', why: 'It comes from the SWIFT message that came before ISO 20022.', how: 'The mapper turns it into SHAR.' },
    TRF: { of: 'PmtMtd', what: 'Transfer: money moves from the debtor\'s account to the creditor.', why: 'pain.001 can also order a cheque. The method says which.', how: 'Always TRF here. It is a constant in the mapper.' },
    HIGH: { of: 'InstrPrty', what: 'High priority.', why: 'A wire is the urgent way to pay. The message says so, so that no bank queues it behind slower payments.', how: 'Always HIGH here. It is a constant in the mapper.' },
    USABA: { of: 'ClrSysId', what: 'The code for the United States routing number system.', why: 'A bank number means nothing without the system it belongs to. Every country has its own.', how: 'It sits beside the nine-digit routing number in MmbId. A nine-digit bank code with no system is taken as USABA.' },
    CACC: { of: 'Tp', what: 'Current account: a checking account.', why: 'The receiving side may need to know what kind of account is debited or credited.', how: 'Written for the debtor account when the payload says DDA or checking.' },
    SVGS: { of: 'Tp', what: 'Savings account.', why: 'Savings accounts are handled differently from checking accounts by some banks.', how: 'Written when the payload says SAV or savings.' },
    OTHR: { of: 'Tp', what: 'Other: none of the standard account types.', why: 'The standard list is closed, so there has to be a way to say "something else".', how: 'Written when the payload\'s account type is neither checking nor savings.' },
    DDA: { of: 'accountIdType', what: 'Demand deposit account: a checking account.', why: 'It is the United States banking word for an account you can pay from at any time.', how: 'The mapper writes it as CACC.' },
    D: { of: 'accountIdType', what: 'Short for DDA, a checking account.', why: 'Some channels send the one-letter form.', how: 'The mapper writes it as CACC.' },
    SAV: { of: 'accountIdType', what: 'Savings account.', why: 'The payload\'s own word for it.', how: 'The mapper writes it as SVGS.' },
    IBAN: { of: 'accountIdType', what: 'The account number is an International Bank Account Number.', why: 'An IBAN carries the country, the bank and the account in one checked number. Many countries require it.', how: 'The mapper then writes the number in Id/IBAN, not in Othr/Id.' },
    TXID: { of: 'SchmeNm', what: 'Tax identification number.', why: 'An id number is only useful when you know what kind it is.', how: 'It names the kind of the company id in OrgId.' },
    CCPT: { of: 'SchmeNm', what: 'Passport number.', why: 'An id number is only useful when you know what kind it is.', how: 'It names the kind of the personal id in PrvtId.' },
    SUPP: { of: 'Purp, CtgyPurp', what: 'Supplier payment.', why: 'A purpose code lets banks and the beneficiary sort and report payments without reading free text.', how: 'Copied to Purp or CtgyPurp as a code.' },
    TRAD: { of: 'CtgyPurp', what: 'Trade: payment for goods or services.', why: 'A purpose code lets banks sort and report payments without reading free text.', how: 'Copied to CtgyPurp as a code.' },
    URGP: { of: 'SvcLvl', what: 'Urgent payment.', why: 'A service level names the agreement the payment runs under.', how: 'Copied to SvcLvl as a code.' },
    SPOT: { of: 'RateTp', what: 'The market rate at the moment of the deal.', why: 'The bank that converts the money must know which rate was promised.', how: 'Written to XchgRateInf/RateTp.' },
    AGRD: { of: 'RateTp', what: 'A rate agreed beforehand in a contract.', why: 'A company can fix a rate with the bank in advance. The wire then points at that contract.', how: 'Written to RateTp, with the contract in CtrctId.' },
    SALE: { of: 'RateTp', what: 'A sale rate.', why: 'One of the three rate types the standard knows.', how: 'Written to RateTp.' },
    CINV: { of: 'documentCode', what: 'Commercial invoice.', why: 'It says what kind of document the payment settles.', how: 'It is in the payload, and the mapper does not write it.' },
    Frb: { of: 'paymentType', what: 'The wire is meant for the Fed network.', why: 'Payment Exchange has to know the route. The external API sets this from the clearing channel of the request: FED becomes Frb.', how: 'It is not written to the message. OPF picks the route itself.' },
    FRB: { of: 'paymentType', what: 'The wire is meant for the Fed network. The spelling seen in Capital One events from UAT.', why: 'Payment Exchange has to know the route.', how: 'It is not written to the message. OPF chooses the route itself.' },
    NOS: { of: 'paymentType', what: 'The wire is meant for SWIFT, through an account at another bank. Capital One events from UAT write NOS or nos.', why: 'Payment Exchange has to know the route.', how: 'It is not written to the message. OPF chooses the route itself.' },
    Nos: { of: 'paymentType', what: 'The wire is meant for SWIFT, through an account at another bank.', why: 'Payment Exchange has to know the route. The external API sets this from the clearing channel of the request: SWIFT becomes Nos.', how: 'It is not written to the message. OPF picks the route itself.' },
    'PULSE-WIRE': { of: 'senderMemberId', what: 'A sender member id: wires of the PULSE network.', why: 'HERA must know which channel a wire belongs to in order to pick the right saga, and OPF counts wires per channel.', how: 'It is not written to the message today.' },
    Wire: { of: 'paymentType', what: 'The rail is a wire. A value of the mapper\'s own samples; a real payload says Frb or Nos.', why: 'Payment Exchange handles many kinds of payment and must send each to the right rail.', how: 'It gets the payment to Wire II. It is not written to the message.' },
    FederalReserveBank: { of: 'clearingSystem', what: 'The wire is meant for the Fed network.', why: 'Domestic dollar wires settle over Fedwire; others go over SWIFT.', how: 'It is not written to the message. In this phase OPF picks the route itself.' },
    SWIFT: { of: 'clearingSystem', what: 'The wire is meant for the SWIFT network.', why: 'International wires travel as SWIFT messages between banks.', how: 'It is not written to the message. In this phase OPF picks the route itself.' },
    Proprietary: { of: 'SchmeNm', what: 'The account number follows no named standard.', why: 'When a number is not an IBAN, the standard asks what scheme it follows.', how: 'A fixed word on the creditor account, as FIS writes it.' },
    PAYX: { of: 'senderMemberId', what: 'A sender member id: Payment Exchange itself.', why: 'HERA must know which channel a wire belongs to in order to pick the right saga.', how: 'It is not written to the message.' },
    TMOBS: { of: 'senderMemberId', what: 'A sender member id of one sending channel.', why: 'HERA must know which channel a wire belongs to.', how: 'It is not written to the message.' },
    WSSAPI: { of: 'senderMemberId', what: 'A sender member id of an existing Capital One channel, seen in events from UAT: an API channel of a commercial platform. Not a Discover channel.', why: 'HERA must know which channel a wire belongs to.', how: 'It is not written to the message.' },
    EaseAdmin: { of: 'senderMemberId', what: 'A sender member id of an existing Capital One channel, seen in an event from UAT: wires keyed for customers by bank staff. Not a Discover channel.', why: 'HERA must know which channel a wire belongs to.', how: 'It is not written to the message.' },
    nos: { of: 'paymentType', what: 'The same as NOS, in small letters, as one Capital One event from UAT writes it.', why: 'Payment Exchange has to know the route.', how: 'It is not written to the message. OPF chooses the route itself.' },
    Person: { of: 'FIS extension', what: 'A fixed FIS setting: how the instruction was given.', why: 'FIS asks for it in its own supplement.', how: 'A setting in the mapper, not from the payload.' },
    Consumer: { of: 'FIS extension', what: 'A fixed FIS setting: the kind of account.', why: 'FIS asks for it in its own supplement.', how: 'A setting in the mapper, not from the payload.' },
  };

  // ---- tags: what each element is for
  C.concepts = {
    GrpHdr: { what: 'The header of the whole message.', why: 'The receiver must be able to name the message, see when it was made and check that nothing is missing.', how: 'One per message. OPF reads it first.' },
    MsgId: { what: 'The id of this message.', why: 'So that sender and receiver can talk about one message, and so that a repeat can be recognised.', how: 'Here it is the client transaction id.' },
    CreDtTm: { what: 'When the message was created.', why: 'For ordering and for the audit trail.', how: 'The mapper\'s clock, in UTC.' },
    NbOfTxs: { what: 'How many payments the message holds.', why: 'A check: the receiver counts and compares.', how: 'Always 1 here.' },
    CtrlSum: { what: 'The total of all amounts in the message.', why: 'A check against a payment lost or changed on the way.', how: 'With one wire it equals the amount.' },
    InitgPty: { what: 'The party that asked for the payment.', why: 'It can differ from the debtor: a parent company or a service provider can initiate for someone else.', how: 'Required by the standard. From the payload when it names one.' },
    PmtInf: { what: 'The debit side: who pays, from which account, at which bank, when.', why: 'One debtor can pay many wires from one account, so these facts sit one level above the wire.', how: 'One per message here.' },
    PmtInfId: { what: 'The id of this payment information block.', why: 'So the block can be named in a status report.', how: 'The client transaction id again.' },
    PmtMtd: { what: 'How to pay: transfer or cheque.', why: 'pain.001 covers both.', how: 'Always TRF.' },
    BtchBookg: { what: 'Whether to book the block as one line or each payment on its own.', why: 'Matters for the debtor\'s statement when a block holds many payments.', how: 'Always false: one wire, booked on its own.' },
    ReqdExctnDt: { what: 'The day the debtor wants the payment executed.', why: 'A wire can be sent today for a later day. The bank needs the day.', how: 'From the value date. OPF sets the final value date with its holiday calendar.' },
    Dbtr: { what: 'The debtor: the party whose account is debited.', why: 'Every bank on the way must know who is paying, for screening and for the beneficiary.', how: 'From payer: name, address and id.' },
    DbtrAcct: { what: 'The account the money leaves from.', why: 'The debtor\'s bank must know which account to debit.', how: 'From the payer\'s account number, still as a token inside Capital One.' },
    DbtrAgt: { what: 'The debtor\'s bank.', why: 'The next bank needs to know where the money comes from.', how: 'From payerBank, named by routing number or BIC.' },
    CdtTrfTxInf: { what: 'One payment: its ids, type, amount and the whole credit side.', why: 'Everything that belongs to this one wire and could differ on the next.', how: 'One per message here.' },
    PmtId: { what: 'The ids of this payment.', why: 'Different parties need different references: bank to bank, payer to payee, and one for the whole route.', how: 'Three ids: InstrId, EndToEndId and UETR.' },
    InstrId: { what: 'A reference between one bank and the next.', why: 'Two neighbours on the route need a number for their own leg.', how: 'It does not travel to the beneficiary.' },
    EndToEndId: { what: 'The originator\'s own reference.', why: 'So the beneficiary can tell which invoice or order was paid.', how: 'It travels unchanged from the first bank to the last.' },
    UETR: { what: 'One unique id for the payment across every bank.', why: 'Before it, each bank had its own reference and nobody could follow a wire end to end.', how: 'A version 4 UUID. Banks and SWIFT use it to trace a wire and to spot a duplicate.' },
    PmtTpInf: { what: 'What kind of payment this is.', why: 'The kind decides the rules, the speed and the network.', how: 'Priority, local instrument, service level and category purpose.' },
    InstrPrty: { what: 'How urgent the instruction is.', why: 'So no bank holds a wire behind slower payments.', how: 'Always HIGH.' },
    LclInstrm: { what: 'The kind of wire in the words of the local network.', why: 'The standard is worldwide; each network has its own list of payment kinds. This is where that word goes.', how: 'CTR, BTR or DRC: the Fedwire codes.' },
    SvcLvl: { what: 'The service agreement the payment runs under.', why: 'It names rules both sides already know, such as "urgent".', how: 'Optional. Copied when the payload has one.' },
    CtgyPurp: { what: 'The broad category of the payment.', why: 'Banks use it to treat whole classes of payments in a certain way, such as salaries.', how: 'Optional. For the banks on the way.' },
    Amt: { what: 'How much to move.', why: 'The core of the payment.', how: 'Either InstdAmt, or EqvtAmt for an FX wire.' },
    InstdAmt: { what: 'The amount to move, in the currency to move.', why: 'The plain case: send this much of this currency.', how: 'The currency is an attribute on the element.' },
    EqvtAmt: { what: 'The amount to debit in the debtor\'s currency, with the currency to send.', why: 'For an FX wire the payer knows what it will pay, not what will arrive.', how: 'Used when the payload carries a debit amount and a foreign currency.' },
    CcyOfTrf: { what: 'The currency the beneficiary is to receive.', why: 'With an equivalent amount, the target currency must be stated separately.', how: 'From the foreign currency of the exchange details.' },
    XchgRateInf: { what: 'The exchange rate promised for this payment.', why: 'The bank that converts must apply the rate that was agreed.', how: 'Rate, rate type and contract id.' },
    XchgRate: { what: 'The rate itself.', why: 'So the converting bank applies the agreed rate.', how: 'From the exchange details of the payload.' },
    RateTp: { what: 'The kind of rate.', why: 'Spot, sale and agreed rates are handled differently.', how: 'SPOT, SALE or AGRD.' },
    CtrctId: { what: 'The id of the FX contract.', why: 'An agreed rate lives in a contract; the bank looks it up by this id.', how: 'From the exchange details of the payload.' },
    ChrgBr: { what: 'Who pays the banks\' fees.', why: 'Without it a bank on the way would not know whether it may take its fee out of the money.', how: 'DEBT, CRED, SHAR or SLEV. Left out when the payload does not say.' },
    UltmtDbtr: { what: 'The party on whose behalf the debtor pays.', why: 'A company can pay for another, such as a parent for a subsidiary. The beneficiary and the screening need the real payer.', how: 'From ultimateDebtor. Optional.' },
    IntrmyAgt1: { what: 'A bank between the debtor\'s bank and the creditor\'s bank.', why: 'Two banks without an account with each other need a bank both know to pass the money on.', how: 'From firstIntermediaryBank. Common on international wires.' },
    IntrmyAgt1Acct: { what: 'The intermediary bank\'s account at the bank before it.', why: 'It tells the earlier bank which account to credit.', how: 'From the intermediary\'s bankAccountNumber.' },
    IntrmyAgt2: { what: 'A second bank in between.', why: 'Some routes need two steps.', how: 'From secondaryIntermediaryBank.' },
    CdtrAgt: { what: 'The creditor\'s bank.', why: 'The network delivers the money to a bank, not to a person. This says which bank.', how: 'From payeeBank, by routing number or BIC. Routing depends on it.' },
    CdtrAgtAcct: { what: 'The creditor\'s bank\'s own account at the bank before it.', why: 'It tells the earlier bank which account to credit.', how: 'From payeeBank.bankAccountNumber.' },
    Cdtr: { what: 'The creditor: the party that is paid.', why: 'The receiving bank checks the name against the account, and every bank screens it.', how: 'From payee: name and address.' },
    CdtrAcct: { what: 'The account the money goes to.', why: 'The receiving bank credits by account number.', how: 'An IBAN, or another number marked Proprietary.' },
    UltmtCdtr: { what: 'The party that finally gets the money, when it is not the account holder.', why: 'The creditor can collect for someone else.', how: 'From ultimateCreditor. Optional.' },
    InstrForCdtrAgt: { what: 'Instructions for the creditor\'s bank.', why: 'The sender sometimes has to tell the receiving bank something, such as "advise by phone".', how: 'From bankToBank. Each line at most 140 characters.' },
    Purp: { what: 'Why this payment is made, as a code.', why: 'For the beneficiary and for reporting, without reading free text.', how: 'From transactionReasonCd.' },
    RmtInf: { what: 'What the payment is for, for the beneficiary.', why: 'So the beneficiary can match the money to an invoice.', how: 'Free text in Ustrd, or fields in Strd.' },
    Ustrd: { what: 'Remittance information as free text.', why: 'The simplest way to say "invoice 123".', how: 'One element per line, at most 140 characters.' },
    Strd: { what: 'Remittance information as fields.', why: 'Fields can be matched by a program; free text cannot.', how: 'Here: who issued the invoice and to whom.' },
    SplmtryData: { what: 'A slot for data outside the standard.', why: 'Every institution has a few needs the standard does not cover.', how: 'FIS expects two: one on the payment information, one on the transaction.' },
    FinInstnId: { what: 'How a bank is named.', why: 'A bank can be named by BIC, by a national number, by name or by LEI. This groups them.', how: 'At least a BIC or a clearing member id.' },
    BICFI: { what: 'The bank\'s BIC: its address on SWIFT.', why: 'One worldwide code per bank.', how: '8 or 11 characters. Used for international routing.' },
    ClrSysMmbId: { what: 'The bank named by its number in a national clearing system.', why: 'Domestic networks route by national numbers, not by BIC.', how: 'The system code plus the member number.' },
    ClrSysId: { what: 'Which national system the number belongs to.', why: 'The number alone is ambiguous.', how: 'USABA for a United States routing number.' },
    MmbId: { what: 'The bank\'s number in that system.', why: 'It is what the network routes by.', how: 'For USABA: the nine-digit routing number.' },
    LEI: { what: 'Legal entity identifier.', why: 'A worldwide id for a company or a bank, used for screening and reporting.', how: '20 characters. Optional.' },
    IBAN: { what: 'An International Bank Account Number.', why: 'It carries country, bank and account in one checked number.', how: 'Used when the payload marks the account number as an IBAN.' },
    Othr: { what: 'An identification that is not one of the named kinds.', why: 'Not every number is an IBAN or a BIC.', how: 'The number goes in Id, its kind in SchmeNm.' },
    SchmeNm: { what: 'The kind of an identification.', why: 'A number is only useful when you know what it is.', how: 'A code such as TXID, or a proprietary word.' },
    PstlAdr: { what: 'A postal address.', why: 'Name and address identify a party for screening and for the beneficiary bank.', how: 'Each part has its own tag. Free lines go in AdrLine.' },
    OrgId: { what: 'The identification of a company.', why: 'Names repeat; a tax id or an LEI does not.', how: 'A company id with its kind, or an LEI.' },
    PrvtId: { what: 'The identification of a person.', why: 'For a person, an id number or birth date and place set them apart from namesakes.', how: 'A personal id with its kind, and date and place of birth.' },
    Tp: { what: 'The type of the account.', why: 'Some banks treat checking and savings accounts differently.', how: 'CACC, SVGS or OTHR on the debtor account.' },
    Nm: { what: 'A name.', why: 'Banks screen names and match them to the account.', how: 'At most 140 characters.' },
    Ccy: { what: 'A currency, as a three-letter ISO code.', why: 'An amount means nothing without its currency.', how: 'USD, EUR and so on.' },
    Ctry: { what: 'A country, as a two-letter ISO code.', why: 'Screening and routing depend on the country.', how: 'US, DE and so on.' },
    BldgNm: { what: 'The name of a building.', why: 'Some addresses have a building name where others have a number.', how: 'From buildingName.' },
    PstBx: { what: 'A post office box.', why: 'Some parties receive their mail at a box, not at a street.', how: 'From postalBox.' },
    Room: { what: 'A room or suite inside a building.', why: 'A large building needs more than a street number.', how: 'From room.' },
    TwnLctnNm: { what: 'A named place inside a town.', why: 'Some addresses are given by a neighbourhood or locality.', how: 'From townLocationName.' },
    DstrctNm: { what: 'A district: a part of a region.', why: 'Some countries use a level between the town and the state.', how: 'From districtName.' },
    // tags that only group others: they appear as parent rows of the message
    Id: { what: 'An identification: the number or code that names what it sits in.', why: 'A name can repeat or be misspelled. A number cannot.', how: 'It holds the number and, where needed, what kind of number it is.' },
    Envlp: { what: 'The wrapper around supplementary data.', why: 'The standard asks for extra data to sit in one envelope, apart from the standard elements.', how: 'Here it holds the FIS supplement.' },
    paymentInformationSupplement: { what: 'The FIS additions for the payment information block.', why: 'FIS needs a few things the standard has no element for.', how: 'The FIS receipt id, the FIS trace id and the extension block.' },
    transactionInformationSupplement: { what: 'The FIS additions for the one transaction.', why: 'FIS needs its own trace id on the transaction.', how: 'Holds the FIS trace id of the transaction, taken from the client transaction id.' },
    extension: { what: 'A block of FIS settings for the payment.', why: 'FIS needs them to process the wire, and the standard has no place for them.', how: 'The international flag is worked out from the currency. The others are fixed in the mapper.' },
    Invcr: { what: 'The party that issued the invoice.', why: 'So the beneficiary can tell whose invoice is paid.', how: 'From the invoicer identification of the remittance details.' },
    Invcee: { what: 'The party the invoice was issued to.', why: 'It can differ from the party that pays.', how: 'From the invoicee identification of the remittance details.' },
    DtAndPlcOfBirth: { what: 'When and where a person was born.', why: 'It sets a person apart from others with the same name, for screening.', how: 'Birth date, city and country of birth.' },
  };
  // ---- why some payload fields exist at all
  C.fieldWhy = {
    paymentTypeCode: 'One code decides the kind of wire for every system after this one.',
    chargedTo: 'Banks charge for a wire. This says who pays, so no bank has to guess.',
    valueDate: 'A wire can be keyed today for another day. The banks need the day the money should arrive.',
    clientTransactionId: 'The sender needs its own number to ask about the wire later. Here it also names the message.',
    endToEndId: 'The originator\'s reference is what lets the beneficiary match the money to an invoice.',
    swiftEndToEndTransactionReference: 'One id that every bank on the route keeps, so the wire can be traced and a repeat recognised.',
    transactionAmount: 'The amount. For an FX wire it is what the originator pays, not what arrives.',
    currencyCode: 'An amount means nothing without its currency.',
    bankToBank: 'Sometimes the sending side must tell the receiving bank something that fits no field.',
    accountNumber: 'Banks debit and credit by account number, not by name.',
    accountIdType: 'It tells the mapper how to write the account: as an IBAN or as another number, and of which type.',
    bankCode: 'Domestic networks route by a national bank number.',
    bankSystemIdentifier: 'A bank number needs the name of the system it belongs to.',
    swiftBankIdentifierCode: 'International wires route by BIC.',
    bankAccountNumber: 'When banks pass money along a chain, each needs to know which account of the next bank to credit.',
    unstructuredInfo: 'The beneficiary needs to know what was paid.',
    exchangeRate: 'An FX wire must carry the rate that was promised, or the converting bank would apply its own.',
    senderMemberId: 'HERA uses it to decide which saga runs the wire.',
    accountName: 'Banks screen the name and compare it with the account.',
  };

  // ---- what version 11 of pain.001 changed from version 9, by tag: 'new' did not exist in version 9, 'changed' exists in both and differs.
  // Every other tag of the message is the same in both versions.
  C.tags.InitnSrc = 'Initiation source'; C.tags.ReqdAdvcTp = 'Requested advice type';
  C.tags.DbtrAgtAcct = C.tags.DbtrAgtAcct || 'Debtor agent account'; C.tags.IntrmyAgt2Acct = C.tags.IntrmyAgt2Acct || 'Intermediary agent 2 account';
  C.concepts.InitnSrc = { what: 'The software or channel the payment was started from.', why: 'So the receiver can tell which system or channel sent the instruction.', how: 'A name and, if wanted, the provider and the version. Optional. The mapper does not write it.' };
  C.concepts.ReqdAdvcTp = { what: 'A request for an advice: a notice from the bank that the account was debited or credited.', why: 'A customer can ask to be told when the booking happens.', how: 'A credit advice, a debit advice or both, each with or without details. Optional. The mapper does not write it.' };
  // Each entry answers three questions in the same order: how was it in version 9, how is it in version 11, what does that mean for a wire.
  // Only tags where the difference sits on the tag itself are listed. A block that merely contains one of them is not marked.
  // The list below is the whole result of comparing the two official schemas element by element (data/v9-v11.json, checked by npm test).
  // re finds the element by its path. touches says whether a wire built here contains it.
  C.v11 = [
    { where: 'Id of an account', places: 8, re: /Acct\/Id$/, kind: 'changed', touches: true, v9: 'The account number (Id) must be there.', v11: 'The account number is optional.', wire: 'No effect. A wire still sends the account number.', note: 'Applies to every account: debtor, creditor, each agent account and the charges account.' },
    { where: 'GrpHdr/InitnSrc', places: 1, re: /(^|\/)InitnSrc$/, kind: 'new', touches: false, v9: 'Does not exist.', v11: 'Optional. Names the software or channel that started the payment: a name, and if wanted the provider and the version.', wire: 'Not used. The mapper does not write it.', note: 'It may be where the source channel that OPF asks for belongs. FIS has not said which element it wants.' },
    { where: 'PmtInf/ReqdAdvcTp', places: 1, re: /(^|\/)ReqdAdvcTp$/, kind: 'new', touches: false, v9: 'Does not exist.', v11: 'Optional. Asks the bank for a notice when the account is debited or credited, with or without details.', wire: 'Not used. The mapper does not write it.' },
    { where: 'CdtTrfTxInf/MndtRltdInf', places: 1, re: /(^|\/)MndtRltdInf$/, kind: 'new', touches: false, v9: 'Does not exist.', v11: 'Optional. The standing order behind a payment: its id, type, dates, how often it runs and why.', wire: 'Not used. A wire is a single payment.' },
    { where: 'InstrForCdtrAgt/Cd', places: 1, re: /InstrForCdtrAgt\/Cd$/, kind: 'changed', touches: false, v9: 'One of four fixed codes: CHQB, HOLD, PHOB, TELB.', v11: 'Any code of up to four characters, from a list kept outside the schema.', wire: 'No effect. The mapper sends free text (InstrInf), not a code.' },
    { where: 'CdtTrfTxInf/InstrForDbtrAgt', places: 1, re: /CdtTrfTxInf\/InstrForDbtrAgt$/, kind: 'changed', touches: false, v9: 'Free text of up to 140 characters.', v11: 'A code plus free text (Cd, InstrInf).', wire: 'Not used. The mapper does not write it.', note: 'The element of the same name one level up, in PmtInf, is free text in both versions.' },
    { where: 'Tax period: Prd/Yr', places: 4, re: /Prd\/Yr$/, kind: 'changed', touches: false, v9: 'A full date.', v11: 'A year only.', wire: 'Not used. A wire here carries no tax data.', note: 'In the tax block and in the tax part of structured remittance information.' },
  ];
  WT.v11Of = (p) => { const n = String(p).replace(/\[\d+\]/g, '').split('@')[0]; return C.v11.find((v) => v.re.test(n)) || null; };
  WT.v11Label = (kind) => (kind === 'new' ? 'new in V11' : 'changed in V11');

  // ---- short forms: what the letters stand for, then what the thing is. null means the program documents give no long form.
  C.short = {
    ISO: ['International Organization for Standardization', 'The body that publishes ISO 20022, the standard behind pain.001.'],
    SWIFT: ['Society for Worldwide Interbank Financial Telecommunication', 'The network banks use to send payment messages across borders.'],
    BIC: ['Business Identifier Code', 'A bank\'s address on SWIFT, 8 or 11 characters. It used to be called Bank Identifier Code.'],
    BICFI: ['Business Identifier Code of a Financial Institution', 'The tag that holds a bank\'s BIC.'],
    IBAN: ['International Bank Account Number', 'Country, bank and account in one checked number.'],
    LEI: ['Legal Entity Identifier', '20 characters that name a company or a bank worldwide.'],
    UETR: ['Unique End-to-end Transaction Reference', 'One id that follows a wire across every bank.'],
    UUID: ['Universally Unique Identifier', 'A 36-character id made so that no two are alike.'],
    ABA: ['American Bankers Association', 'In daily use it means the nine-digit United States routing number, which that association introduced.'],
    USABA: ['United States, American Bankers Association', 'The code for the United States routing number system.'],
    FX: ['Foreign Exchange', 'Changing one currency into another.'],
    DDA: ['Demand Deposit Account', 'A checking account.'],
    API: ['Application Programming Interface', 'The way one program asks another to do something.'],
    JSON: ['JavaScript Object Notation', 'A plain-text format for data, written as names and values.'],
    XML: ['Extensible Markup Language', 'A plain-text format for data, written as nested tags.'],
    UTC: ['Coordinated Universal Time', 'The world\'s reference clock, with no time zone offset.'],
    USD: ['United States Dollar', 'The ISO currency code of the dollar.'],
    EUR: ['Euro', 'The ISO currency code of the euro.'],
    FIS: ['Fidelity National Information Services', 'The company that runs OPF.'],
    OPF: ['Open Payment Framework', 'The FIS payment hub that settles the wire with the banks in Phase 1.'],
    PayX: ['Payment Exchange', 'Capital One\'s payment platform, which processes the wire before the rail.'],
    OFAC: ['Office of Foreign Assets Control', 'The United States Treasury office that keeps the sanctions lists.'],
    JPMC: ['JPMorgan Chase & Co.', 'A bank.'],
    BNY: ['Bank of New York Mellon', 'A bank.'],
    HERA: [null, 'The internal name of the PayX payment request API. It turns the external API request into the payment object.'],
    SDP: [null, 'The name of PayX\'s private event stream. The SDP payload is the payment object carried on it.'],
    'pain.001': ['Payment Initiation, message 001', 'The ISO 20022 message "customer credit transfer initiation": a customer asks its bank to pay.'],
    // codes: the word behind the letters. What the code does comes from the table of values above.
    WSSAPI: [null, 'A sender member id of an existing Capital One channel, seen in events from UAT. The sources do not spell it out.'],
    FRB: ['Federal Reserve Bank'], NOS: [null, 'The route over SWIFT through an account at another bank; read as "nostro". The sources give no long form.'],
    CTR: ['Customer Transfer'], BTR: ['Bank Transfer'], DRC: ['Drawdown Request, Customer or Corporate'], DRB: ['Drawdown Request, Bank to Bank'],
    CTRC: ['Customer Transfer', 'Customer transfer, in the payload\'s own spelling. The sources do not say what the last C stands for.'],
    BTRC: ['Bank Transfer', 'Bank transfer, in the payload\'s own spelling. The sources do not say what the last C stands for.'],
    SHAR: ['Shared'], DEBT: ['Borne by Debtor'], CRED: ['Borne by Creditor'], SLEV: ['Following Service Level'], OUR: ['Our, as in "our side pays"', 'The older word for "the originator pays all charges": our side pays.'], BEN: ['Beneficiary'], SHA: ['Shared'],
    TRF: ['Transfer'], CACC: ['Current Account'], SVGS: ['Savings'], OTHR: ['Other'], SAV: ['Savings'],
    TXID: ['Tax Identification'], CCPT: [null, 'Passport number. A code of the standard, not initials.'], SUPP: ['Supplier Payment'], TRAD: ['Trade'], URGP: ['Urgent Payment'], AGRD: ['Agreed'], CINV: ['Commercial Invoice'],
    PAYX: ['Payment Exchange'], TMOBS: [null, 'A sender member id of one sending channel. The sources do not spell it out.'],
  };
  const SHORT_RE = new RegExp('(?<![A-Za-z0-9_./@])(' + Object.keys(C.short).sort((a, b) => b.length - a.length).map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')(?=s?(?![A-Za-z0-9_]))', 'g');
  WT.shortWhat = (k) => (C.short[k] && C.short[k][1]) || (C.values[k] ? C.values[k].what : '');

  // ---------------------------------------------------------------- the card
  const PARENTS =['Dbtr', 'DbtrAcct', 'DbtrAgt', 'Cdtr', 'CdtrAcct', 'CdtrAgt', 'CdtrAgtAcct', 'IntrmyAgt1', 'IntrmyAgt1Acct', 'IntrmyAgt2', 'UltmtDbtr', 'UltmtCdtr', 'InitgPty', 'RmtInf', 'PmtTpInf', 'PmtId', 'Amt', 'XchgRateInf', 'SplmtryData', 'GrpHdr', 'PmtInf'];
  const GENERIC = ['Cd', 'Prtry', 'Id', 'Dt', 'Othr', 'Envlp'];
  const esc = WT.esc;
  const row = (k, v) => (v ? `<dt>${k}</dt><dd>${v}</dd>` : '');
  const decode = function (v) { const s = WT.fmt(v); const d = C.values[s]; return d ? `<code>${esc(s)}</code> ${esc(d.what)}` : `<code>${esc(WT.short(s, 60))}</code>`; };
  const addr = (p) => { const i = p.indexOf('.address.'); return i > 0 ? p.slice(0, i) + '.address' : p; };

  // every part of a path written out: DbtrAgt Debtor agent, FinInstnId Financial institution identification
  const longOf = (seg) => { const t = seg.split('@')[0]; return seg.includes('@') ? WT.tagName(seg) : ((C.short[t] && C.short[t][0]) || WT.tagName(t)); };
  const inFull = (p) => (WT.norm(p).split('/').filter(Boolean).length < 2 ? '' : row('In full', WT.norm(p).split('/').filter(Boolean).map((s) => { const n = longOf(s); return `<code>${esc(s)}</code>${n && n !== s ? ' ' + esc(n) : ''}`; }).join('<br>')));

  // one difference as a box: version 9, version 11, what it means for a wire. With a title when it stands in the list of all differences.
  const v11Html = (v, titled) => `<div class="vbox ${v.kind}${v.touches ? ' touches' : ''}"><b class="vhead">${titled ? `<code>${esc(v.where)}</code> <span class="vtag ${v.kind}">${v.kind}</span>${v.places > 1 ? ` <i>${v.places} places</i>` : ''}` : (v.kind === 'new' ? 'New in version 11' : 'Changed in version 11')}</b><div class="vcmp"><span>Version 9</span><p>${esc(v.v9)}</p><span>Version 11</span><p>${esc(v.v11)}</p><span>For a wire</span><p>${esc(v.wire)}</p></div>${v.note ? `<p class="vnote">${esc(v.note)}</p>` : ''}</div>`;
  const v11Box = (p) => { const v = WT.v11Of(p); return v ? v11Html(v, false) : ''; };
  WT.v11Html = v11Html;
  const build = function (spec, mode, c) {
    const [type, id] = [spec.slice(0, spec.indexOf(':')), spec.slice(spec.indexOf(':') + 1)];
    if (type === 'fj') return WT.fisCardHtml ? WT.fisCardHtml(id) : '';   // a row of the FIS JSON; the screen keeps the facts
    if (type === 'abbr') {
      const s = C.short[id]; if (!s) return ''; const v = C.values[id];
      return `<h4><code>${esc(id)}</code><span>${s[0] ? 'a short form' : 'a name'}</span></h4><dl>${row('In full', s[0] ? esc(s[0]) : 'The program documents give no long form.')}${row('What it is', esc(WT.shortWhat(id)))}${v ? row('Where it is used', 'A value of ' + esc(v.of) + '. ' + esc(v.how)) : ''}</dl>`;
    }
    if (type === 'val') { const d = C.values[id]; return d ? `<h4><code>${esc(id)}</code><span>a value of ${esc(d.of)}</span></h4><dl>${row('In full', C.short[id] && C.short[id][0] ? esc(C.short[id][0]) : '')}${row('What it is', esc(d.what))}${row('Why it exists', esc(d.why))}${row('How it is used', esc(d.how))}</dl>` : ''; }
    if (type === 'grp') {
      // a parent row: it has no value of its own, so say what the group is, where it sits and what it holds in this wire
      const segs = WT.norm(id).split('/'); const tag = segs[segs.length - 1]; const con = C.concepts[tag];
      const parent = [...segs].reverse().slice(1).find((t) => PARENTS.includes(t) && t !== tag); const above = segs.length > 1 ? segs[segs.length - 2] : null;
      let h = `<h4><code>${esc(WT.shortPath(id) || tag)}</code><span>${esc(longOf(tag))}${parent ? ', in ' + esc(WT.tagName(parent).toLowerCase()) : ''}</span></h4><dl>`;
      h += inFull(WT.shortPath(id) || tag);
      h += con ? row('What it is', esc(con.what)) + row('Why it exists', esc(con.why)) + row('How it is used', esc(con.how)) : row('What it is', esc(WT.tagName(tag)) + '.');
      const sits =parent || (above && C.concepts[above] ? above : null);
      if (sits && C.concepts[sits]) h += row('It sits in', `<code>${esc(sits)}</code> ${esc(C.concepts[sits].what)}`);
      if (mode === 'full' && c) {
        const inside = c.leaves.filter((l) => l.p.startsWith(id + '/') || l.p.startsWith(id + '@'));
        const kids = [...new Set(inside.map((l) => WT.norm(l.p.slice(id.length + 1)).split('/')[0].split('@')[0]).filter(Boolean))];
        if (kids.length) h += row('Holds in this wire', kids.slice(0, 8).map((t) => `<code>${esc(t)}</code>`).join(', ') + (kids.length > 8 ? ' and ' + (kids.length - 8) + ' more' : ''));
      }
      return h + '</dl>' + v11Box(id);
    }
    if (type === 'tag' || type === 'el') {
      // a leaf such as Cd, Id or Dt only wraps a value: explain the element it belongs to (LclInstrm/Cd is about LclInstrm)
      const p = WT.norm(id); const attr = p.includes('@'); const segs = p.split('/').map((t) => t.split('@')[0]); const leafTag = segs[segs.length - 1];
      const tag = attr ? 'Ccy' : (GENERIC.includes(leafTag) ? ([...segs].reverse().find((t) => !GENERIC.includes(t)) || leafTag) : leafTag);
      const con = C.concepts[tag]; const parent = type === 'el' ? [...segs].reverse().slice(1).find((t) => PARENTS.includes(t) && t !== tag) : null;
      const leaf = type === 'el' && c ? c.leaves.find((l) => l.p === id) : null;
      let h = `<h4><code>${esc(type === 'el' ? WT.shortPath(id) : tag)}</code><span>${esc(attr ? 'Currency of the ' + WT.tagName(leafTag).toLowerCase() : longOf(tag))}${parent ? ', in ' + esc(WT.tagName(parent).toLowerCase()) : ''}</span></h4><dl>`;
      h += inFull(type === 'el' ? WT.shortPath(id) : leafTag);
      h += con ? row('What it is', esc(con.what)) + row('Why it exists', esc(con.why)) + row('How it is used', esc(con.how)) : row('What it is', esc(WT.tagName(tag)) + '.');
      if (parent && C.concepts[parent] && parent !== tag) h += row('It sits in', `<code>${esc(parent)}</code> ${esc(C.concepts[parent].what)}`);
      if (leaf && leaf.v !== '') h += row('Value here', decode(leaf.v));
      if (mode === 'full' && type === 'el') {
        if (leaf) h += row('Comes from', leaf.src.length ? leaf.src.map((f) => `<code>${esc(f)}</code>`).join(', ') : { constant: 'a constant in the mapper', clock: 'the clock', context: 'a fixed setting in the mapper', envelope: 'the PayX envelope around the payload' }[leaf.how]);
        if (c && c.v9 && leaf) {   // the rule of the version 9 mapping document, and what version 11 does with the same element
          h += row('Version 9 rule', esc(leaf.say) + (leaf.assumed ? ' ' + esc(leaf.assumed) : ''));
          h += row('In the document', esc(leaf.st === 'Likely' ? 'Marked likely.' : leaf.how === 'constant' || leaf.how === 'envelope' ? 'Set by a decision.' : 'Marked confirmed.') + (leaf.row ? ' Row or decision ' + esc(leaf.row) + '.' : ''));
          h += leaf.d === 'only9' ? row('In version 11', 'Not written.') : leaf.d === 'differs' ? row('In version 11', leaf.how === 'envelope' ? 'Taken from the clock of the mapper.' : `<code>${esc(leaf.v11)}</code>`) : row('In version 11', 'The same value.');
        } else h += row('Rule', esc(WT.ruleFor(id)));
      }
      return h + '</dl>' + v11Box(type === 'el' ? id : tag);
    }
    if (type === 'field') {
      const key = id.split('.').pop(); const top = id.split('.')[0]; const group = id.endsWith('.address');
      const added = C.added && C.added[id];
      const fs = c ? c.fields.filter((f) => addr(f.p) === id) : [];
      const v = c && !group ? id.split('.').reduce((a, k) => (a == null ? a : a[k]), c.payload) : undefined;
      let h = `<h4><code>${esc(id)}</code><span>${id.includes('.') && C.fields[top] ? esc(C.fields[top].split('.')[0]) : 'a field of the payload'}</span></h4><dl>`;
      h += row('What it is', esc((id.endsWith('exchangeRate.exchangeRate') ? C.fields.exchangeRate_exchangeRate : C.fields[key]) || 'A field of the payload.'));
      h += row('Why it exists', esc(C.fieldWhy[key] || ''));
      if (added) h += row('Where it comes from', esc(added.keyed));
      if (v !== undefined) h += row('Value here', decode(v));
      if (mode === 'full' && fs.length && c.v9) {   // what the version 9 mapping document does with this field
        const to9 = [...new Set(fs.flatMap((x) => x.to.map(WT.norm)))];
        h += row('It fills', to9.length ? to9.slice(0, 4).map((t) => `<code>${esc(WT.shortPath(t))}</code>`).join(', ') + (to9.length > 4 ? ' and ' + (to9.length - 4) + ' more' : '') : 'Nothing in version 9.');
        h += row('Version 9 rule', esc(group ? 'Each part of the address goes to its own tag in PstlAdr. The town comes from townName, or from city when there is none.' : fs[0].say));
        if (!group) h += row('In the document', esc(fs[0].st) + (fs[0].row ? ', row ' + esc(fs[0].row) : '') + '.');
      } else if (mode === 'full' && fs.length) {
        const to = [...new Set(fs.flatMap((f) => f.to.map(WT.norm)))];
        h += to.length ? row('It fills', to.slice(0, 4).map((t) => `<code>${esc(WT.shortPath(t))}</code>`).join(', ') + (to.length > 4 ? ' and ' + (to.length - 4) + ' more' : '')) + row('Rule', esc(group ? 'Each part of the address goes to its own tag in PstlAdr.' : WT.ruleFor(to[0])))
          : row('It fills', 'Nothing. ' + esc(C.nowhere[id] || 'The mapper does not read it.'));
        if (!group) { const w = fs[0].without; h += row('If it is missing', w.rejected ? 'The mapper rejects the payment: ' + esc(w.rejected[0].replace('payload.', '')) + '.' : w.gone.length ? esc([...new Set(w.gone.map(WT.shortPath))].slice(0, 3).join(', ')) + ' is left out.' : w.changed.length ? esc(WT.shortPath(w.changed[0][0])) + ' takes another value: ' + esc(WT.short(w.changed[0][1], 40)) + '.' : 'Nothing changes in the message.'); }
      }
      return h + '</dl>';
    }
    return '';
  };
  // every card ends with the short forms its text uses, written out
  WT.shortsIn = function (text, own) { const out = []; SHORT_RE.lastIndex = 0; for (let m = SHORT_RE.exec(text); m; m = SHORT_RE.exec(text)) if (!(own || []).includes(m[1]) && !out.includes(m[1])) out.push(m[1]); return out; };
  WT.infoHtml = function (spec, mode, c) {
    const html = build(spec, mode, c); if (!html) return html;
    const id = spec.slice(spec.indexOf(':') + 1);
    const found = WT.shortsIn(html.replace(/<[^>]+>/g, ' '), [id, ...WT.norm(id).split(/[/.@]/)]).filter((k) => C.short[k][0]).slice(0, 8);
    return found.length ? html.replace('</dl>', row('Short forms here', found.map((k) => `<code>${esc(k)}</code> ${esc(C.short[k][0])}`).join('<br>')) + '</dl>') : html;
  };

  if (typeof document === 'undefined') return;   // the data checks load this file for its tables only
  // one card for the whole app: shown a moment after the pointer rests on anything that carries data-info
  const card = document.createElement('div'); card.className = 'infocard'; card.setAttribute('role', 'tooltip'); document.body.append(card);
  let timer = null; let shownFor = null;
  const hide = function () { clearTimeout(timer); timer = null; shownFor = null; card.classList.remove('on'); };
  const show = function (el) {
    const html = WT.infoHtml(el.dataset.info, el.dataset.infomode || 'meaning', WT.infoCase || null);
    if (!html) return;
    card.innerHTML = html; card.classList.add('on'); shownFor = el;
    const r = el.getBoundingClientRect(); const w = card.offsetWidth; const hgt = card.offsetHeight; const vw = window.innerWidth; const vh = window.innerHeight;
    let x = r.left + Math.min(40, r.width / 4); let y = r.bottom + 8;
    if (y + hgt > vh - 8) y = Math.max(8, r.top - hgt - 8);
    if (x + w > vw - 8) x = vw - w - 8;
    card.style.left = Math.max(8, x) + 'px'; card.style.top = y + 'px';
  };
  document.addEventListener('mouseover', (e) => {
    const el = e.target.closest && e.target.closest('[data-info]');
    if (!el || el === shownFor || document.body.classList.contains('dragging')) return;
    clearTimeout(timer); timer = setTimeout(() => show(el), 420);
  });
  document.addEventListener('mouseout', (e) => { const el = e.target.closest && e.target.closest('[data-info]'); if (el && !el.contains(e.relatedTarget)) hide(); });
  document.addEventListener('mousedown', hide); document.addEventListener('scroll', () => { if (shownFor) hide(); }, true); document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });
  WT.infoShow = show; WT.infoHide = hide;   // for the checks

  // ---------------------------------------------------------------- short forms on every screen
  // Each short form in running text is marked, and resting the pointer on it gives its long form. Left alone: anything that
  // already has a card of its own (that card lists its short forms), and an exercise until it has answered, so no answer is given away.
  const skip = (el) => el.closest('abbr.ac, [data-info], .infocard, textarea, input, select, script, style') || (el.closest('.ex') && !el.closest('.why, .feedback'));
  const mark = function (root) {
    if (!root || root.nodeType !== 1 || !root.isConnected) return;
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); const todo = [];
    for (let n = tw.nextNode(); n; n = tw.nextNode()) { SHORT_RE.lastIndex = 0; if (SHORT_RE.test(n.nodeValue) && n.parentElement && !skip(n.parentElement)) todo.push(n); }
    for (const n of todo) {
      const s = n.nodeValue; const frag = document.createDocumentFragment(); let at = 0; SHORT_RE.lastIndex = 0;
      for (let m = SHORT_RE.exec(s); m; m = SHORT_RE.exec(s)) {
        if (m.index > at) frag.append(s.slice(at, m.index));
        const a = document.createElement('abbr'); a.className = 'ac'; a.dataset.info = 'abbr:' + m[1]; a.textContent = m[1]; frag.append(a); at = m.index + m[1].length;
      }
      if (at < s.length) frag.append(s.slice(at));
      // in a flex or grid parent each piece would become an item of its own and drift apart: keep the text as one item
      if (/flex|grid/.test(getComputedStyle(n.parentElement).display)) { const one = document.createElement('span'); one.append(frag); n.replaceWith(one); } else n.replaceWith(frag);
    }
  };
  const WATCH = { childList: true, subtree: true, characterData: true };
  const watcher = new MutationObserver((recs) => {
    const roots = new Set();
    for (const r of recs) {
      if (r.type === 'characterData') { if (r.target.parentElement) roots.add(r.target.parentElement); continue; }
      for (const n of r.addedNodes) { if (n.nodeType === 1) roots.add(n); else if (n.nodeType === 3 && n.parentElement) roots.add(n.parentElement); }
    }
    watcher.disconnect(); for (const r of roots) mark(r); watcher.observe(document.body, WATCH);
  });
  mark(document.body); watcher.observe(document.body, WATCH);
  WT.markShorts = mark;   // for the checks
})();
