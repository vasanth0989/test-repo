// Start-up and the two tabs. The address bar always names the screen and the wire, so a link opens the same view.
//   #end-to-end/<how it starts>/<wire kind>      #fis-json/<message>
(function () {
  const WT = window.WT; const h = WT.h;
  const TABS = [['journey', 'End to end', 'end-to-end'], ['fisjson', 'To FIS JSON', 'fis-json']];
  WT.current = { view: 'journey', params: {} };
  WT.last = {};          // the last choices made on each screen
  WT.wire = null;        // the wire last looked at, on either screen: the other tab opens on the same one

  const journeyKind = (p) => p.kind || (p.way === 'gateway' && WT.original('gateway') ? 'gateway' : 'customer');
  const hashOf = function (view, p) {
    if (view === 'fisjson') return '#fis-json/' + encodeURIComponent(WT.fisEx || '');
    return '#end-to-end/' + encodeURIComponent(p.way || 'keyed') + '/' + encodeURIComponent(journeyKind(p));
  };
  const fromHash = function () {
    const [slug, a, b] = location.hash.replace(/^#\/?/, '').split('/').map(decodeURIComponent);
    if (slug === 'fis-json') return ['fisjson', a ? { ex: a } : {}];
    if (slug === 'end-to-end') {
      const p = {};
      if (a && WT.content.journey[a]) p.way = a;
      if (b && WT.original(b)) p.kind = b;
      return ['journey', p];
    }
    return null;
  };

  WT.go = function (view, params) {
    if (!WT.views[view]) view = 'journey';
    params = Object.assign({}, params);
    Object.keys(params).forEach((k) => params[k] === undefined && delete params[k]);
    if (view === 'journey' && params.kind && !WT.original(params.kind)) delete params.kind;
    WT.current = { view, params };
    const main = document.getElementById('main');
    main.className = 'v-' + view;
    WT.views[view](main, params);
    main.scrollTop = 0;
    window.dispatchEvent(new Event('resize'));
    if (view === 'journey') { WT.last.journey = { way: params.way, kind: params.kind }; WT.wire = WT.original(journeyKind(params)).id; }
    else { WT.last.fisjson = { ex: WT.fisEx }; WT.wire = WT.fisEx; }
    document.getElementById('nav').replaceChildren(...TABS.map(([id, label]) => h('button', { class: 'nav' + (id === view ? ' on' : ''), type: 'button', data: { view: id }, 'aria-current': id === view ? 'page' : null, onclick: () => open(id) }, label)));
    const hash = hashOf(view, params);
    if (location.hash !== hash) history.replaceState(null, '', hash);
  };

  // a tab opens on the wire the other tab was showing, when that wire exists there
  const open = function (view) {
    if (view === WT.current.view) return;
    if (view === 'fisjson') { WT.go('fisjson', { ex: WT.wire || (WT.last.fisjson || {}).ex }); return; }
    const c = WT.S.cases.find((x) => x.id === WT.wire && x.original && WT.original(x.kind) === x);
    const last = WT.last.journey || {};
    WT.go('journey', c ? { way: c.kind === 'gateway' ? 'gateway' : last.way, kind: c.kind } : last);
  };

  window.addEventListener('hashchange', () => {
    const now = hashOf(WT.current.view, WT.current.params); if (now === location.hash) return;
    const to = fromHash();
    if (to) WT.go(to[0], to[1]); else history.replaceState(null, '', now);   // an address that names no screen: stay, and put the right one back
  });

  WT.load().then(() => {
    const to = fromHash() || ['journey', {}];
    WT.go(to[0], to[1]);
    document.body.classList.add('ready');
  }).catch((e) => {
    document.getElementById('main').replaceChildren(h('div', { class: 'fatal' }, h('h1', {}, 'The app could not start'), h('p', {}, e.message)));
  });
})();
