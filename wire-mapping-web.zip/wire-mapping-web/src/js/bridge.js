// The browser side of what the desktop shell used to do: hand the data to the screens and remember small choices.
// The data arrives as plain scripts (data/*.js), so the app also works when index.html is opened straight from a folder.
(function () {
  const KEY = 'wire-mapping-web:v1';
  const D = window.WT_DATA || {};
  window.WT.views = window.WT.views || {};
  window.trainer = {
    load: async function () {
      if (!D.cases || !D.universe) throw new Error('The data files did not load.');
      let progress = null;
      try { progress = JSON.parse(localStorage.getItem(KEY)); } catch (e) { progress = null; }
      return { cases: D.cases, universe: D.universe, external: D.external || null, v9: D.v9 || null, fis: D.fis || null, progress, today: null, test: false };
    },
    // only what these two screens set is kept: which guides the reader has closed
    save: async function (p) { try { localStorage.setItem(KEY, JSON.stringify({ steps: p.steps || {} })); } catch (e) { /* private window: nothing is kept */ } return true; },
    copy: async function (text) { await navigator.clipboard.writeText(String(text)); return true; },
    saveText: async function (name, text) {
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' })); a.download = name;
      document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); return name;
    },
  };
})();
