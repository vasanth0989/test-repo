// Quick checks, no browser: every file the page names is there and parses, the data holds what the two screens
// read, the two screens name the same wires and the same tags, and nothing of the removed exercise is left.
//   node test/check.js          checks src/        node test/check.js dist     checks a built copy
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const dir = path.resolve(__dirname, '..', process.argv[2] || 'src');
let pass = 0; let fail = 0;
const ok = function (what, cond, detail) { if (cond) pass++; else { fail++; console.log('FAIL  ' + what + (detail ? '\n      ' + detail : '')); } };
const text = (rel) => fs.readFileSync(path.join(dir, rel), 'utf8');

const html = text('index.html');
const clean = (u) => u.split('?')[0];
const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map((m) => clean(m[1]));
const sheets = [...html.matchAll(/<link rel="stylesheet" href="([^"]+)"/g)].map((m) => clean(m[1]));
ok('the page loads scripts', scripts.length >= 10, String(scripts.length));
for (const f of [...scripts, ...sheets, 'icon.png']) ok(f + ' is there', fs.existsSync(path.join(dir, f)));
ok('the page loads nothing from the network', !/(src|href)="(https?:)?\/\//.test(html));
ok('no script inside the page itself', !/<script(?![^>]*\bsrc=)[^>]*>/.test(html));

// fonts named by the font sheet
for (const m of text('fonts/fonts.css').matchAll(/url\(\.\/([^)]+)\)/g)) ok('font ' + m[1], fs.existsSync(path.join(dir, 'fonts', m[1])));
ok('the styles ask for no web address', !/url\(\s*['"]?https?:/.test(text('styles.css') + text('web.css')));

// run the data and the content the way the browser does, in a sandbox
const win = { }; win.window = win;
const box = vm.createContext(win);
for (const f of scripts.filter((s) => s.startsWith('data/') || s === 'js/content.js')) {
  try { vm.runInContext(text(f), box, { filename: f }); ok(f + ' runs', true); } catch (e) { ok(f + ' runs', false, e.message); }
}
for (const f of scripts.filter((s) => s.startsWith('js/') && s !== 'js/content.js')) {
  try { new vm.Script(text(f), { filename: f }); ok(f + ' parses', true); } catch (e) { ok(f + ' parses', false, e.message); }
}
const D = win.WT_DATA || {}; const C = (win.WT || {}).content || {};
ok('data: wires', Array.isArray(D.cases) && D.cases.length >= 7, D.cases && String(D.cases.length));
ok('data: universe', D.universe && D.universe.elements.length > 100);
ok('data: mapping sheet', D.external && D.external.fields.length > 100);
ok('data: version 9', D.v9 && Object.keys(D.v9.cases).length === (D.cases || []).length);
ok('data: FIS JSON examples', D.fis && D.fis.examples.length >= 12 && D.fis.call && D.fis.wrapper && D.fis.contract);

// the two screens are wired to each other by the id of the wire and by the path of a tag
for (const c of D.cases || []) {
  ok(c.id + ': one wire per kind', D.cases.filter((x) => x.kind === c.kind).length === 1);
  ok(c.id + ': has a title', !!(C.kinds && C.kinds[c.kind]));
  ok(c.id + ': has a version 9 view', !!D.v9.cases[c.id]);
  const ex = D.fis.examples.find((e) => e.id === c.id);
  ok(c.id + ': has a FIS JSON example', !!ex && ex.group === 'ours');
  if (!ex) continue;
  const tags = new Set(ex.pairs.filter((q) => q.x).map((q) => q.x));
  const lost = c.leaves.filter((l) => !tags.has(l.p)).map((l) => l.p);
  ok(c.id + ': every tag of the message is in the FIS JSON example', lost.length === 0, lost.slice(0, 5).join(', '));
  ok(c.id + ': every tag has a JSON name', ex.pairs.every((q) => q.j && q.json));
}
ok('FIS\'s own samples are there', (D.fis ? D.fis.examples.filter((e) => e.group === 'fis').length : 0) === 4);

// what was removed stays removed
const journey = text('js/journey.js'); const fis = text('js/fisjson.js'); const app = text('js/app.js');
ok('no exercise from the screen to the payload', !/Now you|formExercise|WT\.go\('run'/.test(journey));
ok('End to end opens the wire as FIS JSON', /WT\.go\('fisjson', \{ ex: c\.id/.test(journey));
ok('To FIS JSON opens the wire end to end', /WT\.go\('journey', \{ kind: back\.kind/.test(fis));
ok('a picked row is carried over', /p\.pick && el\.x\[p\.pick\]/.test(fis));
ok('two tabs only', (app.match(/\['(journey|fisjson)', '[^']+', '[^']+'\]/g) || []).length === 2);
ok('no mapper review notes and no skeleton exercise in the content', !C.review && !C.skeleton);
const allJs = scripts.filter((s) => s.startsWith('js/')).map(text).join('\n');
ok('nothing of the desktop shell is left', !/require\(|ipcRenderer|electron/i.test(allJs));
ok('no screen is opened that does not exist', [...allJs.matchAll(/WT\.go\('([a-z]+)'/g)].every((m) => m[1] === 'journey' || m[1] === 'fisjson'), [...new Set([...allJs.matchAll(/WT\.go\('([a-z]+)'/g)].map((m) => m[1]))].join(' '));

console.log(`${pass} passed, ${fail} failed  (${path.basename(dir)}/)`);
process.exit(fail ? 1 : 0);
