// Brings the two screens (End to end, To FIS JSON), their styles, fonts and data over from the desktop trainer.
//   node tools/sync-from-trainer.js <folder of the desktop trainer>
// Run it again whenever the desktop trainer changes. The two screens are copied as they are, apart from two
// sentences; each change is checked: if the text it expects is no longer there, the script stops and names it.
const fs = require('node:fs');
const path = require('node:path');

const from = process.argv[2];
if (!from || !fs.existsSync(path.join(from, 'renderer', 'js', 'journey.js'))) {
  console.error('Give the folder of the desktop trainer: node tools/sync-from-trainer.js <folder>');
  process.exit(1);
}
const root = path.join(__dirname, '..');
const src = path.join(root, 'src');
const read = (...p) => fs.readFileSync(path.join(from, ...p), 'utf8');
const out = {};                                   // relative path under src -> text or Buffer, written at the end
const swap = function (name, text, find, put) {
  const n = text.split(find).length - 1;
  if (n !== 1) throw new Error(`${name}: expected this text once, found it ${n} times:\n  ${find.slice(0, 140)}`);
  return text.replace(find, () => put);
};
const cut = function (name, text, startMark, endMark) {   // removes from startMark up to, not including, endMark
  const a = text.indexOf(startMark); const b = a < 0 ? -1 : text.indexOf(endMark, a + startMark.length);
  if (a < 0 || b < 0 || b < a) throw new Error(`${name}: could not find the part to remove (${startMark.slice(0, 60)})`);
  return text.slice(0, a) + text.slice(b);
};

// ---------------------------------------------------------------- scripts
// content.js: the two screens do not use the skeleton exercise or the mapper review notes
let content = read('renderer', 'js', 'content.js');
content = cut('content.js', content, '  skeleton: {', '  tags: {');
content = cut('content.js', content, '  review: [', '\n};');
out['js/content.js'] = content;

out['js/core.js'] = read('renderer', 'js', 'core.js');
out['js/explain.js'] = read('renderer', 'js', 'explain.js');

// journey.js: one stop points at a screen this app does not have
let journey = read('renderer', 'js', 'journey.js');
journey = swap('journey.js', journey,
  "'What happens after that, up to the beneficiary\\'s account, is on the screen \"To the account\".'",
  "'How every tag of the message is written in that JSON is on the screen \"To FIS JSON\".'");
out['js/journey.js'] = journey;

// fisjson.js: only the hint for missing data differs
let fis = read('renderer', 'js', 'fisjson.js');
fis = swap('fisjson.js', fis, "h('p', {}, 'It is built with: npm run data:fis')", "h('p', {}, 'The data files of this app are incomplete.')");
out['js/fisjson.js'] = fis;

out['styles.css'] = read('renderer', 'styles.css');
out['icon.png'] = fs.readFileSync(path.join(from, 'assets', 'icon.png'));

// ---------------------------------------------------------------- fonts (only the weights the styles use, Latin)
const FONTS = [['familjen-grotesk', 'Familjen Grotesk', [500, 700]], ['atkinson-hyperlegible', 'Atkinson Hyperlegible', [400, 700]], ['jetbrains-mono', 'JetBrains Mono', [400, 600]]];
let fontCss = '/* The three typefaces of the app, kept in the app so that it needs no network. */\n';
for (const [pkg, family, weights] of FONTS) for (const w of weights) {
  const file = `${pkg}-latin-${w}-normal.woff2`;
  out['fonts/' + file] = fs.readFileSync(path.join(from, 'node_modules', '@fontsource', pkg, 'files', file));
  fontCss += `@font-face { font-family: '${family}'; font-style: normal; font-display: swap; font-weight: ${w}; src: url(./${file}) format('woff2'); }\n`;
}
out['fonts/fonts.css'] = fontCss;

// ---------------------------------------------------------------- data
// Only what the two screens read: one wire of each kind, its version 9 view, the mapping sheet and the FIS JSON examples.
const json = (f) => JSON.parse(read('data', f));
const KINDS = ['gateway', 'customer', 'bank', 'intermediary', 'drawdown', 'fx', 'onbehalf', 'uatfed', 'uatintl', 'uatinter'];
const all = json('cases.json');
const cases = KINDS.map((k) => all.find((c) => c.kind === k && c.original)).filter(Boolean);
const ids = new Set(cases.map((c) => c.id));
const v9all = json('v9.json');
const v9 = { cases: Object.fromEntries(Object.entries(v9all.cases).filter(([id]) => ids.has(id))) };
const fisAll = json('fisjson.json');
const fisData = { contract: fisAll.contract, wrapper: fisAll.wrapper, call: fisAll.call, examples: fisAll.examples };
const data = { cases, universe: json('universe.json'), external: json('external-map.json'), v9, fis: fisData };
for (const [k, v] of Object.entries(data)) out[`data/${k}.js`] = `(window.WT_DATA = window.WT_DATA || {}).${k} = ${JSON.stringify(v)};\n`;

// ---------------------------------------------------------------- write
let bytes = 0;
for (const [rel, body] of Object.entries(out)) {
  const file = path.join(src, rel);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, body);
  bytes += Buffer.byteLength(body);
}
console.log(`Copied ${Object.keys(out).length} files (${Math.round(bytes / 1024)} KB) into src.`);
console.log(`Wires: ${cases.map((c) => c.id).join(', ')}`);
console.log(`FIS JSON examples: ${fisData.examples.length}`);
