// Builds the folder that goes on a web server or on GitHub Pages.
//   node tools/build.js              writes dist/
//   node tools/build.js --out docs   writes docs/ instead (for "deploy from a branch, folder /docs")
// The result is plain files: index.html, styles, scripts, fonts and data. Every script and style address gets a
// stamp made from the content of the files, so that a browser never shows an old copy after an update.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const root = path.join(__dirname, '..');
const src = path.join(root, 'src');
const i = process.argv.indexOf('--out');
const outName = i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : 'dist';
const out = path.resolve(root, outName);
if (out === root || out === src || !out.startsWith(root + path.sep)) { console.error('Choose an output folder inside the app folder, such as dist or docs.'); process.exit(1); }

const files = [];
const walk = function (dir) { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) walk(p); else files.push(p); } };
walk(src);
const hash = crypto.createHash('sha256');
for (const f of files.slice().sort()) { hash.update(path.relative(src, f)); hash.update(fs.readFileSync(f)); }
const stamp = hash.digest('hex').slice(0, 10);

fs.rmSync(out, { recursive: true, force: true });
let bytes = 0;
for (const f of files) {
  const rel = path.relative(src, f); const to = path.join(out, rel);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  let body = fs.readFileSync(f);
  if (rel === 'index.html') {
    let html = body.toString('utf8');
    const missing = [];
    html = html.replace(/(<script src="|<link rel="stylesheet" href=")([^"]+)(")/g, (m, a, url, c) => { if (!fs.existsSync(path.join(src, url))) missing.push(url); return a + url + '?v=' + stamp + c; });
    if (missing.length) { console.error('index.html names files that are not there: ' + missing.join(', ')); process.exit(1); }
    body = Buffer.from(html, 'utf8');
  }
  fs.writeFileSync(to, body); bytes += body.length;
}
fs.writeFileSync(path.join(out, '.nojekyll'), '');   // GitHub Pages: serve the files as they are
console.log(`Built ${files.length} files, ${(bytes / 1024 / 1024).toFixed(2)} MB, into ${path.relative(root, out)}${path.sep}  (stamp ${stamp})`);
console.log('Open it:   npm run preview      or double-click ' + path.join(path.relative(root, out), 'index.html'));
