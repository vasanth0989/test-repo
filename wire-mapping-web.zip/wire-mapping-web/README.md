# Wire Mapping, in the browser

Two screens that follow one wire from the first keystroke to the request FIS receives.

| Screen | What it shows |
|---|---|
| **End to end** | Three columns: the wire entry screen (or the gateway's API request), the SDP payload, and the pain.001 the mapper builds. Click anything in any column: it lights up in all three, lines join them, and the bar underneath says what it becomes and why. Six numbered stops say what happens to the wire on the way. |
| **To FIS JSON** | The pain.001 XML on the left and the same message as the FIS API takes it on the right, linked row by row. Counters show what changes on the way. |

The two screens are joined:

- **This wire as FIS JSON** (top right of End to end) opens the same wire on the second screen. A row picked in the message stays picked there.
- **This wire, end to end** (top right of To FIS JSON) goes back to where the message comes from.
- Switching tabs keeps the wire you were looking at.
- The address bar always names the screen and the wire, so a copied link opens the same view. Examples: `#end-to-end/gateway/bank`, `#fis-json/fis-sample-drawdown`.

Also on the screens: a V11 / V9 switch on the message, a search box in each column, a card with the full name and meaning when the pointer rests on a field, tag or code, ten wires to choose from, and FIS's four own sample requests.

## Run it

There is nothing to install. The app has no packages; it needs only Node.js 18 or later, and for the last way below not even that.

| Way | How |
|---|---|
| With Node | In a terminal, in this folder: `npm start`. It starts a small server on this computer and opens the browser. `npm start -- --port 5000` for another port, `--no-open` to leave the browser alone. Works the same on macOS, Windows and Linux. |
| No Node at all | Open `dist/index.html` in Chrome or Edge. The built copy works straight from the folder. |

The server listens on this computer only. The app makes no network calls: fonts, scripts and data are all in the folder.

## Build it

```
npm run build
```

writes `dist/`: plain files (page, styles, scripts, fonts, data), about 1.4 MB. Every script and style address carries a stamp made from the content, so a browser never keeps an old copy after an update.

```
npm run preview      serve dist/ locally, to look at exactly what will be deployed
npm test             quick checks on src/ (no browser, about a second)
npm run test:dist    the same checks on dist/
```

## Put it on GitHub Pages

The content of `dist/` is the whole site. Two usual ways:

1. **From a folder of the repository.** Run `npm run build:docs`, which writes the site into `docs/` instead. Commit it. In the repository settings, under Pages, choose "Deploy from a branch", the branch, and the folder `/docs`.
2. **From its own branch.** Build, then push the content of `dist/` to a branch such as `gh-pages` and point Pages at it.

All addresses inside the app are relative, so it works under `https://<name>.github.io/<repository>/` without any setting. A `.nojekyll` file is written so that GitHub serves the files as they are.

Before making it public, check what may be published: the app holds field names of the payment object, the mapping rules, names from the FIS contract, and three wires from a test environment.

## What is in the folder

```
src/                the app as it runs
  index.html
  styles.css        the styles of the screens
  web.css           the browser layout (a bar across the top)
  js/content.js     names of tags and fields, one-line rules
  js/core.js        small helpers and the data store
  js/bridge.js      hands the data to the screens; remembers closed guides in the browser
  js/journey.js     the End to end screen
  js/explain.js     the cards and the V11 / V9 comparison
  js/fisjson.js     the To FIS JSON screen
  js/app.js         the two tabs and the address bar
  data/*.js         the wires, the mapping sheet, the V9 view, the FIS JSON examples
  fonts/            the three typefaces
dist/               the built copy (made by npm run build)
server.js           the local server
tools/build.js      the build
tools/sync-from-trainer.js   refreshes src/ from the desktop trainer (see below)
test/check.js       the quick checks
```

## Where the content comes from

The screens, the styles and the data are taken from the desktop Wire Mapping Trainer. The answers in the data come from running the real mapper over sample payloads, and from the FIS contract and FIS's own sample requests; none of it is typed by hand.

When the desktop trainer changes, refresh this app from it:

```
npm run sync -- "<folder of the desktop trainer>"
npm test
npm run build
```

The sync copies the two screens as they are in the desktop trainer, apart from two sentences that point at screens this app does not have, and takes only the data the two screens read. If a piece of text it expects has changed in the trainer, it stops and names it. On a computer without the desktop trainer nothing needs to be synced: `src/` is complete as it is.

## What is not in this app

The other screens of the desktop trainer: the learning path, the exercises and drills, the cases, the route to the account, the reference tables and the mapper notes.
